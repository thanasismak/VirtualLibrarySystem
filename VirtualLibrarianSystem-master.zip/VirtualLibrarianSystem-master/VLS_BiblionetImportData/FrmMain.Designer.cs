﻿namespace VLS_BiblionetImportData
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PnlControls = new System.Windows.Forms.Panel();
            this.chkCompanies = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblinfo = new System.Windows.Forms.Label();
            this.pg = new System.Windows.Forms.ProgressBar();
            this.chkCategories = new System.Windows.Forms.CheckBox();
            this.memLog = new System.Windows.Forms.RichTextBox();
            this.chkPersonKind = new System.Windows.Forms.CheckBox();
            this.chkPersons = new System.Windows.Forms.CheckBox();
            this.chkBooks = new System.Windows.Forms.CheckBox();
            this.BtnStart = new System.Windows.Forms.Button();
            this.PnlControls.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlControls
            // 
            this.PnlControls.Controls.Add(this.BtnStart);
            this.PnlControls.Controls.Add(this.chkBooks);
            this.PnlControls.Controls.Add(this.chkPersons);
            this.PnlControls.Controls.Add(this.chkPersonKind);
            this.PnlControls.Controls.Add(this.chkCategories);
            this.PnlControls.Controls.Add(this.chkCompanies);
            this.PnlControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlControls.Location = new System.Drawing.Point(0, 0);
            this.PnlControls.Name = "PnlControls";
            this.PnlControls.Size = new System.Drawing.Size(691, 50);
            this.PnlControls.TabIndex = 6;
            // 
            // chkCompanies
            // 
            this.chkCompanies.AutoSize = true;
            this.chkCompanies.Location = new System.Drawing.Point(12, 7);
            this.chkCompanies.Name = "chkCompanies";
            this.chkCompanies.Size = new System.Drawing.Size(78, 17);
            this.chkCompanies.TabIndex = 2;
            this.chkCompanies.Text = "Companies";
            this.chkCompanies.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.memLog);
            this.panel3.Controls.Add(this.pg);
            this.panel3.Controls.Add(this.lblinfo);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 50);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(691, 360);
            this.panel3.TabIndex = 7;
            // 
            // lblinfo
            // 
            this.lblinfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblinfo.Location = new System.Drawing.Point(0, 0);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(691, 23);
            this.lblinfo.TabIndex = 9;
            this.lblinfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pg
            // 
            this.pg.Dock = System.Windows.Forms.DockStyle.Top;
            this.pg.Location = new System.Drawing.Point(0, 23);
            this.pg.Name = "pg";
            this.pg.Size = new System.Drawing.Size(691, 23);
            this.pg.Step = 1;
            this.pg.TabIndex = 10;
            // 
            // chkCategories
            // 
            this.chkCategories.AutoSize = true;
            this.chkCategories.Location = new System.Drawing.Point(12, 30);
            this.chkCategories.Name = "chkCategories";
            this.chkCategories.Size = new System.Drawing.Size(76, 17);
            this.chkCategories.TabIndex = 3;
            this.chkCategories.Text = "Categories";
            this.chkCategories.UseVisualStyleBackColor = true;
            // 
            // memLog
            // 
            this.memLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.memLog.Location = new System.Drawing.Point(0, 46);
            this.memLog.Name = "memLog";
            this.memLog.Size = new System.Drawing.Size(691, 314);
            this.memLog.TabIndex = 11;
            this.memLog.Text = "";
            // 
            // chkPersonKind
            // 
            this.chkPersonKind.AutoSize = true;
            this.chkPersonKind.Location = new System.Drawing.Point(115, 7);
            this.chkPersonKind.Name = "chkPersonKind";
            this.chkPersonKind.Size = new System.Drawing.Size(80, 17);
            this.chkPersonKind.TabIndex = 4;
            this.chkPersonKind.Text = "PersonKind";
            this.chkPersonKind.UseVisualStyleBackColor = true;
            // 
            // chkPersons
            // 
            this.chkPersons.AutoSize = true;
            this.chkPersons.Location = new System.Drawing.Point(115, 30);
            this.chkPersons.Name = "chkPersons";
            this.chkPersons.Size = new System.Drawing.Size(64, 17);
            this.chkPersons.TabIndex = 5;
            this.chkPersons.Text = "Persons";
            this.chkPersons.UseVisualStyleBackColor = true;
            // 
            // chkBooks
            // 
            this.chkBooks.AutoSize = true;
            this.chkBooks.Location = new System.Drawing.Point(214, 7);
            this.chkBooks.Name = "chkBooks";
            this.chkBooks.Size = new System.Drawing.Size(56, 17);
            this.chkBooks.TabIndex = 6;
            this.chkBooks.Text = "Books";
            this.chkBooks.UseVisualStyleBackColor = true;
            // 
            // BtnStart
            // 
            this.BtnStart.Location = new System.Drawing.Point(604, 12);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(75, 23);
            this.BtnStart.TabIndex = 7;
            this.BtnStart.Text = "Start";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 410);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.PnlControls);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Data From BiblioNet";
            this.PnlControls.ResumeLayout(false);
            this.PnlControls.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel PnlControls;
        private System.Windows.Forms.CheckBox chkCompanies;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ProgressBar pg;
        private System.Windows.Forms.Label lblinfo;
        private System.Windows.Forms.CheckBox chkCategories;
        private System.Windows.Forms.RichTextBox memLog;
        private System.Windows.Forms.CheckBox chkPersonKind;
        private System.Windows.Forms.CheckBox chkPersons;
        private System.Windows.Forms.CheckBox chkBooks;
        private System.Windows.Forms.Button BtnStart;
    }
}

