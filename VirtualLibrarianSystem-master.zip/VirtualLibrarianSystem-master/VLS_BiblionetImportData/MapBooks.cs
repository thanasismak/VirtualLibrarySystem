﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class MapBooks
    {
        public ImportData Map()
        {
            var importdata = new ImportData
            {
                Importfilters = new ImportFilters()
                {
                    SetOffIdentity = true,
                    Title = "Book",
                    RemoteLoadDataQuery ="select TitlesID,Title,SubTitle,OrigTitle,Descr,PubYear,PubMonth,Pages,ISBN,ISBN13,LastMod, \n" +
                        "        Titles_Com, Titles_Subjects, Titles_Persons \n" +
                        " from [biblionetftp].[BibTitles] order by TitlesID ",
                    RemoteIdFieldName = "TitlesID",
                    LocalTableName = "Book",
                    LocalIdFieldName = "BookId",
                    FieldMapping = new List<ImportFiltersFieldMapping>
                    {
                        new ImportFiltersFieldMapping() {LocalFieldName = "BookId", RemoteFieldName = "TitlesID"},
                        new ImportFiltersFieldMapping() {LocalFieldName = "Title",RemoteFieldName = "Title",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "SubTitle",RemoteFieldName = "SubTitle",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "OriginTitle",RemoteFieldName = "OrigTitle",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "Description",RemoteFieldName = "Descr",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "PublishYear", RemoteFieldName = "PubYear"},
                        new ImportFiltersFieldMapping() {LocalFieldName = "PublishMonth", RemoteFieldName = "PubMonth"},
                        new ImportFiltersFieldMapping() {LocalFieldName = "Pages", RemoteFieldName = "Pages"},
                        new ImportFiltersFieldMapping() {LocalFieldName = "ISBN",RemoteFieldName = "ISBN",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "ISBN13",RemoteFieldName = "ISBN13",NeedQuote = true},
                        new ImportFiltersFieldMapping() {LocalFieldName = "LastModified",RemoteFieldName = "LastMod",NeedQuote = false,IsDateTime = true},
                    },
                    DownLoadImages = false,
                    DwRemotefolder = "covers",
                    DwLocalfolder = "Books",
                    DwPrefixes = "s;b",
                    DwIdFieldName = "TitlesID",
                    Details = new List<ImportFilters>
                    {
                        new ImportFilters()
                        {
                            LocalTableName = "BookCompany",
                            LocalIdFieldName = "BookId",
                            RemoteIdFieldName = "Titles_Com",
                            FieldMapping = new List<ImportFiltersFieldMapping>
                            {
                                new ImportFiltersFieldMapping(){LocalFieldName = "CompanyId",RemoteFieldName = "CompanyId"},
                                new ImportFiltersFieldMapping(){LocalFieldName = "PersonKindId",RemoteFieldName = "PersonKindId"}
                            }
                        },
                        new ImportFilters()
                        {
                            LocalTableName = "BookPerson",
                            LocalIdFieldName = "BookId",
                            RemoteIdFieldName = "Titles_Persons",
                            FieldMapping = new List<ImportFiltersFieldMapping>
                            {
                                new ImportFiltersFieldMapping(){LocalFieldName = "PersonId",RemoteFieldName = "PersonId"},
                                new ImportFiltersFieldMapping(){LocalFieldName = "PersonKindId",RemoteFieldName = "PersonKindId"}
                            }
                        },
                        new ImportFilters()
                        {
                            LocalTableName = "BookCategory",
                            LocalIdFieldName = "BookId",
                            RemoteIdFieldName = "Titles_Subjects",
                            FieldMapping = new List<ImportFiltersFieldMapping>
                            {
                                new ImportFiltersFieldMapping(){LocalFieldName = "CategoryId",RemoteFieldName = "CategoryId"},
                            }
                        },
                    }
                }
            };
            return importdata;
        }

    }
}
