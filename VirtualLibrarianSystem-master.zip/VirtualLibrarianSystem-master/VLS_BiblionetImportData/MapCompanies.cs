﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class MapCompanies
    {
        public ImportData Mapcompanies()
        {
            var mapcommon = new MapCommon();
            var importdata = new ImportData
            {
                Importfilters = new ImportFilters()
                {
                    SetOffIdentity = true,
                    Title = "Companies",
                    RemoteLoadDataQuery ="Select ComID,Name,Address,email,WebSite,Phone1,Phone2,Phone3,Fax,LastMod from [biblionetftp].[BibComs] order by ComID ",
                    RemoteIdFieldName = "ComID",
                    LocalTableName = "Company",
                    LocalIdFieldName = "CompanyID",
                    FieldMapping = new List<ImportFiltersFieldMapping>
                    {
                        new ImportFiltersFieldMapping() {LocalFieldName = "CompanyID", RemoteFieldName = "ComID"},
                        mapcommon.FieldName,
                        new ImportFiltersFieldMapping(){LocalFieldName = "Address",RemoteFieldName = "Address",NeedQuote = true},
                        mapcommon.FieldEmail,
                        mapcommon.FieldWebSite,
                        new ImportFiltersFieldMapping(){LocalFieldName = "Phone1",RemoteFieldName = "Phone1",NeedQuote = true},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Phone2",RemoteFieldName = "Phone2",NeedQuote = true},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Phone3",RemoteFieldName = "Phone3",NeedQuote = true},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Fax",RemoteFieldName = "Fax",NeedQuote = true},
                        mapcommon.FieldLastMod,
                    }
                }
            };
            return importdata;
        }
    }
}