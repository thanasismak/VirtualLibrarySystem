﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class MapPersons
    {
        public ImportData Mappersons()
        {
            var mapcommon = new MapCommon();
            var importdata = new ImportData
            {
                Importfilters = new ImportFilters()
                {
                    SetOffIdentity = true,
                    Title = "Person",
                    RemoteLoadDataQuery ="select PersonsID,Name,Descr,Email,Website,LastMod from [biblionetftp].[BibPersons] order by PersonsID ",
                    RemoteIdFieldName = "PersonsID",
                    LocalTableName = "Person",
                    LocalIdFieldName = "PersonId",
                    FieldMapping = new List<ImportFiltersFieldMapping>
                    {
                        new ImportFiltersFieldMapping(){LocalFieldName = "PersonId", RemoteFieldName = "PersonsID"},
                        mapcommon.FieldName,
                        new ImportFiltersFieldMapping(){LocalFieldName = "Description",RemoteFieldName = "Descr",NeedQuote = true},
                        mapcommon.FieldEmail,
                        mapcommon.FieldWebSite,
                        mapcommon.FieldLastMod,
                    },
                    DownLoadImages = false,
                    DwRemotefolder = "persons",
                    DwLocalfolder = "Persons",
                    DwPrefixes = "",
                    DwIdFieldName = "PersonsID",
                }
            };
            return importdata;
       }
    }
}
