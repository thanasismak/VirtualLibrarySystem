﻿using System;
using System.Windows.Forms;

namespace VLS_BiblionetImportData
{

    public partial class FrmMain : Form
    {

        public FrmMain()
        {
            InitializeComponent();
        }

        private void InitControls(string initext)
        {
            lblinfo.Text = "";
            if (initext != "")
                memLog.Clear();
            pg.Step = 1;
            pg.Maximum = 0;
            pg.Value = 0;
        }

        public void UpdateInfoLabel(string text)
        {
            lblinfo.Text = text;
        }

        public void UpdateProgress()
        {
            pg.PerformStep();
        }

        public void SetMaximumProgress(Int32 maximum)
        {
            pg.Maximum = maximum;
        }

        public void AddLine(string text)
        {
            memLog.AppendText(text);
            memLog.ScrollToCaret();
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            PnlControls.Enabled = false;
            try
            {
                if (chkCompanies.Checked)
                {
                    InitControls("Loading Companies from Biblionet");
                    try
                    {
                        var m = new MapCompanies();
                        var importdata = m.Mapcompanies();
                        importdata.Main = this;
                        importdata.MapAndImportData();
                    }
                    finally
                    {
                        InitControls("");
                    }
                }

                if (chkCategories.Checked)
                {
                    InitControls("Loading Categories from Biblionet");
                    try
                    {
                        var m = new MapCategories();
                        var importdata = m.Map();
                        importdata.Main = this;
                        importdata.MapAndImportData();
                    }
                    finally
                    {
                        InitControls("");
                    }
                }

                if (chkPersonKind.Checked)
                {
                    InitControls("Loading PersonKind from Biblionet");
                    try
                    {
                        var m = new MapPersonKinds();
                        var importdata = m.Map();
                        importdata.Main = this;
                        importdata.MapAndImportData();
                    }
                    finally
                    {
                        InitControls("");
                    }
                }

                if (chkPersons.Checked)
                {
                    InitControls("Loading Persons from Biblionet");
                    try
                    {
                        var m = new MapPersons();
                        var importdata = m.Mappersons();
                        importdata.Main = this;
                        importdata.MapAndImportData();
                    }
                    finally
                    {
                        InitControls("");
                    }
                }


                if (chkBooks.Checked)
                {
                    InitControls("Loading Books from Biblionet");
                    try
                    {
                        var m = new MapBooks();
                        var importdata = m.Map();
                        importdata.Main = this;
                        importdata.MapAndImportData();
                    }
                    finally
                    {
                        InitControls("");
                    }
                }


            }
            finally
            {
                PnlControls.Enabled = true;
            }
        }
    }
}