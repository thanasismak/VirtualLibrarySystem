﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class MapCategories
    {
        public ImportData Map()
        {
            var importdata = new ImportData
            {
                Importfilters = new ImportFilters()
                {
                    SetOffIdentity = true,
                    SetOffConstraints = true,
                    Title = "Categories",
                    RemoteLoadDataQuery ="select SubjectsID, Subjects1, ParentID, DDC from [biblionetftp].[BibSubjects] order by SubjectsID ",
                    RemoteIdFieldName = "SubjectsID",
                    LocalTableName = "Category",
                    LocalIdFieldName = "CategoryID",
                    FieldMapping = new List<ImportFiltersFieldMapping>
                    {
                        new ImportFiltersFieldMapping() {LocalFieldName = "CategoryId", RemoteFieldName = "SubjectsID"},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Description",RemoteFieldName = "Subjects1",NeedQuote = true},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Code",RemoteFieldName = "DDC",NeedQuote = true},
                        new ImportFiltersFieldMapping(){LocalFieldName = "ParentCategoryId",RemoteFieldName = "ParentID"},
                    }
                }
            };
            return importdata;
        }
    }
}
