﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class ImportFiltersFieldMapping
    {
        public string LocalFieldName { get; set; }
        public string RemoteFieldName { get; set; }
        public bool NeedQuote { get; set; }
        public bool IsDateTime { get; set; }
    }

    public class ImportFilters
    {
        public string Title { get; set; }
        public string LocalTableName { get; set; }
        public string LocalIdFieldName { get; set; }
        public string RemoteLoadDataQuery { get; set; }
        public string RemoteIdFieldName { get; set; }
        public bool SetOffIdentity { get; set; }
        public bool SetOffConstraints { get; set; }
        public bool DownLoadImages { get; set; }
        public string DwRemotefolder { get; set; }
        public string DwLocalfolder { get; set; }
        public string DwPrefixes { get; set; }
        public string DwIdFieldName { get; set; }


        public List<ImportFiltersFieldMapping> FieldMapping;
        public List<ImportFilters> Details;
    }

}
