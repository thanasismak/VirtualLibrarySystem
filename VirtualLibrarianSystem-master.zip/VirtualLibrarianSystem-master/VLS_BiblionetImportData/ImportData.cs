﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace VLS_BiblionetImportData
{

    public class ImportData
    {
        private SqlConnection _connVls;
        private SqlConnection _connBn;
        public FrmMain Main;
        public ImportFilters Importfilters;

        private void OpenConnections()
        {
            try
            {
                _connVls = new SqlConnection(Properties.Settings.Default.VLS_ConnectionString);
                _connVls.Open();
            }
            catch (Exception ex)
            {
                Main.AddLine($"Error at connect with VLS DB, Error : {ex.Message} ");
            }

            try
            {
                _connBn = new SqlConnection(Properties.Settings.Default.BiblioNet_ConnectionString);
                _connBn.Open();
            }
            catch (Exception ex)
            {
                Main.AddLine($"Error at connect with BiblioNet DB, Error : {ex.Message} ");
            }
        }

        private void CloseConnections()
        {
            try
            {
                _connVls.Close();
                _connVls.Dispose();
            }
            catch
            {
                // ignored
            }

            try
            {
                _connBn.Close();
                _connBn.Dispose();
            }
            catch
            {
                // ignored
            }
        }

        private void RunQuery(SqlConnection conn, string sql)
        {
            using (var cmd = new SqlCommand())
            {
                try
                {
                    cmd.Connection = conn;
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    Main.AddLine(string.Format("Error with RunQuery SQL: "+sql +"   ERROR:  "+ ex.Message));
                }
            }
        }

        private DataTable LoadData(SqlConnection conn, string sql)
        {
            using (SqlDataAdapter a = new SqlDataAdapter(sql, conn))
            {
                var dtData = new DataTable();
                a.Fill(dtData);
                return dtData;
            }
        }

        public string GetFieldValueDateTime(DateTime value)
        {
            string s =
                $"CONVERT(DATETIME,'{value.Day}/{value.Month}/{value.Year} {value.Hour}:{value.Minute}:{value.Second}',103)";
            return s;
        }

        public void GetImage(string folder,string localfolder,string prefix,string id)
        {
            try
            {
                var remoteFileUrl = $"http://www.biblionet.gr/images/{folder}/{prefix}{id}.jpg";
                var localFileName = $"../../Images/{localfolder}/{prefix}{id}.jpg";
                using (var webClient = new WebClient())
                    webClient.DownloadFile(remoteFileUrl, localFileName);
            }
            catch (Exception)
            {
                // ignored
            }
        }

        public void MapAndImportData()
        {
            Int32 recordCount = 0;
            Int32 recordInsert = 0;
            Int32 recordUpdate = 0;
            Int32 recordError = 0;
            OpenConnections();
            try
            {
                DataTable dtData = LoadData(_connBn, Importfilters.RemoteLoadDataQuery);
                recordCount = dtData.Rows.Count;
                Main.SetMaximumProgress(recordCount);

                if (Importfilters.SetOffConstraints) RunQuery(_connVls, "ALTER TABLE " + Importfilters.LocalTableName + " NOCHECK CONSTRAINT ALL");
                if (Importfilters.SetOffIdentity) RunQuery(_connVls, "set identity_insert "+ Importfilters.LocalTableName+" on");
                try
                {
                    for (int ii = 0; ii < recordCount; ii++)
                    {
                        Application.DoEvents();
                        Main.UpdateInfoLabel(Importfilters.Title+"   "+ ii + " From " + recordCount);
                        Main.UpdateProgress();

                        DataRow dr = dtData.Rows[ii];

                        try
                        {
                            var sql = new StringBuilder();
                            sql.Append($"select * from {Importfilters.LocalTableName} where {Importfilters.LocalIdFieldName}={dr[Importfilters.RemoteIdFieldName]}");
                            DataTable dtDataUpd = LoadData(_connVls, sql.ToString());
                            if (dtDataUpd.Rows.Count > 0)
                            {
                                sql.Clear();
                                foreach (var field in Importfilters.FieldMapping)
                                {
                                    if (field.LocalFieldName.ToUpper(CultureInfo.CurrentCulture)==Importfilters.LocalIdFieldName.ToUpper(CultureInfo.CurrentCulture)) continue;
                                    string fieldvalue = dr[field.RemoteFieldName].ToString().Replace("'", "''");
                                    if (field.IsDateTime)
                                        fieldvalue=GetFieldValueDateTime(Convert.ToDateTime(fieldvalue));
                                    if (field.NeedQuote)
                                        fieldvalue = "'" + fieldvalue + "'";
                                    else
                                        fieldvalue = fieldvalue == "" ? "null" : fieldvalue;
                                    sql.Append($"{field.LocalFieldName}={fieldvalue},");
                                }
                                sql.Remove(sql.Length - 1, 1);
                                RunQuery(_connVls, $"update {Importfilters.LocalTableName} set {sql} where {Importfilters.LocalIdFieldName}={dr[Importfilters.RemoteIdFieldName]} ");
                                recordUpdate += 1;
                            }
                            else
                            {
                                var sqlFieldsBld = new StringBuilder();
                                var sqlValuesBld = new StringBuilder();
                                foreach (var field in Importfilters.FieldMapping)
                                {
                                    string fieldvalue = dr[field.RemoteFieldName].ToString().Replace("'", "''");
                                    if (field.IsDateTime)
                                        fieldvalue = GetFieldValueDateTime(Convert.ToDateTime(fieldvalue));
                                    if (field.NeedQuote)
                                        fieldvalue = "'" + fieldvalue + "'";
                                    else
                                        fieldvalue = fieldvalue == "" ? "null" : fieldvalue;
                                    sqlValuesBld.Append($"{fieldvalue},");
                                    sqlFieldsBld.Append($"{field.LocalFieldName},");
                                }
                                sqlFieldsBld.Remove(sqlFieldsBld.Length - 1,1);
                                sqlValuesBld.Remove(sqlValuesBld.Length - 1,1);

                                sql.Clear();
                                sql.Append($"insert into {Importfilters.LocalTableName}({sqlFieldsBld}) values ({sqlValuesBld}) ");
                                RunQuery(_connVls, sql.ToString());
                                recordInsert += 1;
                            }

                            if (Importfilters.Details!=null)
                                foreach (var detail in Importfilters.Details)
                                    FixFetails(detail.FieldMapping,detail.LocalTableName, detail.LocalIdFieldName,dr[Importfilters.RemoteIdFieldName].ToString(), dr[detail.RemoteIdFieldName].ToString());


                            if (Importfilters.DownLoadImages)
                            {
                                if (Importfilters.DwPrefixes == "")
                                    GetImage(Importfilters.DwRemotefolder, Importfilters.DwLocalfolder,Importfilters.DwPrefixes, dr[Importfilters.DwIdFieldName].ToString());
                                else
                                {
                                    var dWPrefixList = Importfilters.DwPrefixes.Split(';');
                                    foreach (string dWPrefix in dWPrefixList)
                                        GetImage(Importfilters.DwRemotefolder, Importfilters.DwLocalfolder, dWPrefix, dr[Importfilters.DwIdFieldName].ToString());
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            recordError += 1;
                            Main.AddLine($"Error with {Importfilters.RemoteIdFieldName}:{dr[Importfilters.RemoteIdFieldName]} Error : {ex.Message} \n");
                        }
                    }
                }
                finally
                {
                    if (Importfilters.SetOffConstraints) RunQuery(_connVls, "ALTER TABLE " + Importfilters.LocalTableName + " WITH CHECK CHECK CONSTRAINT ALL");
                    if (Importfilters.SetOffIdentity) RunQuery(_connVls, "set identity_insert "+ Importfilters.LocalTableName + " off");
                }

            }
            finally
            {
                CloseConnections();
                Main.AddLine(
                    $"{Importfilters.Title},  Found:{recordCount} Insert:{recordInsert} Update:{recordUpdate}, Error:{recordError} ");
            }
        }

        public void FixFetails(List<ImportFiltersFieldMapping> fieldMapping, string localTableName,string keyField, string keyValue,string values)
        {
            RunQuery(_connVls, $"Delete From {localTableName} where {keyField}={keyValue}");
            var valueList = values.Split('*');
            foreach (string value in valueList)
            {
                if (value != "")
                {
                    var ids = value.Split('.');
                    var sqlFieldsBld = new StringBuilder();
                    var sqlValuesBld = new StringBuilder();
                    int ii = 0;
                    foreach (var field in fieldMapping)
                    {
                        string fieldvalue = ids[ii];
                        if (field.IsDateTime)
                            fieldvalue = GetFieldValueDateTime(Convert.ToDateTime(fieldvalue));
                        if (field.NeedQuote)
                            fieldvalue = "'" + fieldvalue + "'";
                        else
                            fieldvalue = fieldvalue == "" ? "null" : fieldvalue;

                        sqlValuesBld.Append($"{fieldvalue},");
                        sqlFieldsBld.Append($"{field.LocalFieldName},");
                        ii += 1;
                    }
                    sqlValuesBld.Append(keyValue);
                    sqlFieldsBld.Append(keyField);

                    string sql = $"insert into {localTableName}({sqlFieldsBld}) values ({sqlValuesBld}) ";
                    RunQuery(_connVls, sql);
                }
            }

        }

    }
}
