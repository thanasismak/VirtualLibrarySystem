﻿namespace VLS_BiblionetImportData
{
    public  class MapCommon
    {
        public ImportFiltersFieldMapping FieldName = new ImportFiltersFieldMapping(){LocalFieldName = "Name",RemoteFieldName = "Name",NeedQuote = true};
        public ImportFiltersFieldMapping FieldLastMod= new ImportFiltersFieldMapping() { LocalFieldName = "LastModified",RemoteFieldName = "LastMod",NeedQuote = false,IsDateTime = true};
        public ImportFiltersFieldMapping FieldEmail= new ImportFiltersFieldMapping() { LocalFieldName = "Email",RemoteFieldName = "email",NeedQuote = true};
        public ImportFiltersFieldMapping FieldWebSite=new  ImportFiltersFieldMapping() { LocalFieldName = "WebSite",RemoteFieldName = "WebSite",NeedQuote = true};
                        
 }
}
