﻿using System.Collections.Generic;

namespace VLS_BiblionetImportData
{
    public class MapPersonKinds
    {
        public ImportData Map()
        {
            var importdata = new ImportData
            {
                Importfilters = new ImportFilters()
                {
                    SetOffIdentity = true,
                    Title = "PersonKind",
                    RemoteLoadDataQuery ="select PersonsKindID,PersonsKind1 from [biblionetftp].[BibPerkind] order by PersonsKindID ",
                    RemoteIdFieldName = "PersonsKindID",
                    LocalTableName = "PersonKind",
                    LocalIdFieldName = "PersonKindID",
                    FieldMapping = new List<ImportFiltersFieldMapping>
                    {
                        new ImportFiltersFieldMapping(){LocalFieldName = "PersonKindID",RemoteFieldName = "PersonsKindID"},
                        new ImportFiltersFieldMapping(){LocalFieldName = "Description",RemoteFieldName = "PersonsKind1",NeedQuote = true},
                    }
                }
            };
            return importdata;
        }
    }
}
