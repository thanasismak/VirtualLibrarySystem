USE [master]
GO
/****** Object:  Database [VLS]    Script Date: 02/12/2016 21:41:12 ******/
CREATE DATABASE [VLS]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'VLS', FILENAME = N'C:\Program Files (x86)\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\VLS.mdf' , SIZE = 539904KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'VLS_log', FILENAME = N'C:\Program Files (x86)\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\DATA\VLS_log.ldf' , SIZE = 15993536KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [VLS] SET COMPATIBILITY_LEVEL = 120
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [VLS].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [VLS] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [VLS] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [VLS] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [VLS] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [VLS] SET ARITHABORT OFF 
GO
ALTER DATABASE [VLS] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [VLS] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [VLS] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [VLS] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [VLS] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [VLS] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [VLS] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [VLS] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [VLS] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [VLS] SET  DISABLE_BROKER 
GO
ALTER DATABASE [VLS] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [VLS] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [VLS] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [VLS] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [VLS] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [VLS] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [VLS] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [VLS] SET RECOVERY FULL 
GO
ALTER DATABASE [VLS] SET  MULTI_USER 
GO
ALTER DATABASE [VLS] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [VLS] SET DB_CHAINING OFF 
GO
ALTER DATABASE [VLS] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [VLS] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [VLS] SET DELAYED_DURABILITY = DISABLED 
GO
EXEC sys.sp_db_vardecimal_storage_format N'VLS', N'ON'
GO
USE [VLS]
GO
/****** Object:  FullTextCatalog [search_text]    Script Date: 02/12/2016 21:41:14 ******/
CREATE FULLTEXT CATALOG [search_text]WITH ACCENT_SENSITIVITY = OFF

GO
/****** Object:  UserDefinedFunction [dbo].[GetRandomstring]    Script Date: 02/12/2016 21:41:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE function [dbo].[GetRandomstring](@pStringLength int ) returns nvarchar(max)
as begin
    declare  @RandomString varchar(max);

    with
    a1 as (select 1 as N union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1 union all
           select 1),
    a2 as (select
                1 as N
           from
                a1 as a
                cross join a1 as b),
    a3 as (select
                1 as N
           from
                a2 as a
                cross join a2 as b),
    a4 as (select
                1 as N
           from
                a3 as a
                cross join a2 as b),
    Tally as (select
                row_number() over (order by N) as N
              from
                a4)
    , cteRandomString (
        RandomString
    ) as (
    select top (@pStringLength) substring(x,(abs(checksum((select NewIDValue from ViewGetNewGui)))%36)+1,1)
    from Tally 
		cross join (select x='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ') a
    )
    select @RandomString = replace((select',' + RandomString from cteRandomString for xml path ('')),',','');

    return (@RandomString);
end




GO
/****** Object:  Table [dbo].[Book]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Book](
	[BookId] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](512) NULL,
	[SubTitle] [nvarchar](512) NULL,
	[OriginTitle] [nvarchar](512) NULL,
	[Description] [nvarchar](max) NULL,
	[PublishYear] [int] NULL,
	[PublishMonth] [int] NULL,
	[Pages] [int] NULL,
	[ISBN] [nvarchar](20) NULL,
	[ISBN13] [nvarchar](20) NULL,
	[LastModified] [datetime] NULL,
 CONSTRAINT [PK_Book] PRIMARY KEY CLUSTERED 
(
	[BookId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BookCategory]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookCategory](
	[BookCategoryId] [int] IDENTITY(1,1) NOT NULL,
	[BookId] [int] NOT NULL,
	[CategoryId] [int] NOT NULL,
 CONSTRAINT [PK_BookCategory] PRIMARY KEY CLUSTERED 
(
	[BookCategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BookCompany]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookCompany](
	[BookCompanyId] [int] IDENTITY(1,1) NOT NULL,
	[BookId] [int] NOT NULL,
	[CompanyId] [int] NOT NULL,
	[PersonKindId] [int] NOT NULL,
 CONSTRAINT [PK_BookCompany] PRIMARY KEY CLUSTERED 
(
	[BookCompanyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BookPerson]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookPerson](
	[BookPersonId] [int] IDENTITY(1,1) NOT NULL,
	[BookId] [int] NOT NULL,
	[PersonId] [int] NOT NULL,
	[PersonKindId] [int] NOT NULL,
 CONSTRAINT [PK_BookPerson] PRIMARY KEY CLUSTERED 
(
	[BookPersonId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BookRating]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BookRating](
	[BookRatingId] [int] IDENTITY(1,1) NOT NULL,
	[BookId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[Rating] [int] NOT NULL,
	[InsDate] [datetime] NOT NULL,
 CONSTRAINT [PK_BookRating] PRIMARY KEY CLUSTERED 
(
	[BookRatingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BusinessEntity]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[BusinessEntity](
	[BusinessEntityId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](250) NOT NULL,
 CONSTRAINT [PK_BusinessEntity] PRIMARY KEY CLUSTERED 
(
	[BusinessEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Category]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Category](
	[CategoryId] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](512) NULL,
	[ParentCategoryId] [int] NULL,
	[Code] [nvarchar](200) NULL,
 CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Company]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Company](
	[CompanyId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](512) NULL,
	[Address] [nvarchar](512) NULL,
	[Email] [nvarchar](200) NULL,
	[WebSite] [nvarchar](200) NULL,
	[Phone1] [nvarchar](20) NULL,
	[Phone2] [nvarchar](20) NULL,
	[Phone3] [nvarchar](20) NULL,
	[Fax] [nvarchar](20) NULL,
	[LastModified] [datetime] NULL,
 CONSTRAINT [PK_Company] PRIMARY KEY CLUSTERED 
(
	[CompanyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Library]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Library](
	[LibraryId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](512) NULL,
	[Description] [nvarchar](max) NULL,
	[Address] [nvarchar](512) NULL,
	[Email] [nvarchar](200) NULL,
	[WebSite] [nvarchar](200) NULL,
	[Phone1] [nvarchar](20) NULL,
	[Phone2] [nvarchar](20) NULL,
	[Phone3] [nvarchar](20) NULL,
	[Fax] [nvarchar](20) NULL,
	[Longitude] [float] NULL,
	[Latitude] [float] NULL,
 CONSTRAINT [PK_Library] PRIMARY KEY CLUSTERED 
(
	[LibraryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LibraryBookAvailability]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LibraryBookAvailability](
	[LibraryBookAvailabilityId] [int] IDENTITY(1,1) NOT NULL,
	[LibraryId] [int] NOT NULL,
	[BookId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[QuantityReservation] [int] NOT NULL,
 CONSTRAINT [PK_LibraryBookAvailability] PRIMARY KEY CLUSTERED 
(
	[LibraryBookAvailabilityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Param]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Param](
	[ParamId] [int] IDENTITY(1,1) NOT NULL,
	[Code] [nvarchar](100) NOT NULL,
	[Value] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](512) NULL,
 CONSTRAINT [PK_Param] PRIMARY KEY CLUSTERED 
(
	[ParamId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Person]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Person](
	[PersonId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](200) NOT NULL,
	[Description] [nvarchar](max) NULL,
	[Email] [nvarchar](200) NULL,
	[WebSite] [nvarchar](200) NULL,
	[LastModified] [datetime] NULL,
 CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED 
(
	[PersonId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[PersonKind]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PersonKind](
	[PersonKindId] [int] IDENTITY(1,1) NOT NULL,
	[Description] [nvarchar](512) NULL,
 CONSTRAINT [PK_PersonKind] PRIMARY KEY CLUSTERED 
(
	[PersonKindId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Reservation]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Reservation](
	[ReservationId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[InsDate] [datetime] NOT NULL,
 CONSTRAINT [PK_Reservation] PRIMARY KEY CLUSTERED 
(
	[ReservationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ReservationBook]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ReservationBook](
	[ReservationBookId] [int] IDENTITY(1,1) NOT NULL,
	[ReservationId] [int] NOT NULL,
	[LibraryId] [int] NOT NULL,
	[BookId] [int] NOT NULL,
	[ReservationBookStatus] [int] NOT NULL,
	[Extend] [bit] NOT NULL,
	[ExtendReservationBookId] [int] NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
 CONSTRAINT [PK_ReservationBook] PRIMARY KEY CLUSTERED 
(
	[ReservationBookId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Role]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Role](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](250) NOT NULL,
 CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[RoleBusinessEntity]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RoleBusinessEntity](
	[RoleBusinessEntityId] [int] IDENTITY(1,1) NOT NULL,
	[RoleId] [int] NOT NULL,
	[BusinessEntityId] [int] NOT NULL,
	[PermitView] [bit] NOT NULL,
	[PermitInsert] [bit] NOT NULL,
	[PermitUpdate] [bit] NOT NULL,
	[PermitDelete] [bit] NOT NULL,
 CONSTRAINT [PK_RoleBusinessEntity] PRIMARY KEY CLUSTERED 
(
	[RoleBusinessEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Token]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Token](
	[TokenId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[AuthToken] [nvarchar](512) NOT NULL,
	[IssuedOn] [datetime] NOT NULL,
	[ExpiresOn] [datetime] NOT NULL,
 CONSTRAINT [PK_Tokens] PRIMARY KEY CLUSTERED 
(
	[TokenId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[User]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[User](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](512) NOT NULL,
	[FirstName] [nvarchar](100) NOT NULL,
	[LastName] [nvarchar](100) NOT NULL,
	[Email] [nvarchar](100) NOT NULL,
	[Phone] [nvarchar](100) NULL,
	[MobilePhone] [nvarchar](100) NULL,
	[Address] [nvarchar](200) NULL,
	[City] [nvarchar](200) NULL,
	[Country] [nvarchar](200) NULL,
	[StudentCardNumber] [nvarchar](100) NULL,
	[IsActive] [bit] NOT NULL,
	[RoleId] [int] NOT NULL,
 CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_Book_10_418100530__K1_2]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [_dta_index_Book_10_418100530__K1_2] ON [dbo].[Book]
(
	[BookId] ASC
)
INCLUDE ( 	[Title]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_Book_10_418100530__K1_2_6_7_11]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [_dta_index_Book_10_418100530__K1_2_6_7_11] ON [dbo].[Book]
(
	[BookId] ASC
)
INCLUDE ( 	[Title],
	[PublishYear],
	[PublishMonth],
	[ISBN13]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [_dta_index_BookCompany_10_482100758__K4_K2_K3]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [_dta_index_BookCompany_10_482100758__K4_K2_K3] ON [dbo].[BookCompany]
(
	[PersonKindId] ASC,
	[BookId] ASC,
	[CompanyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [Idx_BookPerson_PersonKind_BookIdPersonId]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [Idx_BookPerson_PersonKind_BookIdPersonId] ON [dbo].[BookPerson]
(
	[PersonKindId] ASC
)
INCLUDE ( 	[BookId],
	[PersonId]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_BookRating]    Script Date: 02/12/2016 21:41:15 ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_BookRating] ON [dbo].[BookRating]
(
	[BookId] ASC,
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_BookRating_Book]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [IX_BookRating_Book] ON [dbo].[BookRating]
(
	[BookId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [_dta_index_Company_10_610101214__K1_2]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [_dta_index_Company_10_610101214__K1_2] ON [dbo].[Company]
(
	[CompanyId] ASC
)
INCLUDE ( 	[Name]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_LibraryBookAvailability]    Script Date: 02/12/2016 21:41:15 ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_LibraryBookAvailability] ON [dbo].[LibraryBookAvailability]
(
	[LibraryId] ASC,
	[BookId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_Person]    Script Date: 02/12/2016 21:41:15 ******/
CREATE NONCLUSTERED INDEX [IX_Person] ON [dbo].[Person]
(
	[PersonId] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ReservationBook_RLB]    Script Date: 02/12/2016 21:41:15 ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_ReservationBook_RLB] ON [dbo].[ReservationBook]
(
	[ReservationId] ASC,
	[LibraryId] ASC,
	[BookId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_User_Email]    Script Date: 02/12/2016 21:41:15 ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_User_Email] ON [dbo].[User]
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_UserName]    Script Date: 02/12/2016 21:41:15 ******/
CREATE UNIQUE NONCLUSTERED INDEX [IX_UserName] ON [dbo].[User]
(
	[UserName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[BookRating] ADD  DEFAULT (getdate()) FOR [InsDate]
GO
ALTER TABLE [dbo].[LibraryBookAvailability] ADD  CONSTRAINT [DF_LibraryBookAvailability_QuantityReservation]  DEFAULT ((0)) FOR [QuantityReservation]
GO
ALTER TABLE [dbo].[Reservation] ADD  CONSTRAINT [DF_Reservation_InsDate]  DEFAULT (getdate()) FOR [InsDate]
GO
ALTER TABLE [dbo].[ReservationBook] ADD  DEFAULT ((0)) FOR [Extend]
GO
ALTER TABLE [dbo].[RoleBusinessEntity] ADD  DEFAULT ((0)) FOR [PermitView]
GO
ALTER TABLE [dbo].[RoleBusinessEntity] ADD  DEFAULT ((0)) FOR [PermitInsert]
GO
ALTER TABLE [dbo].[RoleBusinessEntity] ADD  DEFAULT ((0)) FOR [PermitUpdate]
GO
ALTER TABLE [dbo].[RoleBusinessEntity] ADD  DEFAULT ((0)) FOR [PermitDelete]
GO
ALTER TABLE [dbo].[User] ADD  CONSTRAINT [DF_User_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[BookCategory]  WITH CHECK ADD  CONSTRAINT [FK_BookCategory_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[BookCategory] CHECK CONSTRAINT [FK_BookCategory_Book]
GO
ALTER TABLE [dbo].[BookCategory]  WITH CHECK ADD  CONSTRAINT [FK_BookCategory_Category] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[Category] ([CategoryId])
GO
ALTER TABLE [dbo].[BookCategory] CHECK CONSTRAINT [FK_BookCategory_Category]
GO
ALTER TABLE [dbo].[BookCompany]  WITH CHECK ADD  CONSTRAINT [FK_BookCompany_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[BookCompany] CHECK CONSTRAINT [FK_BookCompany_Book]
GO
ALTER TABLE [dbo].[BookCompany]  WITH CHECK ADD  CONSTRAINT [FK_BookCompany_Company] FOREIGN KEY([CompanyId])
REFERENCES [dbo].[Company] ([CompanyId])
GO
ALTER TABLE [dbo].[BookCompany] CHECK CONSTRAINT [FK_BookCompany_Company]
GO
ALTER TABLE [dbo].[BookCompany]  WITH CHECK ADD  CONSTRAINT [FK_BookCompany_PersonKind] FOREIGN KEY([PersonKindId])
REFERENCES [dbo].[PersonKind] ([PersonKindId])
GO
ALTER TABLE [dbo].[BookCompany] CHECK CONSTRAINT [FK_BookCompany_PersonKind]
GO
ALTER TABLE [dbo].[BookPerson]  WITH CHECK ADD  CONSTRAINT [FK_BookPerson_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[BookPerson] CHECK CONSTRAINT [FK_BookPerson_Book]
GO
ALTER TABLE [dbo].[BookPerson]  WITH CHECK ADD  CONSTRAINT [FK_BookPerson_Person] FOREIGN KEY([PersonId])
REFERENCES [dbo].[Person] ([PersonId])
GO
ALTER TABLE [dbo].[BookPerson] CHECK CONSTRAINT [FK_BookPerson_Person]
GO
ALTER TABLE [dbo].[BookPerson]  WITH CHECK ADD  CONSTRAINT [FK_BookPerson_PersonKind] FOREIGN KEY([PersonKindId])
REFERENCES [dbo].[PersonKind] ([PersonKindId])
GO
ALTER TABLE [dbo].[BookPerson] CHECK CONSTRAINT [FK_BookPerson_PersonKind]
GO
ALTER TABLE [dbo].[BookRating]  WITH CHECK ADD  CONSTRAINT [FK_BookRating_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[BookRating] CHECK CONSTRAINT [FK_BookRating_Book]
GO
ALTER TABLE [dbo].[BookRating]  WITH CHECK ADD  CONSTRAINT [FK_BookRating_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[BookRating] CHECK CONSTRAINT [FK_BookRating_User]
GO
ALTER TABLE [dbo].[Category]  WITH CHECK ADD  CONSTRAINT [FK_Category_Category] FOREIGN KEY([ParentCategoryId])
REFERENCES [dbo].[Category] ([CategoryId])
GO
ALTER TABLE [dbo].[Category] CHECK CONSTRAINT [FK_Category_Category]
GO
ALTER TABLE [dbo].[LibraryBookAvailability]  WITH CHECK ADD  CONSTRAINT [FK_LibraryBookAvailability_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[LibraryBookAvailability] CHECK CONSTRAINT [FK_LibraryBookAvailability_Book]
GO
ALTER TABLE [dbo].[LibraryBookAvailability]  WITH CHECK ADD  CONSTRAINT [FK_LibraryBookAvailability_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([LibraryId])
GO
ALTER TABLE [dbo].[LibraryBookAvailability] CHECK CONSTRAINT [FK_LibraryBookAvailability_Library]
GO
ALTER TABLE [dbo].[Reservation]  WITH CHECK ADD  CONSTRAINT [FK_Reservation_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Reservation] CHECK CONSTRAINT [FK_Reservation_User]
GO
ALTER TABLE [dbo].[ReservationBook]  WITH CHECK ADD  CONSTRAINT [FK_ReservationBook_Book] FOREIGN KEY([BookId])
REFERENCES [dbo].[Book] ([BookId])
GO
ALTER TABLE [dbo].[ReservationBook] CHECK CONSTRAINT [FK_ReservationBook_Book]
GO
ALTER TABLE [dbo].[ReservationBook]  WITH CHECK ADD  CONSTRAINT [FK_ReservationBook_Library] FOREIGN KEY([LibraryId])
REFERENCES [dbo].[Library] ([LibraryId])
GO
ALTER TABLE [dbo].[ReservationBook] CHECK CONSTRAINT [FK_ReservationBook_Library]
GO
ALTER TABLE [dbo].[ReservationBook]  WITH CHECK ADD  CONSTRAINT [FK_ReservationBook_Reservation] FOREIGN KEY([ReservationId])
REFERENCES [dbo].[Reservation] ([ReservationId])
GO
ALTER TABLE [dbo].[ReservationBook] CHECK CONSTRAINT [FK_ReservationBook_Reservation]
GO
ALTER TABLE [dbo].[ReservationBook]  WITH CHECK ADD  CONSTRAINT [FK_ReservationBook_ReservationBook] FOREIGN KEY([ExtendReservationBookId])
REFERENCES [dbo].[ReservationBook] ([ReservationBookId])
GO
ALTER TABLE [dbo].[ReservationBook] CHECK CONSTRAINT [FK_ReservationBook_ReservationBook]
GO
ALTER TABLE [dbo].[RoleBusinessEntity]  WITH CHECK ADD  CONSTRAINT [FK_RoleBusinessEntity_BusinessEntity] FOREIGN KEY([BusinessEntityId])
REFERENCES [dbo].[BusinessEntity] ([BusinessEntityId])
GO
ALTER TABLE [dbo].[RoleBusinessEntity] CHECK CONSTRAINT [FK_RoleBusinessEntity_BusinessEntity]
GO
ALTER TABLE [dbo].[RoleBusinessEntity]  WITH CHECK ADD  CONSTRAINT [FK_RoleEntity_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([RoleId])
GO
ALTER TABLE [dbo].[RoleBusinessEntity] CHECK CONSTRAINT [FK_RoleEntity_Role]
GO
ALTER TABLE [dbo].[Token]  WITH CHECK ADD  CONSTRAINT [FK_Token_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[User] ([UserId])
GO
ALTER TABLE [dbo].[Token] CHECK CONSTRAINT [FK_Token_User]
GO
ALTER TABLE [dbo].[User]  WITH CHECK ADD  CONSTRAINT [FK_User_Role] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Role] ([RoleId])
GO
ALTER TABLE [dbo].[User] CHECK CONSTRAINT [FK_User_Role]
GO
ALTER TABLE [dbo].[LibraryBookAvailability]  WITH CHECK ADD  CONSTRAINT [CK_LibraryBookAvailability_Quantity] CHECK  (([Quantity]>=(0)))
GO
ALTER TABLE [dbo].[LibraryBookAvailability] CHECK CONSTRAINT [CK_LibraryBookAvailability_Quantity]
GO
ALTER TABLE [dbo].[LibraryBookAvailability]  WITH CHECK ADD  CONSTRAINT [CK_LibraryBookAvailability_QuantityReservation] CHECK  (([QuantityReservation]<=[Quantity]))
GO
ALTER TABLE [dbo].[LibraryBookAvailability] CHECK CONSTRAINT [CK_LibraryBookAvailability_QuantityReservation]
GO
ALTER TABLE [dbo].[LibraryBookAvailability]  WITH CHECK ADD  CONSTRAINT [CK_LibraryBookAvailability_QuantityReservationZero] CHECK  (([QuantityReservation]>=(0)))
GO
ALTER TABLE [dbo].[LibraryBookAvailability] CHECK CONSTRAINT [CK_LibraryBookAvailability_QuantityReservationZero]
GO
ALTER TABLE [dbo].[ReservationBook]  WITH CHECK ADD  CONSTRAINT [CK__Reservati__Reser__0E240DFC] CHECK  (([ReservationBookStatus]=(5) OR [ReservationBookStatus]=(4) OR [ReservationBookStatus]=(3) OR [ReservationBookStatus]=(2) OR [ReservationBookStatus]=(1)))
GO
ALTER TABLE [dbo].[ReservationBook] CHECK CONSTRAINT [CK__Reservati__Reser__0E240DFC]
GO
/****** Object:  StoredProcedure [dbo].[UpdReservationBookStatus_Reservation]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UpdReservationBookStatus_Reservation]  @ReservationId int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ReservationBookId int;
	DECLARE @ReservationBookStatus_New int;
	DECLARE @ReservationBookStatus_Reservation int;
	DECLARE @ReservationBookStatus_Failed int;
	DECLARE @ReservationBookStatus_Current int;
	DECLARE @LibraryId int;
	DECLARE @BookId int;
	DECLARE @Quantity int;
	DECLARE @QuantityReservation int;


	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	set @ReservationBookStatus_Reservation=2;--Booked
	set @ReservationBookStatus_Failed=3;--Failed
	set @ReservationBookStatus_New = @ReservationBookStatus_Reservation;

	BEGIN TRY
		BEGIN TRAN MASTERTRAN


		DECLARE CUR CURSOR	
		FOR
			select rb.ReservationBookId,rb.ReservationBookStatus, rb.LibraryId,rb.BookId,lba.Quantity,lba.QuantityReservation
			from ReservationBook rb with (updlock, index(IX_ReservationBook_RLB)),
				 LibraryBookAvailability lba with (updlock,serializable index(IX_LibraryBookAvailability)) 
			where rb.ReservationId=@ReservationId and 
			      lba.LibraryId=rb.LibraryId and lba.BookId=rb.BookId
			      
		OPEN CUR
		FETCH NEXT FROM CUR INTO @ReservationBookId,@ReservationBookStatus_Current,@LibraryId,@BookId,@Quantity,@QuantityReservation
		WHILE @@FETCH_STATUS = 0
		BEGIN
	
			if (@ReservationBookStatus_Current =2)
			begin
				SELECT @ErrorMessage = 'Reservation Invalid Status for  ReservationBook ',@ErrorSeverity = 16,@ErrorState =0;
				RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );
			end;
			
			if (@Quantity>@QuantityReservation)
			begin
				update LibraryBookAvailability with (updlock,serializable) set QuantityReservation=QuantityReservation+1 where LibraryId=@LibraryId and BookId=@BookId
			end
			else
			begin
				set @ReservationBookStatus_New = @ReservationBookStatus_Failed;
				SELECT @ErrorMessage = 'No Availability for BookId :'+cast(@BookId as varchar(10))+' at Library :'+cast(@LibraryId as varchar(10)),@ErrorSeverity = 16,@ErrorState =0;
				RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );
			end;

		FETCH NEXT FROM CUR INTO @ReservationBookId,@ReservationBookStatus_Current,@LibraryId,@BookId,@Quantity,@QuantityReservation
		END	
		CLOSE CUR
		DEALLOCATE CUR

		COMMIT TRAN MASTERTRAN

	END TRY
	BEGIN CATCH

		BEGIN TRY
			CLOSE CUR
			DEALLOCATE CUR
		END TRY
		BEGIN CATCH
		END CATCH

		ROLLBACK TRAN MASTERTRAN	 

		SELECT @ErrorMessage = ERROR_MESSAGE(),@ErrorSeverity = ERROR_SEVERITY(),@ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );

	END CATCH

	update ReservationBook with (updlock,serializable) set ReservationBookStatus=@ReservationBookStatus_New where ReservationId=@ReservationId
END

GO
/****** Object:  StoredProcedure [dbo].[UpdReservationBookStatus_Return]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UpdReservationBookStatus_Return]  @ReservationId int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ReservationBookId int;
	DECLARE @ReservationBookStatus_New int;
	DECLARE @ReservationBookStatus_Current int;
	DECLARE @ReservationBookStatus_Return int;
	DECLARE @LibraryId int;
	DECLARE @BookId int;
	DECLARE @Quantity int;
	DECLARE @QuantityReservation int;


	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @ErrorSeverity INT;
	DECLARE @ErrorState INT;

	set @ReservationBookStatus_Return=5;--Booked
	set @ReservationBookStatus_New = @ReservationBookStatus_Return;

	BEGIN TRY
		BEGIN TRAN MASTERTRAN

		DECLARE CUR CURSOR	
		FOR
			select rb.ReservationBookId,rb.ReservationBookStatus, rb.LibraryId,rb.BookId,lba.Quantity,lba.QuantityReservation
			from ReservationBook rb with (updlock, index(IX_ReservationBook_RLB)),
				 LibraryBookAvailability lba with (updlock,serializable index(IX_LibraryBookAvailability)) 
			where rb.ReservationId=@ReservationId and 
			      lba.LibraryId=rb.LibraryId and lba.BookId=rb.BookId
				      
		OPEN CUR
		FETCH NEXT FROM CUR INTO @ReservationBookId,@ReservationBookStatus_Current,@LibraryId,@BookId,@Quantity,@QuantityReservation
		WHILE @@FETCH_STATUS = 0
		BEGIN
	
			if (@ReservationBookStatus_Current not in (2))
			begin
				SELECT @ErrorMessage = 'Reservation Invalid Status for  Return ',@ErrorSeverity = 16,@ErrorState =0;
				RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );
			end;			
			

			if (@QuantityReservation>0)
			begin
				update LibraryBookAvailability with (updlock,serializable) set QuantityReservation=QuantityReservation-1 where LibraryId=@LibraryId and BookId=@BookId
   			    update ReservationBook with (updlock,serializable) set ReservationBookStatus=@ReservationBookStatus_Return where ReservationBookId=@ReservationBookId
			end
			else
			begin
				SELECT @ErrorMessage = 'Error returning availability  BookId :'+cast(@BookId as varchar(10))+' at Library :'+cast(@LibraryId as varchar(10)),@ErrorSeverity = 16,@ErrorState =0;
				RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );
			end;

		FETCH NEXT FROM CUR INTO @ReservationBookId,@ReservationBookStatus_Current,@LibraryId,@BookId,@Quantity,@QuantityReservation
		END	
		CLOSE CUR
		DEALLOCATE CUR

		COMMIT TRAN MASTERTRAN
	

	END TRY
	BEGIN CATCH

		BEGIN TRY
			CLOSE CUR
			DEALLOCATE CUR
		END TRY
		BEGIN CATCH
		END CATCH

		ROLLBACK TRAN MASTERTRAN	 

		SELECT @ErrorMessage = ERROR_MESSAGE(),@ErrorSeverity = ERROR_SEVERITY(),@ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage,  @ErrorSeverity, @ErrorState );

	END CATCH
END




GO
/****** Object:  StoredProcedure [dbo].[UpdTableStatistics]    Script Date: 02/12/2016 21:41:15 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE procedure [dbo].[UpdTableStatistics]
as

DECLARE updatestats CURSOR FOR
SELECT  table_name FROM information_schema.tables
where TABLE_TYPE = 'BASE TABLE'
OPEN updatestats

DECLARE @schema NVARCHAR(128)
DECLARE @tablename NVARCHAR(128)
DECLARE @Statement NVARCHAR(300)

FETCH NEXT FROM updatestats INTO @tablename
WHILE (@@FETCH_STATUS = 0)
BEGIN
PRINT N'UPDATING STATISTICS ' + @tablename
SET @Statement = 'UPDATE STATISTICS [' + @tablename + '] WITH FULLSCAN'
EXEC sp_executesql @Statement
FETCH NEXT FROM updatestats INTO @tablename
END

CLOSE updatestats
DEALLOCATE updatestats

GO
USE [master]
GO
ALTER DATABASE [VLS] SET  READ_WRITE 
GO
