﻿using VLS_Payment.Models;

namespace VLS_Payment.Service
{
    /// <summary>
    /// 
    /// </summary>
    public class Payment
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="paymentRequest"></param>
        /// <returns></returns>
        public PaymentResponse Pay(PaymentRequest paymentRequest)
        {
            Providers.Viva.VivaPayment vivaPayment = new Providers.Viva.VivaPayment();
            return vivaPayment.Pay(paymentRequest);

        }

    }
}
