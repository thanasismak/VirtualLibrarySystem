﻿using System;
using VLS_Payment.Interfaces;
using VLS_Payment.Models;

namespace VLS_Payment.Providers.Viva
{
    /// <summary>
    /// 
    /// </summary>
    public class VivaPayment: IPayment
    {
        public readonly Guid MerchantId = new Guid("xxxxxxx");
        public const string ApiKey = "xxxxx";
        public const string PublicKey = "xxxx";
        public const string SourceCode = "Default"; //A SourceCode that is set for Native Checkout
        public const string BasePaymentsApiUrl = "http://demo.vivapayments.com";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="paymentRequest"></param>
        /// <returns></returns>
        public PaymentResponse Pay(PaymentRequest paymentRequest)
        {

            int cvv ;
            int expiryMonth = 0;
            int expiryYear = 0;
            if (String.IsNullOrEmpty(paymentRequest.CardHolder) ||string.IsNullOrEmpty(paymentRequest.CardNumber) ||
                    !int.TryParse(paymentRequest.Cvv, out cvv) ||!int.TryParse(paymentRequest.ExpiryMonth, out expiryMonth) ||
                    !int.TryParse(paymentRequest.ExpiryYear, out expiryYear))
            {
                return new PaymentResponse() {
                    Status = "01",
                    Message = "Invalid input"

                };
            }

            var cl = new ApiClient(BasePaymentsApiUrl,MerchantId,ApiKey,PublicKey);

            //CREATE ORDER
            long orderCode = 0;
            var amount = (long)(paymentRequest.Amount * 100);
            var orderResp = cl.CreateOrder(amount, SourceCode);
            if (orderResp != null && orderResp.Data != null)
            {
                if (orderResp.Data.ErrorCode == 0)
                {
                    orderCode = orderResp.Data.OrderCode;
                }
                else
                {
                    return new PaymentResponse()
                    {
                        Status = "02",
                        OrderId = orderCode != null ? orderCode.ToString() : "0",
                        TransactionId = "0",
                        Message =$"Create Order Failed with Error ({orderResp.Data.ErrorCode}){orderResp.Data.ErrorText}"
                    };
                }
            }
            else
            {
                return new PaymentResponse()
                {
                    Status = "03",
                    OrderId = orderCode != null ? orderCode.ToString() : "0",
                    TransactionId = "0",
                    Message = "Create Order failed"

                };
            }

            //CREATE TOKEN
            string token;
            var tokenResp = cl.Tokenize(paymentRequest.CardHolder, paymentRequest.CardNumber, cvv, expiryMonth, expiryYear);
            if (tokenResp.StatusCode == System.Net.HttpStatusCode.OK &&
                tokenResp.Data != null)
            {
                token = tokenResp.Data.Token;
            }
            else
            {
                return new PaymentResponse()
                {
                    Status = "04",
                    OrderId = orderCode != null ? orderCode.ToString() : "0",
                    TransactionId = "0",
                    Message = $"Tokenization Failed with Error ({tokenResp.StatusCode}){tokenResp.StatusDescription}"
                };
            }

            var res = cl.ExecuteTransaction(orderCode, SourceCode, token);
            if (res != null)
            {
                if (res.ErrorCode == 0 && res.StatusId == "F")
                {
                    return new PaymentResponse()
                    {
                        Status = "00",
                        Action = true,
                        OrderId = orderCode != null ? orderCode.ToString() : "0",
                        TransactionId = res.TransactionId != null ? res.TransactionId.ToString() : "0",
                        Message = String.Format(
                        "Transaction was successful ({0})",
                        res.TransactionId)
                     };
                }
                else
                {
 
                    return new PaymentResponse()
                    {
                        Status = "05",
                        OrderId = orderCode != null ? orderCode.ToString() : "0",
                        TransactionId = res.TransactionId != null ? res.TransactionId.ToString() : "0",
                        Message = String.Format(
                        "Transaction failed with Error ({0}){1}",
                        res.ErrorCode,
                        res.ErrorText)
                    };
                }
            }
            else
            {
                return new PaymentResponse()
                {
                    Status = "06",
                    OrderId = orderCode != null ? orderCode.ToString() : "0",
                    TransactionId = "0",
                    Message = "Transaction failed"
                };
            }


        }
    }
}
