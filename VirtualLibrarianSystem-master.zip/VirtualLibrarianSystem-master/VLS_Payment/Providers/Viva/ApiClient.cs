﻿using System;
using RestSharp;
using RestSharp.Authenticators;
using System.Web;

namespace VLS_Payment.Providers.Viva
{
    /// <summary>
    /// 
    /// </summary>
    public class ApiClient
    {
        private readonly string _paymentsCreateOrderUrl = "/api/orders";
        private string _paymentsTokenizeUrl = "/api/cards?key={0}";
        private readonly string _paymentsExecutionUrl = "/api/transactions";
        private readonly string _baseApiUrl;
        private readonly Guid _merchantId;
        private readonly string _apiKey;
        private readonly string _publicKey;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="baseApiUrl"></param>
        /// <param name="merchantId"></param>
        /// <param name="apiKey"></param>
        /// <param name="publicKey"></param>
        public ApiClient(string baseApiUrl, Guid merchantId, string apiKey, string publicKey)
        {
            _baseApiUrl = baseApiUrl;
            _merchantId = merchantId;
            _apiKey = apiKey;
            _publicKey = publicKey;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="sourceCode"></param>
        /// <returns></returns>
        public IRestResponse<OrderResult> CreateOrder(long amount, string sourceCode)
        {
            var cl = new RestClient(_baseApiUrl)
            {
                Authenticator = new HttpBasicAuthenticator(
                    _merchantId.ToString(),
                    _apiKey)
            };

            var req = new RestRequest(_paymentsCreateOrderUrl, Method.POST);

            req.AddObject(new
            {
                Amount = amount,    // Amount is in cents
                SourceCode = sourceCode
            });

            return cl.Execute<OrderResult>(req);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cardHolderName"></param>
        /// <param name="cardNumber"></param>
        /// <param name="cvv"></param>
        /// <param name="expiryMonth"></param>
        /// <param name="expiryYear"></param>
        /// <returns></returns>
        public IRestResponse<TokenizeResult> Tokenize(string cardHolderName, string cardNumber, int cvv, int expiryMonth, int expiryYear)
        {
            var cl = new RestClient(_baseApiUrl);
            _paymentsTokenizeUrl = String.Format(_paymentsTokenizeUrl, HttpUtility.UrlEncode(_publicKey));
            var req = new RestRequest(_paymentsTokenizeUrl, Method.POST);

            req.AddObject(new
            {
                CardHolderName = cardHolderName,
                Number = cardNumber,
                CVC = cvv,
                ExpirationDate = new DateTime(expiryYear, expiryMonth, 15, 0, 0 ,0, DateTimeKind.Utc).ToString("yyyy-MM-dd")
            });

            return cl.Execute<TokenizeResult>(req);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orderCode"></param>
        /// <param name="sourceCode"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public TransactionResult ExecuteTransaction(long orderCode, string sourceCode, string token)
        {
            var cl = new RestClient(_baseApiUrl);
            cl.Authenticator = new HttpBasicAuthenticator(
                                    _merchantId.ToString(),
                                    _apiKey);

            var req = new RestRequest(_paymentsExecutionUrl, Method.POST);
            req.RequestFormat = DataFormat.Json;
            req.AddBody(new
            {
                OrderCode = orderCode,
                SourceCode = sourceCode,             //MAKE SURE THIS IS A SOURCE OF TYPE NATIVE/SIMPLE 
                Installments = 1,
                CreditCard = new
                {
                    Token = token
                }
            });
            var res = cl.Execute<TransactionResult>(req);
            return res.Data;
        }

    }

    /// <summary>
    /// 
    /// </summary>
    public class OrderResult
    {
        /// <summary>
        /// 
        /// </summary>
        public long OrderCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ErrorCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ErrorText { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime TimeStamp { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    public class TokenizeResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string Token {get; set;}
    }

    /// <summary>
    /// 
    /// </summary>
    public class TransactionResult
    {
        /// <summary>
        /// 
        /// </summary>
        public string StatusId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Guid TransactionId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public int ErrorCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ErrorText { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime TimeStamp { get; set; }
    }

}
