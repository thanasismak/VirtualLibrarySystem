﻿using System.Runtime.Serialization;

namespace VLS_Payment.Models
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class PaymentResponse
    {
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public bool Action { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public string OrderId { get; set; }
        [DataMember]
        public string TransactionId { get; set; }
    }
}
