﻿using System.Runtime.Serialization;

namespace VLS_Payment.Models
{
    [DataContract]
    public class PaymentRequest
    {
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public string CardNumber { get; set; }
        [DataMember]
        public string CardHolder { get; set; }
        [DataMember]
        public string Cvv { get; set; }
        [DataMember]
        public string ExpiryMonth { get; set; }
        [DataMember]
        public string ExpiryYear { get; set; }
        [DataMember]
        public int Intallments { get; set; } = 1;
        [DataMember]
        public double Amount { get; set; }
    }
}
