﻿using VLS_Payment.Models;

namespace VLS_Payment.Interfaces
{
    public interface IPayment
    {
         PaymentResponse Pay(PaymentRequest paymentRequest);
    }
}
