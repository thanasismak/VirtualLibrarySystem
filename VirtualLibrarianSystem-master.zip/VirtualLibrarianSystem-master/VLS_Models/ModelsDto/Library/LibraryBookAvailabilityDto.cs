﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Library
{
    [DataContract]
    public class LibraryBookAvailabilityDto
    {
        [DataMember]
        public int? LibraryBookAvailabilityId { get; set; }
        [DataMember]
        public int? LibraryId { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public int? Quantity { get; set; }

    }
}
