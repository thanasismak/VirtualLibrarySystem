﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class PersonDto
    {
        [DataMember]
        public int? PersonId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string WebSite { get; set; }
    }
}
