﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookAvailabilityDto
    {
        [DataMember]
        public int? LibraryId { get; set; }
        [DataMember]
        public double? Longitude { get; set; }
        [DataMember]
        public double? Latitude { get; set; }
        [DataMember]
        public string LibraryName { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public string BookTitle { get; set; }
        [DataMember]
        public int? Quantity { get; set; }
        [DataMember]
        public int? QuantityAvailable { get; set; }
    }
}
