﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookCompanyDto
    {
        [DataMember]
        public int? BookCompanyId { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public int? CompanyId { get; set; }
        [DataMember]
        public int? PersonKindId { get; set; }
        [DataMember]
        public string PersonKindDescription { get; set; }
        [DataMember]
        public string CompanyName { get; set; }

    }
}
