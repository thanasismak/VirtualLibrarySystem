﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookSearchResultDto
    {
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public string BookTitle { get; set; }
        [DataMember]
        public string BookDescription { get; set; }
        [DataMember]
        public string PersonName { get; set; }
        [DataMember]
        public string PersonKindDescription { get; set; }
        [DataMember]
        public int? PublishYear { get; set; }
        [DataMember]
        public int? PublishMonth { get; set; }
        [DataMember]
        public string Isbn13 { get; set; }
        [DataMember]
        public string CompanyName { get; set; }
        [DataMember]
        public string CategoriesDescription { get; set; }
        [DataMember]
        public int Rating { get; set; }
        [DataMember]
        public int? TotalRows { get; set; }
    }
}
