﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookDto
    {
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string SubTitle { get; set; }
        [DataMember]
        public string OriginTitle { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public int? PublishYear { get; set; }
        [DataMember]
        public int? PublishMonth { get; set; }
        [DataMember]
        public int? Pages { get; set; }
        [DataMember]
        public string Isbn { get; set; }
        [DataMember]
        public string Isbn13 { get; set; }
    }
}
