﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookPersonDto
    {
        [DataMember]
        public int? BookPersonId { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public int? PersonId { get; set; }
        [DataMember]
        public int? PersonKindId { get; set; }
        [DataMember]
        public string PersonName { get; set; }
        [DataMember]
        public string PersonKindDescription { get; set; }
    }
}
