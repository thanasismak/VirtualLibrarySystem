﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookRatingDto
    {
        [DataMember]
        public int? BookRatingId { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public int? UserId { get; set; }
        [DataMember]
        public int? Rating { get; set; }
        [DataMember]
        public System.DateTime? InsDate { get; set; }
    }
}
