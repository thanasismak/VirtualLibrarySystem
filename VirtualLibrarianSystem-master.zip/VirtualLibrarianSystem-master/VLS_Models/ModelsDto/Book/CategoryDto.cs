﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class CategoryDto
    {
        [DataMember]
        public int? CategoryId { get; set; }
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public int? ParentCategoryId { get; set; }
    }
}
