﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class PersonKindDto
    {
        [DataMember]
        public int? PersonKindId { get; set; }
        [DataMember]
        public string Description { get; set; }
    }
}
