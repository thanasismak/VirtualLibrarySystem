﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Book
{
    [DataContract]
    public class BookCategoryDto
    {
        [DataMember]
        public int? BookCategoryId { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public int? CategoryId { get; set; }
        [DataMember]
        public string CategoryDescription { get; set; }

    }
}
