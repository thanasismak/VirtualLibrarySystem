﻿using System;
using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Reservation
{
    [DataContract]
    public class ReservationBookDto
    {
        [DataMember]
        public int? ReservationBookId { get; set; }
        [DataMember]
        public int? ReservationId { get; set; }
        [DataMember]
        public int? LibraryId { get; set; }
        [DataMember]
        public string LibraryName { get; set; }
        [DataMember]
        public int? BookId { get; set; }
        [DataMember]
        public string BookTitle { get; set; }
        [DataMember]
        public DateTime? StartDate { get; set; }
        [DataMember]
        public DateTime? EndDate { get; set; }
        [DataMember]
        public int? ReservationBookStatus { get; set; }
        [DataMember]
        public bool? Extend { get; set; }
        [DataMember]
        public int? ExtendReservationBookId { get; set; }

    }
}
