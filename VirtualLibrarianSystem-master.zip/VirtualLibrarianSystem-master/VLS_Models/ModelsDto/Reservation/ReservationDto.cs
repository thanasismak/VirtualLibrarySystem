﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Reservation
{
    [DataContract]
    public class ReservationDto
    {
        [DataMember]
        public int? ReservationId { get; set; }
        [DataMember]
        public int? UserId { get; set; }
        [DataMember]
        public DateTime? InsDate { get; set; }
        [DataMember]
        public List<ReservationBookDto> ReservationBooks { get; set; }
    }
}
