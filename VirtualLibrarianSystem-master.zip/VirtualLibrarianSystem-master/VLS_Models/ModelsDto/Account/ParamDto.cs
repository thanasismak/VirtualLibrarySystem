﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Account
{
    [DataContract]
    public class ParamDto
    {
        [DataMember]
        public int? ParamId { get; set; }
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string Value { get; set; }
        [DataMember]
        public string Description { get; set; }
    }
}
