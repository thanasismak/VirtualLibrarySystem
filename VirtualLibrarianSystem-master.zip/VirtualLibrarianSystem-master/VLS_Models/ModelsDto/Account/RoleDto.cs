﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Account
{
    [DataContract]
    public class RoleDto
    {
        [DataMember]
        public int? RoleId { get; set; }
        [DataMember]
        public string Name { get; set; }

    }
}
