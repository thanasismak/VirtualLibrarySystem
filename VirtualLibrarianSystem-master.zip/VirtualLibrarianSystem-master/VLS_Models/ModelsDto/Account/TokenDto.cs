﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Account
{
    [DataContract]
    public class TokenDto
    {
        [DataMember]
        public int? TokenId { get; set; }
        [DataMember]
        public int? UserId { get; set; }
        [DataMember]
        public string UserName { get; set; }
        [DataMember]
        public string AuthToken { get; set; }
        [DataMember]
        public System.DateTime? IssuedOn { get; set; }
        [DataMember]
        public System.DateTime? ExpiresOn { get; set; }
    }

}