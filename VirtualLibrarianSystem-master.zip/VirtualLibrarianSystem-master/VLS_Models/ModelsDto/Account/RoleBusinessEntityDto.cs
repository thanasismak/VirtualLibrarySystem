﻿using System.Runtime.Serialization;

namespace VLS_Models.ModelsDto.Account
{
    [DataContract]
    public class RoleBusinessEntityDto
    {
        [DataMember]
        public int? RoleBusinessEntityId { get; set; }
        [DataMember]
        public int? RoleId { get; set; }
        [DataMember]
        public int? BusinessEntityId { get; set; }
        [DataMember]
        public bool? PermitView { get; set; }
        [DataMember]
        public bool? PermitInsert { get; set; }
        [DataMember]
        public bool? PermitUpdate { get; set; }
        [DataMember]
        public bool? PermitDelete { get; set; }
        [DataMember]
        public string BusinessEntityName { get; set; }
        [DataMember]
        public string RoleName { get; set; }

    }
}
