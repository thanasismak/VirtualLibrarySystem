﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Interfaces.Services.Account;

namespace VLS_BusinessLayer.Services.Account
{
    public class RoleBusinessEntityService : IRoleBusinessEntityService, IDisposable
    {
        private readonly IRoleBusinessEntity _repo;

        public RoleBusinessEntityService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IRoleBusinessEntity>();
        }


        public async Task<List<RoleBusinessEntityDto>> GetById(int roleBusinessEntityid)
        {
            return await _repo.Get(new RoleBusinessEntityDto() { RoleBusinessEntityId = roleBusinessEntityid  });
        }

        public async Task<List<RoleBusinessEntityDto>> Get(RoleBusinessEntityDto filtersRoleBusinessEntity)
        {
            return await _repo.Get(filtersRoleBusinessEntity);
        }

        public async Task<int> Insert(RoleBusinessEntityDto newRoleBusinessEntity)
        {
            return await _repo.Insert(newRoleBusinessEntity);
        }

        public async Task<int> Update(int updRoleBusinessEntityId, RoleBusinessEntityDto updRoleBusinessEntity)
        {
            return await _repo.Update(updRoleBusinessEntityId, updRoleBusinessEntity);
        }

        public async Task<int> Delete(int delRoleBusinessEntityId)
        {
            return await _repo.Delete(delRoleBusinessEntityId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion


    }
}
