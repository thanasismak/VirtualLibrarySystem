﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Interfaces.Services.Account;

namespace VLS_BusinessLayer.Services.Account
{
    public class TokenService : ITokenService, IDisposable
    {
        private readonly IToken _repo;

        public TokenService()
        {
             var assembly = new AssemblyManager() ;
            _repo = assembly.GetDataAccessRepository<IToken>();
        }

        public async Task<TokenDto> GenerateToken(int userId)
        {
            var token = Guid.NewGuid().ToString();
            var issuedOn = DateTime.Now;
            var expiredOn = DateTime.Now.AddSeconds(Convert.ToDouble(ConfigurationManager.AppSettings["AuthTokenExpiry"]));
            var newtoken = new TokenDto {UserId = userId, AuthToken = token, IssuedOn = issuedOn, ExpiresOn = expiredOn};

            await _repo.Insert(newtoken);
            return newtoken;
        }

        public async Task<bool> ValidateToken(string authToken)
        {
            var tokens = await _repo.Get(new TokenDto() {AuthToken = authToken});
            var token = tokens.FirstOrDefault();

            if (token == null || (DateTime.Now > token.ExpiresOn))
                return false;

            token.ExpiresOn =token.ExpiresOn.GetValueOrDefault().AddSeconds(Convert.ToDouble(ConfigurationManager.AppSettings["AuthTokenExpiry"]));
            return await _repo.Update(token.TokenId.GetValueOrDefault(), token) > 0;
        }


        public async Task<List<TokenDto>> GetById(int tokenId)
        {
            return await _repo.Get(new TokenDto() {TokenId = tokenId });
        }

        public async Task<List<TokenDto>> Get(TokenDto filtersToken)
        {
            return await _repo.Get(filtersToken);
        }

        public async Task<int> Insert(TokenDto newToken)
        {
            return await _repo.Insert(newToken);
        }

        public async Task<int> Update(int updTokenId, TokenDto updToken)
        {
            return await _repo.Update(updTokenId, updToken);
        }

        public async Task<int> Delete(int delTokenId)
        {
            return await _repo.Delete(delTokenId);
        }

        #region IDisposable
        private bool _disposedValue; 

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}