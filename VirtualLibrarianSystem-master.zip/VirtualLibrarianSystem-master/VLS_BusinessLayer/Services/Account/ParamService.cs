﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_BusinessLayer.Interfaces.Services.Account;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Services.Account
{
    public class ParamService : IParamService,IDisposable
    {
        private readonly IParam _repo;

        public ParamService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IParam>();
        }

        public async Task<string> GetValueByCode(string code)
        {
            var data = await _repo.Get(new ParamDto() {Code = code});
            return data.FirstOrDefault()?.Value;
        }

        public async Task<List<ParamDto>> GetById(int paramid)
        {
            return await _repo.Get(new ParamDto() { ParamId = paramid  });
        }

        public async Task<List<ParamDto>> Get(ParamDto filtersParam)
        {
            return await _repo.Get(filtersParam);
        }

        public async Task<int> Insert(ParamDto newParam)
        {
            return await _repo.Insert(newParam);
        }

        public async Task<int> Update(int updParamId, ParamDto updParam)
        {
            return await _repo.Update(updParamId, updParam);
        }

        public async Task<int> Delete(int delParamId)
        {
            return await _repo.Delete(delParamId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}
