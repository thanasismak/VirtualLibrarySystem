﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Interfaces.Services.Account;

namespace VLS_BusinessLayer.Services.Account
{
    public class UserService : IUserService,IDisposable
    {
        private readonly IUser _repo;

        public UserService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IUser>();
        }

        public async Task<bool> CheckAuthorization(int userId, string businessEntity, string businessEntityAction)
        {
            return await _repo.CheckAuthorization(userId, businessEntity, businessEntityAction);
        }

        public async Task<int> Authenticate(string userName, string password)
        {
            var users = await _repo.Get(new UserDto() {UserName = userName, Password = password});
            var user = users.FirstOrDefault();
            if (user != null && user.UserId > 0)
                return user.UserId ?? -1;
            return -1;
        }
        public async Task<int> Register(UserDto newUser)
        {
            string paramvalue;
            using (var paramservice = new ParamService())
                paramvalue = await paramservice.GetValueByCode("DefaultUserRole");
            newUser.IsActive = true;
            newUser.RoleId = Convert.ToInt32(paramvalue);
            return await _repo.Insert(newUser);
        }
        
        public async Task<List<UserDto>> GetById(int userId)
        {
            return await _repo.Get(new UserDto() {UserId = userId });
        }

        public async Task<List<UserDto>> Get(UserDto filtersUser)
        {
            return await _repo.Get(filtersUser);
        }

        public async Task<int> Insert(UserDto newUser)
        {
            return await _repo.Insert(newUser);
        }

        public async Task<int> Update(int updUserId, UserDto updUser)
        {
            return await _repo.Update(updUserId, updUser);
        }

        public async Task<int> Delete(int delUserId)
        {
            return await _repo.Delete(delUserId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}
