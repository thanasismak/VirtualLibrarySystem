﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Interfaces.Services.Account;

namespace VLS_BusinessLayer.Services.Account
{
    public class RoleService : IRoleService, IDisposable
    {
        private readonly IRole _repo;

        public RoleService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IRole>();
        }

        public async Task<List<RoleDto>> GetById(int roleid)
        {
            return await _repo.Get(new RoleDto() {RoleId = roleid});
        }

        public async Task<List<RoleDto>> Get(RoleDto filtersRole)
        {
            return await _repo.Get(filtersRole);
        }

        public async Task<int> Insert(RoleDto newRole)
        {
            return await _repo.Insert(newRole);
        }

        public async Task<int> Update(int updRoleId, RoleDto updRole)
        {
            return await _repo.Update(updRoleId, updRole);
        }

        public async Task<int> Delete(int delRoleId)
        {
            return await _repo.Delete(delRoleId);
        }

        #region IDisposable

        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    IDisposable disposable = _repo as IDisposable;
                    disposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}