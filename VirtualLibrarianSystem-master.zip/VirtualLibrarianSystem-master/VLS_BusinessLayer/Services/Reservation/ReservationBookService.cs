﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Reservation;
using VLS_Models.ModelsDto.Reservation;
using VLS_BusinessLayer.Interfaces.Services.Reservation;

namespace VLS_BusinessLayer.Services.Reservation
{
    public class ReservationBookService : IReservationBookService, IDisposable
    {
        private readonly IReservationBook _repo;

        public ReservationBookService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IReservationBook>();
        }

        public async Task<List<ReservationBookDto>> GetById(int reservationBookId)
        {
            return await _repo.Get(new ReservationBookDto() {ReservationBookId = reservationBookId });
        }

        public async Task<List<ReservationBookDto>> Get(ReservationBookDto filtersReservationBook)
        {
            return await _repo.Get(filtersReservationBook);
        }

        public async Task<int> Insert(ReservationBookDto newReservationBook)
        {
            newReservationBook.ReservationBookStatus = null;
            return await _repo.Insert(newReservationBook);
        }

        public async Task<int> Update(int updReservationBookId, ReservationBookDto updReservationBook)
        {
            var reservationBook = (await _repo.Get(new ReservationBookDto() { ReservationBookId = updReservationBookId })).FirstOrDefault();
            if (reservationBook == null) return 0;
            if ((reservationBook.ReservationBookStatus.GetValueOrDefault() == 2) && (!updReservationBook.Extend.GetValueOrDefault()))
                throw new Exception("Update of ReservationBook book with status 'ReservationBook' is not allowed");
            return await _repo.Update(updReservationBookId, updReservationBook);
        }

        public async Task<int> Delete(int delReservationBookId)
        {
            var reservationBook = (await _repo.Get(new ReservationBookDto() {ReservationBookId = delReservationBookId})).FirstOrDefault();
            if (reservationBook == null) return 0;
            if (reservationBook.ReservationBookStatus.GetValueOrDefault() == 2)
                throw new Exception("Deletion of ReservationBook book with status 'ReservationBook' is not allowed");
            return await _repo.Delete(delReservationBookId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}