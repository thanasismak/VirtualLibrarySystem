﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Reservation;
using VLS_Models.ModelsDto.Reservation;
using VLS_BusinessLayer.Interfaces.Services.Reservation;
using VLS_BusinessLayer.Services.Account;

namespace VLS_BusinessLayer.Services.Reservation
{
    public class ReservationService : IReservationService, IDisposable
    {
        private readonly IReservation _repo;

        public ReservationService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IReservation>();
        }

        public async Task<int> UserNewReservation(ReservationDto newReservation)
        {
            string paramvalue;
            using (var paramservice = new ParamService())
                paramvalue = await paramservice.GetValueByCode("LoanDays");

            foreach (var book in newReservation.ReservationBooks)
            {
                book.ReservationBookStatus = (int) EnumBookingStatus.Pending;
                book.EndDate = book.StartDate.GetValueOrDefault().AddDays(Convert.ToInt32(paramvalue));
            }

            var newid = await _repo.Insert(newReservation);
            await _repo.UpdateReservationBookStatus_Reservation(newid);

            return newid;
        }

        public async Task<int> UserExtendReservation(ReservationDto extendReservation)
        {
            var newcount = 0;
            foreach (var bookforextend in extendReservation.ReservationBooks)
            {
                using (var reservationbookrepo = new ReservationBookService())
                {
                    var bookfromextend = (await reservationbookrepo.GetById(bookforextend.ExtendReservationBookId.GetValueOrDefault())).FirstOrDefault();
                    if (bookfromextend != null)
                    {
                        string paramvalue;
                        using (var paramservice = new ParamService())
                            paramvalue = await paramservice.GetValueByCode("LoanDays");

                        bookforextend.Extend = false;
                        bookforextend.ExtendReservationBookId = null;
                        bookforextend.ReservationBookStatus = (int) EnumBookingStatus.Booked;
                        bookforextend.EndDate = bookforextend.StartDate.GetValueOrDefault().AddDays(Convert.ToInt32(paramvalue));
                        var newid = await _repo.Insert(extendReservation);
                        if (newid > 0)
                        {
                            var newreservation = (await _repo.Get(new ReservationDto() {ReservationId = newid})).FirstOrDefault();
                            var newreservationbook = newreservation?.ReservationBooks.FirstOrDefault(r => r.LibraryId == bookforextend.LibraryId & r.BookId == bookforextend.BookId);
                            if (newreservationbook == null) continue;
                            bookfromextend.ReservationBookStatus = (int) EnumBookingStatus.Return;
                            bookfromextend.Extend = true;
                            bookfromextend.ExtendReservationBookId =newreservationbook.ReservationBookId.GetValueOrDefault();
                            await reservationbookrepo.Update(bookfromextend.ReservationBookId.GetValueOrDefault(), bookfromextend);
                        }
                    }
                }
            }
            return newcount;
        }

        public async Task<List<ReservationDto>> GetById(int reservationId)
        {
            return await _repo.Get(new ReservationDto() {ReservationId = reservationId });
        }

        public async Task<List<ReservationDto>> Get(ReservationDto filtersReservation)
        {
            return await _repo.Get(filtersReservation);
        }

        public async Task UpdateReservationBookStatus_Reservation(int reservationId)
        {
            await _repo.UpdateReservationBookStatus_Reservation(reservationId);
        }

        public async Task UpdateReservationBookStatus_Return(int reservationId)
        {
            await _repo.UpdateReservationBookStatus_Return(reservationId);
        }

        public async Task<int> Insert(ReservationDto newReservation)
        {
            foreach (var book in newReservation.ReservationBooks)
                book.ReservationBookStatus = null;

            return await _repo.Insert(newReservation);
        }

        public async Task<int> Update(int updReservationId, ReservationDto updReservation)
        {
            var reservation = (await _repo.Get(new ReservationDto() { ReservationId = updReservationId })).FirstOrDefault();
            if (reservation == null) return 0;
            if (reservation.ReservationBooks.Any(b => b.ReservationBookStatus.GetValueOrDefault() == 2 && !b.Extend.GetValueOrDefault() ))
                throw new Exception("Update of reservation book with status 'Reservation' is not allowed");
            return await _repo.Update(updReservationId, updReservation);
        }

        public async Task<int> Delete(int delReservationId)
        {
            var reservation = (await _repo.Get(new ReservationDto() {ReservationId = delReservationId})).FirstOrDefault();
            if (reservation == null) return 0;
            if (reservation.ReservationBooks.Any(b=>b.ReservationBookStatus.GetValueOrDefault() == 2))
                throw new Exception("Deletion of reservation book with status 'Reservation' is not allowed");
            return await _repo.Delete(delReservationId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}