﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookService : IBookService, IDisposable
    {
        private readonly IBook _repo;

        public BookService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBook>();
        }

        public async Task<List<BookDto>> GetById(int bookId)
        {
            return await _repo.Get(new BookDto() {BookId = bookId });
        }

        public async Task<List<BookDto>> Get(BookDto filtersBook)
        {
            return await _repo.Get(filtersBook);
        }

        public async Task<int> Insert(BookDto newBook)
        {
            return await _repo.Insert(newBook);
        }

        public async Task<int> Update(int updBookId, BookDto updBook)
        {
            return await _repo.Update(updBookId, updBook);
        }

        public async Task<int> Delete(int delBookId)
        {
            return await _repo.Delete(delBookId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}