﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class CompanyService : ICompanyService, IDisposable
    {
        private readonly ICompany _repo;

        public CompanyService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<ICompany>();
        }

        public async Task<List<CompanyDto>> GetById(int companyId)
        {
            return await _repo.Get(new CompanyDto() {CompanyId = companyId });
        }

        public async Task<List<CompanyDto>> Get(CompanyDto filtersCompany)
        {
            return await _repo.Get(filtersCompany);
        }

        public async Task<int> Insert(CompanyDto newCompany)
        {
            return await _repo.Insert(newCompany);
        }

        public async Task<int> Update(int updCompanyId, CompanyDto updCompany)
        {
            return await _repo.Update(updCompanyId, updCompany);
        }

        public async Task<int> Delete(int delCompanyId)
        {
            return await _repo.Delete(delCompanyId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}