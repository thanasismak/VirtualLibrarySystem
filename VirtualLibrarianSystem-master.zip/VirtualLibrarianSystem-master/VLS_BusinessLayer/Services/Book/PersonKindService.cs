﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class PersonKindService : IPersonKindService, IDisposable
    {
        private readonly IPersonKind _repo;

        public PersonKindService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IPersonKind>();
        }

        public async Task<List<PersonKindDto>> GetById(int personKindId)
        {
            return await _repo.Get(new PersonKindDto() {PersonKindId = personKindId });
        }

        public async Task<List<PersonKindDto>> Get(PersonKindDto filtersPersonKind)
        {
            return await _repo.Get(filtersPersonKind);
        }

        public async Task<int> Insert(PersonKindDto newPersonKind)
        {
            return await _repo.Insert(newPersonKind);
        }

        public async Task<int> Update(int updPersonKindId, PersonKindDto updPersonKind)
        {
            return await _repo.Update(updPersonKindId, updPersonKind);
        }

        public async Task<int> Delete(int delPersonKindId)
        {
            return await _repo.Delete(delPersonKindId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}