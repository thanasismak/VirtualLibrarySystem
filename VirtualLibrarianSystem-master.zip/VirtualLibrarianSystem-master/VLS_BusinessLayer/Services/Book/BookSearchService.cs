﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookSearchService : IBookSearchService, IDisposable
    {
        private readonly IBookSearch _repo;

        public BookSearchService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBookSearch>(true);
        }

        public async Task<List<BookSearchResultDto>> GetByValue(EnumBookSearchField bookSearchfield,string keyword, int pageIndex)
        {
            return await _repo.GetByValue(bookSearchfield,keyword, pageIndex);
        }

        public async Task<List<BookSearchResultDto>> GetByPerson(int personKindId, string keyword, int pageIndex)
        {
            return await _repo.GetByPerson(personKindId,keyword, pageIndex);
        }

        public async Task<List<BookSearchResultDto>> GetById(int bookId)
        {
            return await _repo.GetById(bookId);
        }

        public async Task<List<BookAvailabilityDto>> GetBookAvailability(int bookId)
        {
            return await _repo.GetBookAvailability(bookId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}