﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class CategoryService : ICategoryService, IDisposable
    {
        private readonly ICategory _repo;

        public CategoryService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<ICategory>();
        }

        public async Task<List<CategoryDto>> GetById(int categoryId)
        {
            return await _repo.Get(new CategoryDto() {CategoryId = categoryId });
        }

        public async Task<List<CategoryDto>> Get(CategoryDto filtersCategory)
        {
            return await _repo.Get(filtersCategory);
        }

        public async Task<int> Insert(CategoryDto newCategory)
        {
            return await _repo.Insert(newCategory);
        }

        public async Task<int> Update(int updCategoryId, CategoryDto updCategory)
        {
            return await _repo.Update(updCategoryId, updCategory);
        }

        public async Task<int> Delete(int delCategoryId)
        {
            return await _repo.Delete(delCategoryId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}