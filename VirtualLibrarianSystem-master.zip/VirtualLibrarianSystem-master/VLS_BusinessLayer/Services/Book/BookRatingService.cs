﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookRatingService : IBookRatingService, IDisposable
    {
        private readonly IBookRating _repo;

        public BookRatingService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBookRating>();
        }

        public async Task<List<BookRatingDto>> GetById(int bookRatingId)
        {
            return await _repo.Get(new BookRatingDto() {BookRatingId = bookRatingId });
        }

        public async Task<List<BookRatingDto>> Get(BookRatingDto filtersBookRating)
        {
            return await _repo.Get(filtersBookRating);
        }

        public async Task<int> Insert(BookRatingDto newBookRating)
        {
            return await _repo.Insert(newBookRating);
        }

        public async Task<int> Update(int updBookRatingId, BookRatingDto updBookRating)
        {
            return await _repo.Update(updBookRatingId, updBookRating);
        }

        public async Task<int> Delete(int delBookRatingId)
        {
            return await _repo.Delete(delBookRatingId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}