﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookPersonService : IBookPersonService, IDisposable
    {
        private readonly IBookPerson _repo;

        public BookPersonService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBookPerson>();
        }

        public async Task<List<BookPersonDto>> GetById(int bookPersonId)
        {
            return await _repo.Get(new BookPersonDto() {BookPersonId = bookPersonId });
        }

        public async Task<List<BookPersonDto>> Get(BookPersonDto filtersBookPerson)
        {
            return await _repo.Get(filtersBookPerson);
        }

        public async Task<int> Insert(BookPersonDto newBookPerson)
        {
            return await _repo.Insert(newBookPerson);
        }

        public async Task<int> Update(int updBookPersonId, BookPersonDto updBookPerson)
        {
            return await _repo.Update(updBookPersonId, updBookPerson);
        }

        public async Task<int> Delete(int delBookPersonId)
        {
            return await _repo.Delete(delBookPersonId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}