﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class PersonService : IPersonService, IDisposable
    {
        private readonly IPerson _repo;

        public PersonService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IPerson>();
        }

        public async Task<List<PersonDto>> GetById(int personId)
        {
            return await _repo.Get(new PersonDto() {PersonId = personId });
        }

        public async Task<List<PersonDto>> Get(PersonDto filtersPerson)
        {
            return await _repo.Get(filtersPerson);
        }

        public async Task<int> Insert(PersonDto newPerson)
        {
            return await _repo.Insert(newPerson);
        }

        public async Task<int> Update(int updPersonId, PersonDto updPerson)
        {
            return await _repo.Update(updPersonId, updPerson);
        }

        public async Task<int> Delete(int delPersonId)
        {
            return await _repo.Delete(delPersonId);
        }


        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}