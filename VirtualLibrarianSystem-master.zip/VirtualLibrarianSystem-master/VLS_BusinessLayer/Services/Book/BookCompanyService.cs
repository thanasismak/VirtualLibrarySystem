﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookCompanyService : IBookCompanyService, IDisposable
    {
        private readonly IBookCompany _repo;

        public BookCompanyService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBookCompany>();
        }

        public async Task<List<BookCompanyDto>> GetById(int bookCompanyId)
        {
            return await _repo.Get(new BookCompanyDto() {BookCompanyId = bookCompanyId });
        }

        public async Task<List<BookCompanyDto>> Get(BookCompanyDto filtersBookCompany)
        {
            return await _repo.Get(filtersBookCompany);
        }

        public async Task<int> Insert(BookCompanyDto newBookCompany)
        {
            return await _repo.Insert(newBookCompany);
        }

        public async Task<int> Update(int updBookCompanyId, BookCompanyDto updBookCompany)
        {
            return await _repo.Update(updBookCompanyId, updBookCompany);
        }

        public async Task<int> Delete(int delBookCompanyId)
        {
            return await _repo.Delete(delBookCompanyId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}