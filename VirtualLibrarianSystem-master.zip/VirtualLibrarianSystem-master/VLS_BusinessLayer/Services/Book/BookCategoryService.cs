﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_BusinessLayer.Interfaces.Services.Book;

namespace VLS_BusinessLayer.Services.Book
{
    public class BookCategoryService : IBookCategoryService, IDisposable
    {
        private readonly IBookCategory _repo;

        public BookCategoryService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<IBookCategory>();
        }

        public async Task<List<BookCategoryDto>> GetById(int bookCategoryid)
        {
            return await _repo.Get(new BookCategoryDto() {BookCategoryId = bookCategoryid });
        }

        public async Task<List<BookCategoryDto>> Get(BookCategoryDto filtersBookCategory)
        {
            return await _repo.Get(filtersBookCategory);
        }

        public async Task<int> Insert(BookCategoryDto newBookCategory)
        {
            return await _repo.Insert(newBookCategory);
        }

        public async Task<int> Update(int updBookCategoryId, BookCategoryDto updBookCategory)
        {
            return await _repo.Update(updBookCategoryId, updBookCategory);
        }

        public async Task<int> Delete(int delBookCategoryId)
        {
            return await _repo.Delete(delBookCategoryId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}