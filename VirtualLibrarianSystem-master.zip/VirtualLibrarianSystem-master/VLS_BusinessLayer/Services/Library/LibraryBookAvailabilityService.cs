﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Library;
using VLS_Models.ModelsDto.Library;
using VLS_BusinessLayer.Interfaces.Services.Library;

namespace VLS_BusinessLayer.Services.Library
{
    public class LibraryBookAvailabilityService : ILibraryBookAvailabilityService, IDisposable
    {
        private readonly ILibraryBookAvailability _repo;

        public LibraryBookAvailabilityService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<ILibraryBookAvailability>();
        }

        public async Task<List<LibraryBookAvailabilityDto>> GetById(int libraryBookAvailabilityId)
        {
            return await _repo.Get(new LibraryBookAvailabilityDto() {LibraryBookAvailabilityId = libraryBookAvailabilityId });
        }

        public async Task<List<LibraryBookAvailabilityDto>> Get(LibraryBookAvailabilityDto filtersLibraryBookAvailability)
        {
            return await _repo.Get(filtersLibraryBookAvailability);
        }

        public async Task<int> Insert(LibraryBookAvailabilityDto newLibraryBookAvailability)
        {
            return await _repo.Insert(newLibraryBookAvailability);
        }

        public async Task<int> Update(int updLibraryBookAvailabilityId, LibraryBookAvailabilityDto updLibraryBookAvailability)
        {
            return await _repo.Update(updLibraryBookAvailabilityId, updLibraryBookAvailability);
        }

        public async Task<int> Delete(int delLibraryBookAvailabilityId)
        {
            return await _repo.Delete(delLibraryBookAvailabilityId);
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    var repoDisposable = _repo as IDisposable;
                    repoDisposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

    }
}