﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Library;
using VLS_Models.ModelsDto.Library;
using VLS_BusinessLayer.Interfaces.Services.Library;

namespace VLS_BusinessLayer.Services.Library
{
    public class LibraryService : ILibraryService, IDisposable
    {
        private readonly ILibrary _repo;

        public LibraryService()
        {
            var assembly = new AssemblyManager();
            _repo = assembly.GetDataAccessRepository<ILibrary>();
        }

        public async Task<List<LibraryDto>> GetByDistance(float latitude, float longitude)
        {
            return await _repo.GetByDistance(latitude, longitude);
        }

        public async Task<List<LibraryDto>> GetById(int libraryId)
        {
            return await _repo.Get(new LibraryDto() {LibraryId = libraryId });
        }

        public async Task<List<LibraryDto>> Get(LibraryDto filtersLibrary)
        {
            return await _repo.Get(filtersLibrary);
        }

        public async Task<int> Insert(LibraryDto newLibrary)
        {
            return await _repo.Insert(newLibrary);
        }

        public async Task<int> Update(int updLibraryId, LibraryDto updLibrary)
        {
            return await _repo.Update(updLibraryId, updLibrary);
        }

        public async Task<int> Delete(int delLibraryId)
        {
            return await _repo.Delete(delLibraryId);
        }

        #region IDisposable

        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    IDisposable disposable = _repo as IDisposable;
                    disposable?.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


        #endregion

    }
}