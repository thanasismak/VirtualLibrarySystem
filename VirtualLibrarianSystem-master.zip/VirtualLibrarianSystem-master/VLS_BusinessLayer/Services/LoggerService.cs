﻿using NLog;

namespace VLS_BusinessLayer.Services
{
    public class LoggerService : Interfaces.Services.ILoggerService
    {
        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();

        public void Log(LogEntry entry)
        {
            switch (entry.Severity)
            {
                case EnumLoggingEventType.Error:
                    Logger.Error(entry.Exception,entry.Message);
                    break;
                case EnumLoggingEventType.Fatal:
                    Logger.Fatal(entry.Exception, entry.Message);
                    break;
                case EnumLoggingEventType.Debug:
                    Logger.Debug(entry.Exception, entry.Message);
                    break;
                case EnumLoggingEventType.Information:
                    Logger.Info(entry.Exception, entry.Message);
                    break;
                case EnumLoggingEventType.Warning:
                    Logger.Warn(entry.Exception, entry.Message);
                    break;
            }
        }
    }
}
