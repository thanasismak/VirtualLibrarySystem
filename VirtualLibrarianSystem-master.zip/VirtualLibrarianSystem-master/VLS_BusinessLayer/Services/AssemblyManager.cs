﻿using System;
using System.Reflection;

namespace VLS_BusinessLayer.Services
{
    public class AssemblyManager
    {
        public T GetDataAccessRepository<T>()
        {
            return GetDataAccessRepository<T>(false);
        }

        public T GetDataAccessRepository<T>(bool Searching)
        {
            string assemblyName = System.Configuration.ConfigurationManager.AppSettings["DataAccess_AssemblyName_Manager"];
            if (Searching)
                assemblyName = System.Configuration.ConfigurationManager.AppSettings["DataAccess_AssemblyName_Search"];

            string repositoryName = typeof(T).Name.Substring(1, typeof(T).Name.Length - 1);
            var typename = assemblyName + ".Repositories." + repositoryName+"Repo";

            try
            {
                var assembly = Assembly.Load(assemblyName);
                var repType = assembly.GetType(typename, false, true);
                if (typeof (T).IsAssignableFrom(repType))
                    return (T) Activator.CreateInstance(repType);
            }
            catch (Exception)
            {
                return default(T);
            }
            return default(T);

        }
    }
}
