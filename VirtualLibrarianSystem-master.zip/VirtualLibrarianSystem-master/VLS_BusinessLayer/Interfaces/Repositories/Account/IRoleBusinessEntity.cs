﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Repositories.Account
{
    public interface IRoleBusinessEntity 
    {
        Task<List<RoleBusinessEntityDto>> Get(RoleBusinessEntityDto filtersRoleBusinessEntity);

        Task<int> Insert(RoleBusinessEntityDto newRoleBusinessEntity);

        Task<int> Update(int updRoleBusinessEntityId, RoleBusinessEntityDto updRoleBusinessEntity);

        Task<int> Delete(int delRoleBusinessEntityId);
    }

}
