﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;


namespace VLS_BusinessLayer.Interfaces.Repositories.Account
{
    public interface IUser
    {
        Task<bool> CheckAuthorization(int userId, string businessEntity, string businessEntityAction);

        Task<List<UserDto>> Get(UserDto filtersUser);

        Task<int> Insert(UserDto newUser);

        Task<int> Update(int updUserId,UserDto updUser);

        Task<int> Delete(int delUserId);
    }


}
