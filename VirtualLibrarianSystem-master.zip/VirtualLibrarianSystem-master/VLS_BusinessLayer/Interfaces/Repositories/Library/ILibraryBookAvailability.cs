﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Library;


namespace VLS_BusinessLayer.Interfaces.Repositories.Library
{
    public interface ILibraryBookAvailability 
    {
        Task<List<LibraryBookAvailabilityDto>> Get(LibraryBookAvailabilityDto filtersLibraryBookAvailability);

        Task<int> Insert(LibraryBookAvailabilityDto newLibraryBookAvailability);

        Task<int> Update(int updLibraryBookAvailabilityId,LibraryBookAvailabilityDto updLibraryBookAvailability);

        Task<int> Delete(int delLibraryBookAvailabilityId);
    }


}
