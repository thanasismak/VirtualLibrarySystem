﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface ICategory 
    {
        Task<List<CategoryDto>> Get(CategoryDto filtersCategory);

        Task<int> Insert(CategoryDto newCategory);

        Task<int> Update(int updCategoryId,CategoryDto updCategory);

        Task<int> Delete(int delCategoryId);
    }


}
