﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IBookPerson 
    {
        Task<List<BookPersonDto>> Get(BookPersonDto filtersBookPerson);

        Task<int> Insert(BookPersonDto newBookPerson);

        Task<int> Update(int updBookPersonId,BookPersonDto updBookPerson);

        Task<int> Delete(int delBookPersonId);
    }


}
