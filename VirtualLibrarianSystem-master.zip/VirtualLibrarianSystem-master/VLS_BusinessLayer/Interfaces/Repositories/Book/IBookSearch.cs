﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IBookSearch
    {
        Task<List<BookSearchResultDto>> GetByValue(EnumBookSearchField bookSearchfield, string keyword, int pageIndex);

        Task<List<BookSearchResultDto>> GetByPerson(int personKindId, string keyword, int pageIndex);

        Task<List<BookSearchResultDto>> GetById(int bookId);

        Task<List<BookAvailabilityDto>> GetBookAvailability(int bookId);

    }


}
