﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IBook 
    {
        Task<List<BookDto>> Get(BookDto filtersBook);

        Task<int> Insert(BookDto newBook);

        Task<int> Update(int updBookId,BookDto updBook);

        Task<int> Delete(int delBookId);
    }


}
