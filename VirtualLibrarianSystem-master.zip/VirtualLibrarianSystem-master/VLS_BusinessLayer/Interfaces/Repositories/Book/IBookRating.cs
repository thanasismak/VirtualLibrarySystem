﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IBookRating
    {
        Task<List<BookRatingDto>> Get(BookRatingDto filtersBookRating);

        Task<int> Insert(BookRatingDto newBookRating);

        Task<int> Update(int updBookRatingId, BookRatingDto updBookRating);

        Task<int> Delete(int delBookRatingId);
    }


}
