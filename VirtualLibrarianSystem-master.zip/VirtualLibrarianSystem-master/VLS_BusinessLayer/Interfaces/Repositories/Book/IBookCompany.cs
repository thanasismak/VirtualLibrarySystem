﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IBookCompany 
    {
        Task<List<BookCompanyDto>> Get(BookCompanyDto filtersBookCompany);

        Task<int> Insert(BookCompanyDto newBookCompany);

        Task<int> Update(int updBookCompanyId,BookCompanyDto updBookCompany);

        Task<int> Delete(int delBookCompanyId);
    }


}
