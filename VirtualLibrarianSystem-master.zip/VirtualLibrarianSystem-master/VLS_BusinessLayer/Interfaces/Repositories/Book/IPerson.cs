﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IPerson 
    {
        Task<List<PersonDto>> Get(PersonDto filtersPerson);

        Task<int> Insert(PersonDto newPerson);

        Task<int> Update(int updPersonId,PersonDto updPerson);

        Task<int> Delete(int delPersonId);
    }


}
