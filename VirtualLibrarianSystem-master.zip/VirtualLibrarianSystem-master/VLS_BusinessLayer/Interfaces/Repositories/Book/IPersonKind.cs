﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;


namespace VLS_BusinessLayer.Interfaces.Repositories.Book
{
    public interface IPersonKind
    {
        Task<List<PersonKindDto>> Get(PersonKindDto filtersPersonKind);

        Task<int> Insert(PersonKindDto newPersonKind);

        Task<int> Update(int updPersonKindId,PersonKindDto updPersonKind);

        Task<int> Delete(int delPersonKindId);
    }


}
