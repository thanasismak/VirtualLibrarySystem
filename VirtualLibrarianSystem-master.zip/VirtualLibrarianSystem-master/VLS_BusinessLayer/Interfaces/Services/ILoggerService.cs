﻿namespace VLS_BusinessLayer.Interfaces.Services
{
    public interface ILoggerService
    {
        void Log(LogEntry entry);
    }

}
