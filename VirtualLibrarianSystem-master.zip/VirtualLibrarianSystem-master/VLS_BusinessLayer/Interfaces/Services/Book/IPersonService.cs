﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;

namespace VLS_BusinessLayer.Interfaces.Services.Book
{
    public interface IPersonService
    {
        Task<List<PersonDto>> Get(PersonDto filtersPerson);

        Task<int> Insert(PersonDto newPerson);

        Task<int> Update(int updPersonId, PersonDto updPerson);

        Task<int> Delete(int delPersonId);
    }

}
