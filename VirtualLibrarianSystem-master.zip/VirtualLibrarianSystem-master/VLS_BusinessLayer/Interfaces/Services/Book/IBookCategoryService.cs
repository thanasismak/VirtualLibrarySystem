﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;

namespace VLS_BusinessLayer.Interfaces.Services.Book
{
    public interface IBookCategoryService
    {
        Task<List<BookCategoryDto>> Get(BookCategoryDto filtersBookCategory);

        Task<int> Insert(BookCategoryDto newBookCategory);

        Task<int> Update(int updBookCategoryId, BookCategoryDto updBookCategory);

        Task<int> Delete(int delBookCategoryId);
    }

}
