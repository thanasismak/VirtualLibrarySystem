﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;

namespace VLS_BusinessLayer.Interfaces.Services.Book
{
    public interface ICompanyService
    {
        Task<List<CompanyDto>> Get(CompanyDto filtersCompany);

        Task<int> Insert(CompanyDto newCompany);

        Task<int> Update(int updCompanyId, CompanyDto updCompany);

        Task<int> Delete(int delCompanyId);
    }

}
