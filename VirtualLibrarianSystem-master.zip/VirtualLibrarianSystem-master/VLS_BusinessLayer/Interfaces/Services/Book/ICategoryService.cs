﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;

namespace VLS_BusinessLayer.Interfaces.Services.Book
{
    public interface ICategoryService
    {
        Task<List<CategoryDto>> Get(CategoryDto filtersCategory);

        Task<int> Insert(CategoryDto newCategory);

        Task<int> Update(int updCategoryId, CategoryDto updCategory);

        Task<int> Delete(int delCategoryId);
    }

}
