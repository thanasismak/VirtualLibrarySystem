﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Reservation;

namespace VLS_BusinessLayer.Interfaces.Services.Reservation
{
    public interface IReservationBookService
    {
        Task<List<ReservationBookDto>> Get(ReservationBookDto filtersReservationBook);

        Task<int> Insert(ReservationBookDto newReservationBook);

        Task<int> Update(int updReservationBookId, ReservationBookDto updReservationBook);

        Task<int> Delete(int delReservationBookId);
    }

}
