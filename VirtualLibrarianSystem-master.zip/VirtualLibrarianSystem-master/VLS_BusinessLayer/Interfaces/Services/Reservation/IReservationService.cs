﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Reservation;

namespace VLS_BusinessLayer.Interfaces.Services.Reservation
{
    public interface IReservationService
    {
        Task<List<ReservationDto>> Get(ReservationDto filtersReservation);

        Task<int> Insert(ReservationDto newReservation);

        Task UpdateReservationBookStatus_Reservation(int reservationId);

        Task UpdateReservationBookStatus_Return(int reservationId);

        Task<int> Update(int updReservationId, ReservationDto updReservation);

        Task<int> Delete(int delReservationId);
    }

}
