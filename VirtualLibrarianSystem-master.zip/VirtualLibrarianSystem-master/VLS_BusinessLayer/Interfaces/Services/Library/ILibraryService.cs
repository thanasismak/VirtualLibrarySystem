﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Library;

namespace VLS_BusinessLayer.Interfaces.Services.Library
{
    public interface ILibraryService
    {
        Task<List<LibraryDto>> GetByDistance(float latitude, float longitude);

        Task<List<LibraryDto>> Get(LibraryDto filtersLibrary);

        Task<int> Insert(LibraryDto newLibrary);

        Task<int> Update(int updLibraryId, LibraryDto updLibrary);

        Task<int> Delete(int delLibraryId);
    }

}
