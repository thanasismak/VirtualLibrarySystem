﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Services.Account
{
    public interface IUserService
    {
        Task<bool> CheckAuthorization(int userId, string businessEntity, string businessEntityAction);

        Task<int> Authenticate(string userName, string password);

        Task<int> Register(UserDto newUser);

        Task<List<UserDto>> Get(UserDto filtersUser);

        Task<int> Insert(UserDto newUser);

        Task<int> Update(int updUserId,UserDto updUser);

        Task<int> Delete(int delUserId);
    }


}
