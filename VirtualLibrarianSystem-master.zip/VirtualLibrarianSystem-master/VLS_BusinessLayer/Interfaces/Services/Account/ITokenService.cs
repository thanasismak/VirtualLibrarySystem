﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Services.Account
{
    public interface ITokenService
    {
        Task<bool> ValidateToken(string tokenValue);

        Task<List<TokenDto>> Get(TokenDto filtersToken);

        Task<int> Insert(TokenDto newToken);

        Task<int> Update(int updTokenId, TokenDto updToken);

        Task<int> Delete(int delTokenId);

    }
}
