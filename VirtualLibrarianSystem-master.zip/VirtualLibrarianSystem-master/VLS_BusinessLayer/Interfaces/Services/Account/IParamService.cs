﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Services.Account
{
    public interface IParamService
    {
        Task<List<ParamDto>> Get(ParamDto filtersParam);

        Task<int> Insert(ParamDto newParam);

        Task<int> Update(int updParamId, ParamDto updParam);

        Task<int> Delete(int delParamId);
    }

}
