﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Services.Account
{
    public interface IRoleService
    {
        Task<List<RoleDto>> Get(RoleDto filtersRole);

        Task<int> Insert(RoleDto newRole);

        Task<int> Update(int updRoleId, RoleDto updRole);

        Task<int> Delete(int delRoleId);
    }

}
