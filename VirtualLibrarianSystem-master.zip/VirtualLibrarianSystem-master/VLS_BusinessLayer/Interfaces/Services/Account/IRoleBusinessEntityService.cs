﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;

namespace VLS_BusinessLayer.Interfaces.Services.Account
{
    public interface IRoleBusinessEntityService
    {
        Task<List<RoleBusinessEntityDto>> Get(RoleBusinessEntityDto filtersRoleBusinessEntity);

        Task<int> Insert(RoleBusinessEntityDto newRoleBusinessEntity);

        Task<int> Update(int updRoleBusinessEntityId, RoleBusinessEntityDto updRoleBusinessEntity);

        Task<int> Delete(int delRoleBusinessEntityId);
    }

}
