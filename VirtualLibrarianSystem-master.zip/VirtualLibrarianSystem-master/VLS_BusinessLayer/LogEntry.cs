﻿using System;

namespace VLS_BusinessLayer
{
    public class LogEntry
    {
        internal readonly EnumLoggingEventType Severity;
        internal readonly string Message;
        internal readonly Exception Exception;

        public LogEntry(EnumLoggingEventType severity, string message) : this(severity, message, null)
        {
        }

        public LogEntry(EnumLoggingEventType severity, string message, Exception exception)
        {
            Severity = severity;
            Message = message;
            Exception = exception;
        }
    }
}
