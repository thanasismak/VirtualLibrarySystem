﻿namespace VLS_BusinessLayer
{

    public enum EnumBusinessEntityAction
    {
        None,
        View,Insert,Update,Delete
    };

    public enum EnumBusinessEntity
    {
        None,
        BusinessEntity,Role,RoleBusinessEntity,User,Param,
        PersonKind,Person,Company,Category,
        BookPerson,BookCompany,BookCategory,Book,
        Library,LibraryBookAvailability,
        Reservation, UserReservation,
        BookRating
    }

    public enum EnumLoggingEventType
    {
        Debug,Information,Warning,Error,Fatal
    };

    public enum EnumBookSearchField
    {
        None,Title,Description,Isbn,Isbn13
    };

    public enum EnumBookingStatus
    {
        None,Pending,Booked,Failed,Canceled,Return
    };
}