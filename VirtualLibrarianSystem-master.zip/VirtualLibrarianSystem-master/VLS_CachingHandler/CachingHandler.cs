﻿using System;
using System.Globalization;
using System.Web;


namespace VLS_CachingHandler.Web
{
	/// <summary>
	/// Handler for sending files to the client
	/// </summary>
	public class CachingHandler : IHttpHandler
	{
		public bool IsReusable => true;

	    public void ProcessRequest(HttpContext context)
		{
			string file = context.Server.MapPath(context.Request.FilePath.Replace(".ashx", ""));
            string extension = file.Substring(file.LastIndexOf('.') + 1);

            context.Response.Cache.SetExpires(DateTime.Now.AddDays(1));
			context.Response.Cache.SetCacheability(HttpCacheability.Public);
			context.Response.Cache.SetValidUntilExpires(false);

            if (extension.ToLower(CultureInfo.CurrentCulture)=="png")
                context.Response.ContentType = "image/png";
            else if (extension.ToLower(CultureInfo.CurrentCulture)=="jpg")
                context.Response.ContentType = "image/jpeg";
            else if (extension.ToLower(CultureInfo.CurrentCulture)=="gif")
                context.Response.ContentType = "image/gif";

		    if (!System.IO.File.Exists(file))
                file = context.Server.MapPath("~/Content/images/1px.gif");

            context.Response.AddHeader("content-disposition", "inline; filename=" + file);
            context.Response.WriteFile(file);
		}
	}
}
