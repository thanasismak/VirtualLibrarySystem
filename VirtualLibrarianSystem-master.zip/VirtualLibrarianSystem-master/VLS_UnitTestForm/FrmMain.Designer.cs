﻿namespace VLS_UnitTestForm
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.BtnLibraryByDistance = new System.Windows.Forms.Button();
            this.BtnSearchBookByValue = new System.Windows.Forms.Button();
            this.BtnNewReservation = new System.Windows.Forms.Button();
            this.BtnPayment = new System.Windows.Forms.Button();
            this.BtnRegister = new System.Windows.Forms.Button();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.BtnUpdateUser = new System.Windows.Forms.Button();
            this.BtnSearchBookByPerson = new System.Windows.Forms.Button();
            this.BtnGetUsers = new System.Windows.Forms.Button();
            this.BtnUserRole = new System.Windows.Forms.Button();
            this.BtnBookAvailability = new System.Windows.Forms.Button();
            this.BtnGetBookById = new System.Windows.Forms.Button();
            this.btnRateBook = new System.Windows.Forms.Button();
            this.BtnGetUserReservations = new System.Windows.Forms.Button();
            this.BtnExtendReservation = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.richTextBox1.Location = new System.Drawing.Point(0, 141);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(918, 298);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // BtnLibraryByDistance
            // 
            this.BtnLibraryByDistance.Location = new System.Drawing.Point(742, 5);
            this.BtnLibraryByDistance.Name = "BtnLibraryByDistance";
            this.BtnLibraryByDistance.Size = new System.Drawing.Size(140, 34);
            this.BtnLibraryByDistance.TabIndex = 3;
            this.BtnLibraryByDistance.Text = "library distance";
            this.BtnLibraryByDistance.UseVisualStyleBackColor = true;
            this.BtnLibraryByDistance.Click += new System.EventHandler(this.BtnLibraryByDistance_Click);
            // 
            // BtnSearchBookByValue
            // 
            this.BtnSearchBookByValue.Location = new System.Drawing.Point(158, 5);
            this.BtnSearchBookByValue.Name = "BtnSearchBookByValue";
            this.BtnSearchBookByValue.Size = new System.Drawing.Size(140, 34);
            this.BtnSearchBookByValue.TabIndex = 4;
            this.BtnSearchBookByValue.Text = "Book GetByValue";
            this.BtnSearchBookByValue.UseVisualStyleBackColor = true;
            this.BtnSearchBookByValue.Click += new System.EventHandler(this.BtnSearchBookByValue_Click);
            // 
            // BtnNewReservation
            // 
            this.BtnNewReservation.Location = new System.Drawing.Point(305, 45);
            this.BtnNewReservation.Name = "BtnNewReservation";
            this.BtnNewReservation.Size = new System.Drawing.Size(140, 34);
            this.BtnNewReservation.TabIndex = 5;
            this.BtnNewReservation.Text = "New Reservation";
            this.BtnNewReservation.UseVisualStyleBackColor = true;
            this.BtnNewReservation.Click += new System.EventHandler(this.BtnNewReservation_Click);
            // 
            // BtnPayment
            // 
            this.BtnPayment.Location = new System.Drawing.Point(743, 45);
            this.BtnPayment.Name = "BtnPayment";
            this.BtnPayment.Size = new System.Drawing.Size(140, 34);
            this.BtnPayment.TabIndex = 6;
            this.BtnPayment.Text = "Payment";
            this.BtnPayment.UseVisualStyleBackColor = true;
            this.BtnPayment.Click += new System.EventHandler(this.BtnPayment_Click);
            // 
            // BtnRegister
            // 
            this.BtnRegister.Location = new System.Drawing.Point(12, 5);
            this.BtnRegister.Name = "BtnRegister";
            this.BtnRegister.Size = new System.Drawing.Size(140, 34);
            this.BtnRegister.TabIndex = 7;
            this.BtnRegister.Text = "Register New User";
            this.BtnRegister.UseVisualStyleBackColor = true;
            this.BtnRegister.Click += new System.EventHandler(this.BtnRegister_Click);
            // 
            // BtnLogin
            // 
            this.BtnLogin.Location = new System.Drawing.Point(12, 45);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(140, 34);
            this.BtnLogin.TabIndex = 8;
            this.BtnLogin.Text = "Login";
            this.BtnLogin.UseVisualStyleBackColor = true;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // BtnUpdateUser
            // 
            this.BtnUpdateUser.Location = new System.Drawing.Point(12, 85);
            this.BtnUpdateUser.Name = "BtnUpdateUser";
            this.BtnUpdateUser.Size = new System.Drawing.Size(140, 34);
            this.BtnUpdateUser.TabIndex = 9;
            this.BtnUpdateUser.Text = "Update User";
            this.BtnUpdateUser.UseVisualStyleBackColor = true;
            this.BtnUpdateUser.Click += new System.EventHandler(this.BtnUpdateUser_Click);
            // 
            // BtnSearchBookByPerson
            // 
            this.BtnSearchBookByPerson.Location = new System.Drawing.Point(158, 45);
            this.BtnSearchBookByPerson.Name = "BtnSearchBookByPerson";
            this.BtnSearchBookByPerson.Size = new System.Drawing.Size(140, 34);
            this.BtnSearchBookByPerson.TabIndex = 10;
            this.BtnSearchBookByPerson.Text = "Book GetByPerson";
            this.BtnSearchBookByPerson.UseVisualStyleBackColor = true;
            this.BtnSearchBookByPerson.Click += new System.EventHandler(this.BtnSearchBookByPerson_Click);
            // 
            // BtnGetUsers
            // 
            this.BtnGetUsers.Location = new System.Drawing.Point(596, 5);
            this.BtnGetUsers.Name = "BtnGetUsers";
            this.BtnGetUsers.Size = new System.Drawing.Size(140, 34);
            this.BtnGetUsers.TabIndex = 11;
            this.BtnGetUsers.Text = "Get Users";
            this.BtnGetUsers.UseVisualStyleBackColor = true;
            this.BtnGetUsers.Click += new System.EventHandler(this.BtnGetUsers_Click_1);
            // 
            // BtnUserRole
            // 
            this.BtnUserRole.Location = new System.Drawing.Point(597, 45);
            this.BtnUserRole.Name = "BtnUserRole";
            this.BtnUserRole.Size = new System.Drawing.Size(140, 34);
            this.BtnUserRole.TabIndex = 12;
            this.BtnUserRole.Text = "Get User BusinessEntity";
            this.BtnUserRole.UseVisualStyleBackColor = true;
            this.BtnUserRole.Click += new System.EventHandler(this.BtnUserRole_Click);
            // 
            // BtnBookAvailability
            // 
            this.BtnBookAvailability.Location = new System.Drawing.Point(304, 5);
            this.BtnBookAvailability.Name = "BtnBookAvailability";
            this.BtnBookAvailability.Size = new System.Drawing.Size(140, 34);
            this.BtnBookAvailability.TabIndex = 13;
            this.BtnBookAvailability.Text = "Book Availability";
            this.BtnBookAvailability.UseVisualStyleBackColor = true;
            this.BtnBookAvailability.Click += new System.EventHandler(this.BtnBookAvailability_Click);
            // 
            // BtnGetBookById
            // 
            this.BtnGetBookById.Location = new System.Drawing.Point(158, 85);
            this.BtnGetBookById.Name = "BtnGetBookById";
            this.BtnGetBookById.Size = new System.Drawing.Size(140, 34);
            this.BtnGetBookById.TabIndex = 14;
            this.BtnGetBookById.Text = "Book GetById";
            this.BtnGetBookById.UseVisualStyleBackColor = true;
            this.BtnGetBookById.Click += new System.EventHandler(this.BtnGetBookById_Click);
            // 
            // btnRateBook
            // 
            this.btnRateBook.Location = new System.Drawing.Point(451, 5);
            this.btnRateBook.Name = "btnRateBook";
            this.btnRateBook.Size = new System.Drawing.Size(140, 34);
            this.btnRateBook.TabIndex = 15;
            this.btnRateBook.Text = "Rate Book";
            this.btnRateBook.UseVisualStyleBackColor = true;
            this.btnRateBook.Click += new System.EventHandler(this.btnRateBook_Click);
            // 
            // BtnGetUserReservations
            // 
            this.BtnGetUserReservations.Location = new System.Drawing.Point(451, 45);
            this.BtnGetUserReservations.Name = "BtnGetUserReservations";
            this.BtnGetUserReservations.Size = new System.Drawing.Size(140, 34);
            this.BtnGetUserReservations.TabIndex = 16;
            this.BtnGetUserReservations.Text = "Get User Reservations";
            this.BtnGetUserReservations.UseVisualStyleBackColor = true;
            this.BtnGetUserReservations.Click += new System.EventHandler(this.BtnGetUserReservations_Click);
            // 
            // BtnExtendReservation
            // 
            this.BtnExtendReservation.Location = new System.Drawing.Point(304, 85);
            this.BtnExtendReservation.Name = "BtnExtendReservation";
            this.BtnExtendReservation.Size = new System.Drawing.Size(140, 34);
            this.BtnExtendReservation.TabIndex = 17;
            this.BtnExtendReservation.Text = "Extend Reservation";
            this.BtnExtendReservation.UseVisualStyleBackColor = true;
            this.BtnExtendReservation.Click += new System.EventHandler(this.BtnExtendReservation_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 439);
            this.Controls.Add(this.BtnExtendReservation);
            this.Controls.Add(this.BtnGetUserReservations);
            this.Controls.Add(this.btnRateBook);
            this.Controls.Add(this.BtnGetBookById);
            this.Controls.Add(this.BtnBookAvailability);
            this.Controls.Add(this.BtnUserRole);
            this.Controls.Add(this.BtnGetUsers);
            this.Controls.Add(this.BtnSearchBookByPerson);
            this.Controls.Add(this.BtnUpdateUser);
            this.Controls.Add(this.BtnLogin);
            this.Controls.Add(this.BtnRegister);
            this.Controls.Add(this.BtnPayment);
            this.Controls.Add(this.BtnNewReservation);
            this.Controls.Add(this.BtnSearchBookByValue);
            this.Controls.Add(this.BtnLibraryByDistance);
            this.Controls.Add(this.richTextBox1);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button BtnLibraryByDistance;
        private System.Windows.Forms.Button BtnSearchBookByValue;
        private System.Windows.Forms.Button BtnNewReservation;
        private System.Windows.Forms.Button BtnPayment;
        private System.Windows.Forms.Button BtnRegister;
        private System.Windows.Forms.Button BtnLogin;
        private System.Windows.Forms.Button BtnUpdateUser;
        private System.Windows.Forms.Button BtnSearchBookByPerson;
        private System.Windows.Forms.Button BtnGetUsers;
        private System.Windows.Forms.Button BtnUserRole;
        private System.Windows.Forms.Button BtnBookAvailability;
        private System.Windows.Forms.Button BtnGetBookById;
        private System.Windows.Forms.Button btnRateBook;
        private System.Windows.Forms.Button BtnGetUserReservations;
        private System.Windows.Forms.Button BtnExtendReservation;
    }
}

