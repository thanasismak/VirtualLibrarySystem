﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VLS_Models.ModelsDto.Book;

namespace VLS_UnitTestForm
{
    public partial class FrmMain : Form
    {

        private List<string> keywords = new List<string>();

      //  private string baseurl= "http://40.76.223.113/";
      // private string urlprefix = "Team1_VirtualLibrarianSystem_Api/";
        private string baseurl = "http://localhost:59478/";
        private string urlprefix = "";

        public FrmMain()
        {
            InitializeComponent();
        }


        private void BtnRegister_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string data =
                "{ \"UserName\" : \"test10\", \"Password\" :  \"test10\", \"FirstName\" : \"test10\", \"LastName\" : \"test10\", \"Email\" : \"test10@sasa.fr\" }";

            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/User/Registration")
                {
                    Content = new StringContent(data, Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                else
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                richTextBox1.AppendText("BtnRegister Error " + ex.Message);
            }

        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            string token = web_api_Token_Generate("1", "1");
            richTextBox1.AppendText("Token " + token);
        }

        public string web_api_Token_Generate(string username, string password)
        {
            string basicAuth =
                Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1")
                    .GetBytes(username + ":" + password));

            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "Token");
                request.Headers.Add("Authorization", "Basic " + basicAuth);

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var headers = response.Headers;
                    if (headers.Contains("Token"))
                    {
                        string token = headers.GetValues("Token").First();
                        return token;
                    }
                }
                return "";
            }
            catch (Exception)
            {
                return "----------ERROR AT GET TOKEN-------";
            }
        }

        private void BtnUpdateUser_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("test10", "test10");
            if (token == "") return;
            {

                string data = "{  \"FirstName\" : \"Vasilis\" }";

                try
                {
                    var client = new HttpClient {BaseAddress = new Uri(baseurl)}; //http://40.76.223.113/
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Token", token);
                    var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/User/Update")
                    {
                        Content = new StringContent(data, Encoding.UTF8, "application/json")
                    };

                    var response = Task.Run(() => client.SendAsync(request)).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                    }
                    else
                        richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                catch (Exception ex)
                {
                    richTextBox1.AppendText("Btn Update user Error " + ex.Message);
                }
            }
        }

        private void BtnLibraryByDistance_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var request = new HttpRequestMessage(HttpMethod.Get,
                    urlprefix + "api/v1.0/Library/GetByDistance?latitude=37.987969&longitude=23.733387");

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
            }
            catch (Exception ex)
            {
                richTextBox1.AppendText("library_distance__webapi Error " + ex.Message);
            }

        }

        private void BtnPayment_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            var paymentRequest = new VLS_Payment.Models.PaymentRequest();
            paymentRequest.Id = 1.ToString();
            paymentRequest.Amount = 100;
            paymentRequest.CardHolder = "Test name";
            paymentRequest.CardNumber = "4111111111111111";
            paymentRequest.ExpiryYear = "2017";
            paymentRequest.ExpiryMonth = "12";
            paymentRequest.Cvv = "123";

            var payment = new VLS_Payment.Service.Payment();
            var paymentResponse = payment.Pay(paymentRequest);
            richTextBox1.AppendText(paymentResponse.Status + " " + paymentResponse.Message);


        }

        private void BtnSearchBookByValue_Click(object sender, EventArgs e)
        {
            string keyword = "γιαν";

            richTextBox1.Text = "";

            var client = new HttpClient {BaseAddress = new Uri(baseurl)};
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
            var request = new HttpRequestMessage(HttpMethod.Get,
                urlprefix + "api/v1.0/BookSearch/GetByValue?searchfield=Title&keyword="+ keyword + "&pageIndex=1");
            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var stream = response.Content.ReadAsStreamAsync().Result;
                MemoryStream ms = new MemoryStream();
                stream.CopyToAsync(ms);
                ms.Position = 0;
                var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                string _value = str.ReadToEnd();
                var books = JsonConvert.DeserializeObject<List<BookSearchResultDto>>(_value);
                richTextBox1.Text = _value;
            }
            else
            {
                richTextBox1.Text = response.Content.ToString();
            }

        }

        private void BtnSearchBookByPerson_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            var client = new HttpClient {BaseAddress = new Uri(baseurl)};
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
            var request = new HttpRequestMessage(HttpMethod.Get,
                urlprefix + "api/v1.0/BookSearch/GetByPerson?personKindId=1&keyword=μαρια&pageIndex=1");
            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var stream = response.Content.ReadAsStreamAsync().Result;
                MemoryStream ms = new MemoryStream();
                stream.CopyToAsync(ms);
                ms.Position = 0;
                var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                string _value = str.ReadToEnd();
                var books = JsonConvert.DeserializeObject<List<BookSearchResultDto>>(_value);
                richTextBox1.Text = _value;
            }
            else
            {
                richTextBox1.Text = response.Content.ToString();
            }

        }

        private void BtnGetUsers_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("test10", "test10");
            if (token == "") return;

            string user = " { \"UserName\" : \"Admin@vls.gr\" }";

            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/User/Search")
                {
                    //SSSContent = new StringContent(user, Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                else
                    richTextBox1.AppendText(response.ToString());

            }
            catch (Exception)
            {
                richTextBox1.AppendText("GET USER ERROR");
            }
        }

        private void BtnUserRole_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("librarian", "librarian");
            if (token == "") return;

            string data = "{\"RoleId\":\"2\"}";

            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/RoleBusinessEntity/Search")
                {
                    Content = new StringContent(data, Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                else
                    richTextBox1.AppendText(response.ToString());

            }
            catch (Exception)
            {
                richTextBox1.AppendText("GET USER ERROR");
            }

        }

        private void BtnBookAvailability_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("admin", "adm");
            if (token == "") return;


            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var request = new HttpRequestMessage(HttpMethod.Get,urlprefix + "api/v1.0/BookSearch/BookAvailability?bookId=63");

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                else
                    richTextBox1.AppendText(response.ToString());

            }
            catch (Exception)
            {
                richTextBox1.AppendText("GET LibraryBookAvailability ERROR");
            }
        }

        private void BtnNewReservation_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("librarian", "librarian");
            if (token == "") return;

            /*
            string rsv =
                "{" +
                "\"ReservationBooks\": [" +
                "               {\"LibraryId\": \"1\",\"BookId\": \"63\",\"StartDate\": \"2016-11-25\"}," +
                "               {\"LibraryId\": \"1\",\"BookId\": \"67\",\"StartDate\": \"2016-11-25\"}," +
                "               {\"LibraryId\": \"3\",\"BookId\": \"78\",\"StartDate\": \"2016-11-25\"}" +
                "             ]" +
                "}";
             */
          string rsv =
                "{" +
                "\"ReservationBooks\": [" +
                "               {\"LibraryId\": \"2\",\"BookId\": \"78\",\"StartDate\": \"2016-11-25\"}" +
                "             ]" +
                "}";
          
            try
            {
                var client = new HttpClient {BaseAddress = new Uri(baseurl)};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/UserNewReservation")
                {
                    Content = new StringContent(rsv, Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                else
                    richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
            }
            catch (Exception ex)
            {
                richTextBox1.AppendText("BookTitleAutoComplete Error " + ex.Message);
            }

        }

        private void BtnGetBookById_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            var client = new HttpClient {BaseAddress = new Uri(baseurl)};
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
            var request = new HttpRequestMessage(HttpMethod.Get, urlprefix + "api/v1.0/BookSearch/GetById?bookId=74");
            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var stream = response.Content.ReadAsStreamAsync().Result;
                MemoryStream ms = new MemoryStream();
                stream.CopyToAsync(ms);
                ms.Position = 0;
                var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                string _value = str.ReadToEnd();
                var books = JsonConvert.DeserializeObject<List<BookSearchResultDto>>(_value);
                richTextBox1.Text = _value;
            }
            else
            {
                richTextBox1.Text = response.Content.ToString();

            }
        }

        private void btnRateBook_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("1", "1");
            if (token == "")
            {
                richTextBox1.AppendText("no token");
                return;
            }
            string data = "{\"BookId\":\"74\",\"Rating\":\"6\"}";

            var client = new HttpClient { BaseAddress = new Uri(baseurl) };
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", token);
            var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/BookRating")
            {
                Content = new StringContent(data, Encoding.UTF8, "application/json")
            };

            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
            }
            else
                richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);

        }

        private void BtnGetUserReservations_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";

            string token = web_api_Token_Generate("1", "1");
            if (token == "")
            {
                richTextBox1.AppendText("no token");
                return;
            }

            var client = new HttpClient { BaseAddress = new Uri(baseurl) };
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", token);
            var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/UserReservation/Search");

            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
            }
            else
                richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
        }

        private void BtnExtendReservation_Click(object sender, EventArgs e)
        {
            {
                richTextBox1.Text = "";

                string token = web_api_Token_Generate("1", "1");
                if (token == "") return;

                string rsv =
                      "{" +
                      "\"ReservationBooks\": [" +
                      "               {\"Extend\": \"true\",\"ExtendReservationBookId\": \"28\",\"LibraryId\": \"1\",\"BookId\": \"129\",\"StartDate\": \"2016-12-10\"}" +
                      "             ]" +
                      "}";

                try
                {
                    var client = new HttpClient { BaseAddress = new Uri(baseurl) };
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Token", token);
                    var request = new HttpRequestMessage(HttpMethod.Post, urlprefix + "api/v1.0/UserExtendReservation")
                    {
                        Content = new StringContent(rsv, Encoding.UTF8, "application/json")
                    };

                    var response = Task.Run(() => client.SendAsync(request)).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                    }
                    else
                        richTextBox1.AppendText(response.Content.ReadAsStringAsync().Result);
                }
                catch (Exception ex)
                {
                    richTextBox1.AppendText("BookTitleAutoComplete Error " + ex.Message);
                }

            }

        }
    }
}
