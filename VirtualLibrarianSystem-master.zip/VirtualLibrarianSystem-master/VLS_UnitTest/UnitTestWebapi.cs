﻿using System;
using System.IO;
using System.IO.Compression;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Book;

namespace UnitTest
{

    [TestClass]
    public class UnitTestWebapi
    {

        [TestMethod]
        public void books_insertbook()
        {

            var newbook = new BookDto()
            {
                Title = "Βιβλίο τεστ 1",
                Description = "Περιγραγή Βιβλίο test 1",
            };


            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.Team1_VirtualLibrarianSystem_Api.gr")};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string request = "/api/books/insertbook";

                var response = Task.Run(() => client.PostAsJsonAsync(request, newbook)).Result;
                var res = response.Content.ReadAsStringAsync().Result;
                Console.WriteLine("books_insertbook : " + res);

            }
            catch (Exception ex)
            {
                Console.WriteLine("books_insertbook error : " + ex.Message);
            }
        }


        [TestMethod]
        public void books_search()
        {
            string token = "bb70eb3a-5a35-44cd-881b-bde8e6fc8cd7";

            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr/")};
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Get, "/api/v1.0/books/search");
                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var stream = response.Content.ReadAsStreamAsync().Result;
                    MemoryStream ms = new MemoryStream();
                    stream.CopyToAsync(ms);
                    ms.Position = 0;
                    var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                    var res = str.ReadToEnd();
                    Console.WriteLine("books_search " + res);
                }
                else
                {
                    Console.WriteLine("books_search err " + response);
                }

                

            }
            catch (Exception ex)
            {
                Console.WriteLine("books_search error "+ex.Message);
            }
        }

        

    }
}