﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{

    [TestClass]
    public class UnitTestBl
    {


        [TestMethod]
        public void Book_Search()
        {
            try
            {
                DateTime startDt = DateTime.Now;
              //  var cl = new BookManager();
              //  var books = cl.Search();
                DateTime endDt = DateTime.Now;
                Console.WriteLine("Time {0}", endDt - startDt);
                //Console.WriteLine("Book_Search Count {0}", books.Count.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Book_Search Error {0}", ex.Message);
            }
        }

        [TestMethod]
        public void Insert_Book()
        {
            try
            {
                //var cl = new BookManager();
                //var newBookId= cl.InsertBook("το βιβλίο μου 1", "το βιβλίο μου περιγραφή 1");
                //DateTime EndDT = DateTime.Now;
                //Console.WriteLine("Time {0}", EndDT-StartDT);
                //Console.WriteLine("Insert_Book New Book ID {0}", newBookId.GetValueOrDefault());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert_Book Error {0}", ex.Message);
            }
        }
    }
}
