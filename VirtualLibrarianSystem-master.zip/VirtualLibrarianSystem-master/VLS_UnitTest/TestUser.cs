﻿using System;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Net.Http.Headers;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Services.Account;

namespace UnitTest
{
    [TestClass]
    public class TestUser
    {
        [TestMethod]
        public void user_Get()
        {
            try
            {
                UserDto user = new UserDto { UserId = 3, FirstName = "first" };

                DateTime startDt = DateTime.Now;
                var cl = new UserService();
                var res = Task.Run(() => cl.Get(user));
                var endDt = DateTime.Now;
                Console.WriteLine("Time {0}", endDt - startDt);
                Console.WriteLine("Authenticate user id {0}", res.Result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Authenticate Error {0}", ex.Message);
            }
        }


        [TestMethod]
        public void user_Authenticate()
        {
            try
            {
                DateTime startDt = DateTime.Now;
                var cl = new UserService();
                var res = Task.Run(() => cl.Authenticate("admi11n", "admin"));
                DateTime endDt = DateTime.Now;
                Console.WriteLine("Time {0}", endDt - startDt);
                Console.WriteLine("Authenticate user id {0}", res.Result.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Authenticate Error {0}", ex.Message);
            }
        }

        [TestMethod]
        public void user_insert()
        {
            try
            {
                DateTime startDt = DateTime.Now;
                var cl = new UserService();
                UserDto user = new UserDto { UserName = "1111111111111", Password = "ddddf", FirstName = "first", LastName = "last", Email = "sasas@sasa.fr" };

                var res = Task.Run(() => cl.Insert(user));
                DateTime endDt = DateTime.Now;
                Console.WriteLine("Time {0}", endDt - startDt);
                Console.WriteLine("Authenticate user id {0}", res.Result.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Authenticate Error {0}", ex.Message);
            }
        }

        [TestMethod]
        public void User_get_webapi()
        {
            string token = "558427f3-37f8-4623-a0c2-8d22e5ffeb83";

            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr/")};
                //http://www.Team1_VirtualLibrarianSystem_Api.gr
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Get, "/api/v1.0/User/10");

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content;
                    Console.WriteLine("User_Insert : " + res);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("User_Insert Error " + ex.Message);
            }
        }



        [TestMethod]
        public void User_Insert_webapi()
        {
            string token = "558427f3-37f8-4623-a0c2-8d22e5ffeb83";
            UserDto user = new UserDto { UserName = "test", Password = "test", FirstName = "test", LastName = "test", Email = "test" };

            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr/")};
                //http://www.Team1_VirtualLibrarianSystem_Api.gr
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1.0/User")
                {
                    Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content;
                    Console.WriteLine("User_Insert : " + res);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("User_Insert Error " + ex.Message);
            }
        }


        [TestMethod]
        public void User_Update()
        {
            string token = "558427f3-37f8-4623-a0c2-8d22e5ffeb83";
            UserDto user = new UserDto { UserId = 3, UserName = "TEST 3", Password = "aaaaaa", FirstName = "first", LastName = "last", Email = "33333",IsActive = true,RoleId = 1};

            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr/")};
                //http://www.Team1_VirtualLibrarianSystem_Api.gr
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Put, "/api/v1.0/User/3")
                {
                    Content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json")
                };
                
                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content;
                    Console.WriteLine("User_Update: " + res);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("User_Update Error " + ex.Message);
            }
        }

        [TestMethod]
        public void User_Delete()
        {
            const string token = "558427f3-37f8-4623-a0c2-8d22e5ffeb83";
            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr/")};
                //http://www.Team1_VirtualLibrarianSystem_Api.gr
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Delete, "/api/v1.0/User/5");

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var res = response.Content;
                    Console.WriteLine("User_Delete: " + res);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("User_Delete Error " + ex.Message);
            }
        }
    }
}
