﻿using System;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VLS_BusinessLayer.Services.Account;

namespace UnitTest
{
    [TestClass]
    public class TestToken
    {

        [TestMethod]
        public void Token_Generate()
        {
            try
            {
                DateTime startDt = DateTime.Now;
                var m =new UserService();
                var r= Task.Run(() => m.Authenticate("admin", "adm")).Result;
                
                var cl = new TokenService();
                var res =  cl.GenerateToken(1);
                DateTime endDt = DateTime.Now;
                Console.WriteLine(r.ToString());
                Console.WriteLine("Time {0}", endDt - startDt);
                Console.WriteLine("token {0}", Task.Run(() => res).Result.AuthToken);
            }
            catch (Exception ex)
            {
                Console.WriteLine("GenerateToken Error {0}", ex.Message);
            }

        }

        [TestMethod]
        public void Token_Validate()
        {
            string token = "558427f3-37f8-4623-a0c2-8d22e5ffeb83";
            try
            {
                DateTime startDt = DateTime.Now;
                var cl = new TokenService();
                var res = cl.ValidateToken(token);
                DateTime endDt = DateTime.Now;
                Console.WriteLine("Time {0}", endDt - startDt);
                Console.WriteLine("ValidateToken {0}", Task.Run(() => res).Result.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("ValidateToken Error {0}", ex.Message);
            }
        }


        [TestMethod]
        public void web_api_Token_Generate()
        {
            const string username = "admin";
            const string password = "adm";
            string basicAuth = Convert.ToBase64String(System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(username + ":" + password));

            try
            {
                var client = new HttpClient {BaseAddress = new Uri("http://www.VLS_WebApi.gr")};
                //http://www.Team1_VirtualLibrarianSystem_Api.gr
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var request = new HttpRequestMessage(HttpMethod.Post, "/Token");
                request.Headers.Add("Authorization", "Basic " + basicAuth);

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    var headers = response.Headers;
                    if (headers.Contains("Token"))
                    {
                        string token = headers.GetValues("Token").First();
                        Console.WriteLine("Get_Token : " + token);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Get_Token Error " + ex.Message);
            }
        }

    }
}
