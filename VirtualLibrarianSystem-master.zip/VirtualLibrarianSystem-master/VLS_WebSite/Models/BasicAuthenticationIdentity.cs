﻿using System.Security.Principal;

namespace VLS_WebSite.Models
{
    public class BasicAuthenticationIdentity : GenericIdentity
    {
        /// <summary>
        /// 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserToken { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        /// <param name="userToken"></param>
        public BasicAuthenticationIdentity(int userId, string userName, string userToken) : base(userName, "Basic")
        {
            UserId = userId;
            UserName = userName;
            UserToken = userToken;
        }
    }

}