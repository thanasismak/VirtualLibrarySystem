﻿namespace VLS_WebSite.Models
{
    public class ErrorViewModel
    {
        public string Error { get; set; }
        public VLS_Models.ModelsDto.Account.UserDto User { get; set; }
    }
}