﻿using System.Collections.Generic;
using System.Web.Mvc;
using PagedList;

namespace VLS_WebSite.Models
{
    public class BooksearchModel
    {
        public IEnumerable<SelectListItem> SearchingType { set; get; }
        public IPagedList<VLS_Models.ModelsDto.Book.BookSearchResultDto> Books { set; get; }
        public int Index { get; set; }
        public string SearchItems { get; set; }
        public string SearchContent { get; set; }

    }
}