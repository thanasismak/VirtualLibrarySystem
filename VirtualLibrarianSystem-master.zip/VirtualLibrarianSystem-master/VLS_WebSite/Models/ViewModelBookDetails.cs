﻿using System.Collections.Generic;
using VLS_Models.ModelsDto.Book;

namespace VLS_WebSite.Models
{
    public class ViewModelBookDetails
    {
        public BookSearchResultDto SearchReult { get; set; }
        public List<BookAvailabilityDto> Availability { get; set; }

        
    }
}