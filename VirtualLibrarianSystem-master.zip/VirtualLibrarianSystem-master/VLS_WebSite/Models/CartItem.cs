﻿namespace VLS_WebSite.Models
{
    public class CartItem
    {
        public int BookId { get; set; }

        public string BookTitle { get; set; }

        public int LibraryId { get; set; }

        public string LibraryName { get; set; }
    }
}