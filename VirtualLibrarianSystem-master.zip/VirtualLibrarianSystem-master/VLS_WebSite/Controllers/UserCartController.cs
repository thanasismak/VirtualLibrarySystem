﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Routing;
using VLS_Models.ModelsDto.Reservation;
using VLS_WebSite.Models;

namespace VLS_WebSite.Controllers
{
    public class UserCartController : Controller
    {

        public  List<CartItem> GetCart()
        {
            if (System.Web.HttpContext.Current.Session["_cart"] != null)
                return System.Web.HttpContext.Current.Session["_cart"] as List<CartItem>;
            return new List<CartItem>();
        }

        public void SetCart(List<CartItem> cart)
        {
            System.Web.HttpContext.Current.Session["_cart"] = cart;
        }


        // GET: UserCart
        public ActionResult Index()
        {
            return View(GetCart());
        }


        public ActionResult Cart()
        {

            return View(GetCart());
        }

        public void ClearCart()
        {
            SetCart(null);
        }

        public ActionResult AddToCart(int bookId, string bookTitle, int libraryId, string libraryName)
        {
            var cart = GetCart();
            if (cart.All(i => i.BookId != bookId))
                cart.Add(new CartItem() { BookId = bookId, BookTitle = bookTitle, LibraryId = libraryId, LibraryName = libraryName });
            SetCart(cart);

            return View("Cart", GetCart());
        }


        public ActionResult Remove(int bookId,int libraryId)
        {
            var cart = GetCart();
            cart.RemoveAll(i => i.BookId == bookId && i.LibraryId == libraryId);
            SetCart(cart);

            return View("Cart",GetCart());
        }


        public ActionResult Extend(int reservationBookId, int bookId, string bookTitle, int libraryId, string libraryName)
        {

            ClearCart();
            AddToCart(bookId, bookTitle, libraryId, libraryName);
            Reservetion(true, reservationBookId);

            return View("Cart", GetCart());
        }

        public ActionResult Reservetion(bool? isExtend,int? extendReservationBookId)
        {
            var auth = new AuthController();
            if (!auth.UserIsAuth())
                return RedirectToAction("Login", "Account", new RouteValueDictionary(new { returnUrl = "UserCart/Cart" }));

            string token = new AuthController().GetToken();
            var cart = GetCart();
            var rsv = new VLS_Models.ModelsDto.Reservation.ReservationDto();
            rsv.ReservationBooks = new List<ReservationBookDto>();

            foreach (var item in cart)
                rsv.ReservationBooks.Add(new ReservationBookDto() {Extend= isExtend.GetValueOrDefault() ,ExtendReservationBookId = extendReservationBookId, BookId = item.BookId, LibraryId = item.LibraryId, StartDate = System.DateTime.Now });

            try
            {
                var action = "User"+ (isExtend.GetValueOrDefault() ? "Extend" : "New") +"Reservation";

                var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Token", token);
                var request = new HttpRequestMessage(HttpMethod.Post, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/"+action)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(rsv), Encoding.UTF8, "application/json")
                };

                var response = Task.Run(() => client.SendAsync(request)).Result;

                if (response.IsSuccessStatusCode)
                {
                    ClearCart();
                    return RedirectToAction("Index", "UserReservation");
                }
            }
            catch (Exception ex)
            {
                return RedirectToAction("ErrorPage", "Home");
            }
            return RedirectToAction("Index", "Home");
        }


    }
}