﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Net.Http;
using System.Text;
using System.Net.Http.Headers;
using System.Web.Configuration;
using Newtonsoft.Json;
using VLS_Models.ModelsDto.Account;
using VLS_WebSite.Models;

namespace VLS_WebSite.Controllers
{


    public class AccountController : Controller
    {
        public AccountController()
        {
        }

        public ActionResult Register()
        {
            return View();
        }


        // POST: /Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(UserDto model)
        {

            if (ModelState.IsValid)
            {
                    var client = new HttpClient {BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"] ) };
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var request = new HttpRequestMessage(HttpMethod.Post, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/User/Registration")
                    {
                        Content =
                            new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(model), Encoding.UTF8,"application/json")
                    };

                    var response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        var err= response.Content.ReadAsStringAsync().Result;
                        RedirectToAction("ErrorPage", "Home");
                        return Content(err);
                    }
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        public ActionResult Login(string returnUrl)
        {
            TempData["returnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(UserDto model)
        {
            new AuthController().LoggOff();

            if (ModelState.IsValid)
            {
                string basicAuth =
                    Convert.ToBase64String(
                        System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(model.UserName + ":" + model.Password));

                try
                {
                    var client = new HttpClient {BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    var request = new HttpRequestMessage(HttpMethod.Post, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "Token");
                    request.Headers.Add("Authorization", "Basic " + basicAuth);

                    var response = await client.SendAsync(request);

                    if (response.IsSuccessStatusCode)
                    {
                        var headers = response.Headers;
                        if (headers.Contains("Token"))
                        {
                            string token = headers.GetValues("Token").First();
                            if (token != "")
                            {
                                var identity = new BasicAuthenticationIdentity(0, model.UserName, token);
                                var auth = new AuthController();
                                auth.SetToken(identity);
                            }
                            string returnUrl= TempData["returnUrl"]  as string;

                            if (!string.IsNullOrEmpty(returnUrl))
                                return RedirectToAction(returnUrl.Split('/')[1], returnUrl.Split('/')[0]);
                            else
                                return RedirectToAction("Index", "Home");
                        }
                    }
                    else
                    {
                        var err=response.Content.ReadAsStringAsync().Result;
                        ErrorViewModel error = new ErrorViewModel { Error = err };
                        return View("ErrorPage",error);
                       
                    }
                }
                catch (Exception ex)
                {
                    return Content(ex.Message);
                }

            }
            return View(model);
        }

        public async Task<ActionResult> Update()
        {
            var auth = new AuthController();
            if (!auth.UserIsAuth()) return RedirectToAction("Login", "Account");

            var client = new HttpClient();
            client.BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", auth.GetToken());
            var request = new HttpRequestMessage(HttpMethod.Get, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/User/User");
            var response = await client.SendAsync(request);

            if (response.IsSuccessStatusCode)
            {
                var _value = response.Content.ReadAsStringAsync().Result;
                var user = JsonConvert.DeserializeObject<List<UserDto>>(_value).FirstOrDefault();
                return View(user);
            }
            else
            {
                RedirectToAction("ErrorPage", "Home");
                var err = response.Content.ReadAsStringAsync().Result;
                return Content(err);
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Update(UserDto model)
        {
            var auth= new AuthController();
            if (!auth.UserIsAuth()) return RedirectToAction("Login", "Account");

            var client = new HttpClient();
            client.BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", auth.GetToken());
            var request = new HttpRequestMessage(HttpMethod.Post, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/User/Update")
            {
                Content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json")
            };
            var response = await client.SendAsync(request);

            var res = response.Content.ReadAsStringAsync().Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("Manage", "Account");
            return Content(res);
        }

        [HttpPost]
        public ActionResult Logoff()
        {
            var auth = new AuthController();
            auth.LoggOff();
            return RedirectToAction("Index", "Home");
        }

        public async Task<ActionResult> Manage()
        {
            return View();
        }
    }
}