﻿using Newtonsoft.Json;
using PagedList;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Mvc;
using VLS_Models.ModelsDto.Book;
using VLS_WebSite.Models;

namespace VLS_WebSite.Controllers
{
    public class HomeController : Controller
    {
        private readonly BooksearchModel _booksearchModel = new BooksearchModel { SearchingType = null, Books = null, Index = 0 };
        private readonly int _pageSize = 20;


        private static List<SelectListItem> GetList()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem { Text = "Title", Value = "0", Selected = true });
            items.Add(new SelectListItem { Text = "Description", Value = "1" }); 
            items.Add(new SelectListItem { Text = "ISBN", Value = "2" });
            items.Add(new SelectListItem { Text = "Author", Value = "3" });
            items.Add(new SelectListItem { Text = "Translator", Value = "4" });
            items.Add(new SelectListItem { Text = "Illustrator", Value = "5" });
            return items;
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        public ActionResult Index(string searchItems, string searchContent, int? page)
        {
            List<SelectListItem> _items = GetList();

            if ( (string.IsNullOrEmpty(searchItems)) || string.IsNullOrEmpty(searchContent))
            {
                _booksearchModel.SearchingType = _items;
                return View(_booksearchModel);
            }

            var index = Int32.Parse(searchItems);
            var pageNumber = page ?? 1;

            if (index < 3)
            {
                var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
                var request = new HttpRequestMessage(HttpMethod.Get, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/BookSearch/GetByValue?searchfield=" + _items[index].Text + "&keyword=" + searchContent + "&pageIndex=" + pageNumber.ToString());

                GetResponse(client,request, _items, searchItems, searchContent, pageNumber);
            }
            else
            {
                string index2 = "";
                switch (index)
                {
                    case 3:
                        index2 = "1";
                        break;
                    case 4:
                        index2 = "2";
                        break;
                    case 5:
                        index2 = "4";
                        break;
                }
                var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
                var request = new HttpRequestMessage(HttpMethod.Get, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/BookSearch/GetByPerson?personKindId=" + index2 + "&keyword=" + searchContent + "&pageIndex=" + pageNumber.ToString());

                GetResponse(client, request, _items, searchItems, searchContent, pageNumber);
            }

            return View(_booksearchModel);
        }

        private void GetResponse(HttpClient client,HttpRequestMessage request, List<SelectListItem> _items, string SearchItems, string searchContent,int pageNumber)
        {
            var response = Task.Run(() => client.SendAsync(request)).Result;
            if (response.IsSuccessStatusCode)
            {
                var stream = response.Content.ReadAsStreamAsync().Result;
                MemoryStream ms = new MemoryStream();
                stream.CopyToAsync(ms);
                ms.Position = 0;
                var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                string _value = str.ReadToEnd();
                var books = JsonConvert.DeserializeObject<List<BookSearchResultDto>>(_value);
                int totalrows = 0;
                if (books.Count > 0)
                    totalrows = books[0].TotalRows.GetValueOrDefault();
                ViewBag.Books = books;
                _booksearchModel.SearchingType = _items;
                _booksearchModel.SearchItems = SearchItems;
                _booksearchModel.SearchContent = searchContent;

                _booksearchModel.Books = new StaticPagedList<BookSearchResultDto>(books, pageNumber, _pageSize, totalrows);
            }

        }

    }
}