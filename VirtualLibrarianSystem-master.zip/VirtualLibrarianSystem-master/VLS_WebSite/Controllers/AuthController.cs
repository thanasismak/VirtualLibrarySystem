﻿using System.Web.Mvc;
using VLS_WebSite.Models;

namespace VLS_WebSite.Controllers
{
    public class AuthController : Controller
    {
        // GET: Auth
        public ActionResult Index()
        {
            return View();
        }

        public void SetToken(BasicAuthenticationIdentity identity)
        {
            System.Web.HttpContext.Current.Session["Useridentity"] = identity;
        }

        public string GetToken()
        {
            string token = "";
            try
            {
                if (System.Web.HttpContext.Current.Session["Useridentity"] != null)
                    token = ((BasicAuthenticationIdentity)System.Web.HttpContext.Current.Session["Useridentity"]).UserToken;
            }
            catch
            {
                token = "";
            }
            return token;
        }

        public void LoggOff()
        {
            System.Web.HttpContext.Current.Session["Useridentity"] = null;
        }

        public bool UserIsAuth()
        {
            string token = GetToken();
            if (token == "")
                return false;
            return true;
        }

    }
}