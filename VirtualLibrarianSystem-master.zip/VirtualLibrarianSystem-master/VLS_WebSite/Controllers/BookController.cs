﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Mvc;
using VLS_Models.ModelsDto.Book;
using VLS_WebSite.Models;

namespace VLS_WebSite.Controllers
{
    public class BookController : Controller
    {
        private ViewModelBookDetails GetBook(int bookId)
        {
            ViewModelBookDetails viewModel2 = null;


            var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.AcceptEncoding.Add(new StringWithQualityHeaderValue("gzip"));
            var request = new HttpRequestMessage(HttpMethod.Get, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/BookSearch/GetById?bookId=" + bookId);
            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var stream = response.Content.ReadAsStreamAsync().Result;
                MemoryStream ms = new MemoryStream();
                stream.CopyToAsync(ms);
                ms.Position = 0;
                var str = new StreamReader(new GZipStream(ms, CompressionMode.Decompress));
                string _value = str.ReadToEnd();
                var book = JsonConvert.DeserializeObject<List<BookSearchResultDto>>(_value).FirstOrDefault();
                ViewBag.Book = book;
                List<BookAvailabilityDto> Availability = null;
                if (book != null)
                    Availability = GetBookAvailability(book.BookId.GetValueOrDefault());
                viewModel2 = new ViewModelBookDetails {SearchReult = ViewBag.Book, Availability = Availability};
            }
            else RedirectToAction("ErrorPage", "Home");
            return viewModel2;

        }

        // GET: Book/Details
        public ActionResult Details(int id)
        {
            var viewModel2 = GetBook(id);
            return View(viewModel2);
        }


        private List<BookAvailabilityDto> GetBookAvailability(int BookId)
        {
            var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var request = new HttpRequestMessage(HttpMethod.Get,
                WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/BookSearch/BookAvailability?bookId=" + BookId.ToString());

            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var _value = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<List<BookAvailabilityDto>>(_value);
            }
            return null;
        }

        public ActionResult AddToCart(int bookId,string bookTitle,int libraryId, string libraryName)
        {
            var cartcontroller =new UserCartController();
            cartcontroller.AddToCart(bookId, bookTitle, libraryId, libraryName);

            ViewBag.Succeed = "Your product is in cart.";
            var book = GetBook(bookId);
            return View("Details",book);
        }


    }
}