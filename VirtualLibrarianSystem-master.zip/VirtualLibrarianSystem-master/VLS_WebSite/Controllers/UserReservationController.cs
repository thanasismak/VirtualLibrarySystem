﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Mvc;
using System.Web.Routing;
using Newtonsoft.Json;
using VLS_Models.ModelsDto.Reservation;

namespace VLS_WebSite.Controllers
{
    public class UserReservationController : Controller
    {
        // GET: UserReservation
        public ActionResult Index()
        {
            var auth = new AuthController();
            if (!auth.UserIsAuth())
                return RedirectToAction("Login", "Account", new RouteValueDictionary(new { returnUrl = "UserReservation/Index" }));

            var userReservations = GetUserReservations();
            return View(userReservations);
        }

        private List<VLS_Models.ModelsDto.Reservation.ReservationDto> GetUserReservations()
        {
            List<VLS_Models.ModelsDto.Reservation.ReservationDto> userReservations = null;

            string token = new AuthController().GetToken();

            var client = new HttpClient { BaseAddress = new Uri(WebConfigurationManager.AppSettings["WebApi_baseurl"]) };
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("Token", token);
            var request = new HttpRequestMessage(HttpMethod.Post, WebConfigurationManager.AppSettings["WebApi_urlprefix"] + "api/v1.0/UserReservation/Search");
            var response = Task.Run(() => client.SendAsync(request)).Result;

            if (response.IsSuccessStatusCode)
            {
                var res = response.Content.ReadAsStringAsync().Result;
                userReservations = JsonConvert.DeserializeObject<List<ReservationDto>>(res);
                ViewBag.Reservations = userReservations;

            }
            return userReservations;

        }
    }
}