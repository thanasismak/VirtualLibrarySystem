﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Dapper;

namespace VLS_DataAccessDapper.Abstract
{
    public abstract class BaseRepository : IDisposable
    {
        protected SqlConnection Connection;

        protected BaseRepository()
        {
            Connection = new SqlConnection(ConfigurationManager.ConnectionStrings["mssql"].ConnectionString);
        }

        protected virtual string GetFieldValueDateTime(DateTime value)
        {
            return
                $"CONVERT(DATETIME,'{value.Day}/{value.Month}/{value.Year} {value.Hour}:{value.Minute}:{value.Second}',103)";
        }

        protected virtual async Task<List<T>> QueryAsync<T>(string sqlQuery)
        {
            return (await Connection.QueryAsync<T>(sqlQuery)).ToList();
        }

        protected virtual async Task<int> ExecuteAsync(string sql)
        {
            return await Connection.ExecuteAsync(sql);
        }

        #region IDisposable

        public bool CanDispose { get; set; }
        public void Dispose(bool disposing)
        {
            if (CanDispose && disposing && Connection != null && CanDispose) Connection.Dispose();
            CanDispose = false;
        }

        public void Dispose()
        {
            CanDispose = true;
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}