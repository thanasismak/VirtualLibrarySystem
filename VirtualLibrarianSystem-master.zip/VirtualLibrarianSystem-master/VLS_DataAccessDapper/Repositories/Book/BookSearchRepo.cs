﻿using Dapper;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessDapper.Abstract;

namespace VLS_DataAccessDapper.Repositories
{
    public sealed class BookSearchRepo : BaseRepository, IBookSearch
    {
        private string FixString(string value)
        {
            value = value.Replace("'", "").Replace("--", "-").Replace("\"", "");
            value = value.Replace(" ", "%");
            return value;
        }

        public async Task<List<BookSearchResultDto>> GetByValue(EnumBookSearchField bookSearchfield, string keyword,
            int pageIndex)
        {
            keyword = FixString(keyword);

            var sqlQuery =
                " select BookID, BookTitle,'' as BookDescription, PersonName, PersonKindDescription, PublishYear,publishMonth,Isbn13,CompanyName,CategoriesDescription,Rating,TotalRows " +
                " from (select ROW_NUMBER() OVER(order by b.BookID) AS RowNum, b.BookID, b.Title as BookTitle, p.Name as PersonName, pk.Description as PersonKindDescription, b.PublishYear,b.publishMonth, b.Isbn13,c.Name As CompanyName, " +
                "      (select Stuff((Select ',' + quotename(Category.Description) " +
                "                  from BookCategory, Category " +
                "                  where BookCategory.CategoryId = Category.CategoryId and BookCategory.BookId = b.BookId " +
                "                  group by Description, Category.CategoryId " +
                "                  order by Category.CategoryId " +
                "              for xml path(''), type).value('.', 'nvarchar(max)'),1,1,'') ) CategoriesDescription, " +
                "    (select avg(Rating) avgrating from BookRating br where BookId=b.BookId) as Rating,  " +
                "    TotalRows = Count(*) OVER() " +
                "    from Book b with(NOLOCK) " +
                "    inner join BookPerson bp WITH(nolock, INDEX(Idx_BookPerson_PersonKind_BookIdPersonId)) on b.BookId = bp.BookId  and bp.PersonKindId = 1  " +
                "    inner join Person p with(nolock)on bp.PersonId = p.PersonId " +
                "    inner join PersonKind pk with(nolock) on  bp.PersonKindId = pk.PersonKindId " +
                "    left outer join BookCompany bc WITH(nolock) on b.BookId = bc.BookId and bc.PersonKindId = 1 " +
                "    left outer join Company c WITH(nolock)on bc.CompanyId = c.CompanyId " +
                $"   where b.{bookSearchfield.ToString()} like '%{keyword}%'  " + "       ) AS result " +
                $" where RowNum >= {(pageIndex - 1)*20}  AND RowNum < {pageIndex*20} " +
                " order by RowNum";

            return (await Connection.QueryAsync<BookSearchResultDto>(sqlQuery)).ToList();
        }

        public async Task<List<BookSearchResultDto>> GetByPerson(int personKindId, string keyword, int pageIndex)
        {
            keyword = FixString(keyword);
            var sqlQuery =
                " select BookID, BookTitle,'' as BookDescription, PersonName, PersonKindDescription, PublishYear,publishMonth,Isbn13,CompanyName,CategoriesDescription,Rating,TotalRows " +
                " from (select ROW_NUMBER() OVER(order by b.BookID) AS RowNum, b.BookID, b.Title as BookTitle, p.Name as PersonName, pk.Description as PersonKindDescription, b.PublishYear,b.publishMonth, b.Isbn13,c.Name As CompanyName, " +
                "      (select Stuff((Select ',' + quotename(Category.Description) " +
                "                  from BookCategory, Category " +
                "                  where BookCategory.CategoryId = Category.CategoryId and BookCategory.BookId = b.BookId " +
                "                  group by Description, Category.CategoryId " +
                "                  order by Category.CategoryId " +
                "              for xml path(''), type).value('.', 'nvarchar(max)'),1,1,'') ) CategoriesDescription, " +
                "    (select avg(Rating) avgrating from BookRating br where BookId=b.BookId) as Rating,  " +
                "    TotalRows = Count(*) OVER() " +
                "    from Book b with(NOLOCK) " +
                "    inner join BookPerson bp WITH(nolock, INDEX(Idx_BookPerson_PersonKind_BookIdPersonId)) on b.BookId = bp.BookId " +
                "    inner join Person p with(nolock)on bp.PersonId = p.PersonId " +
                "    inner join PersonKind pk with(nolock) on  bp.PersonKindId = pk.PersonKindId " +
                "    left outer join BookCompany bc WITH(nolock) on b.BookId = bc.BookId and bc.PersonKindId = 1 " +
                "    left outer join Company c WITH(nolock)on bc.CompanyId = c.CompanyId " +
                $"   where bp.PersonKindId={personKindId} and p.Name like '%{keyword}%'  ) AS result " +
                $"   where RowNum >= {(pageIndex - 1)*20}  AND RowNum < {pageIndex*20} " +
                "   order by RowNum";

            return (await Connection.QueryAsync<BookSearchResultDto>(sqlQuery)).ToList();
        }

        public async Task<List<BookSearchResultDto>> GetById(int bookId)
        {
            var sqlQuery =
                " select b.BookID, b.Title as BookTitle, b.Description  BookDescription, p.Name as PersonName, pk.Description as PersonKindDescription, b.PublishYear,b.publishMonth, b.Isbn13,c.Name As CompanyName, " +
                "     (select Stuff((Select ',' + quotename(Category.Description) " +
                "      from BookCategory, Category " +
                "      where BookCategory.CategoryId = Category.CategoryId and BookCategory.BookId = b.BookId " +
                "      group by Description, Category.CategoryId " +
                "      order by Category.CategoryId " +
                "      for xml path(''), type).value('.', 'nvarchar(max)'),1,1,'') ) CategoriesDescription,  " +
                "      (select avg(Rating) avgrating from BookRating br where BookId=b.BookId) as Rating,  " +
                "    TotalRows = Count(*) OVER() " +
                " from Book b with(NOLOCK) " +
                "     left outer join BookPerson bp WITH(nolock, INDEX(Idx_BookPerson_PersonKind_BookIdPersonId)) on b.BookId = bp.BookId  and bp.PersonKindId = 1 " +
                "     left outer join Person p with(nolock)on bp.PersonId = p.PersonId " +
                "     left outer join PersonKind pk with(nolock) on  bp.PersonKindId = pk.PersonKindId " +
                "     left outer join BookCompany bc WITH(nolock) on b.BookId = bc.BookId and bc.PersonKindId = 1 " +
                "     left outer join Company c WITH(nolock)on bc.CompanyId = c.CompanyId " +
                $" where b.Bookid = {bookId}";
            return (await Connection.QueryAsync<BookSearchResultDto>(sqlQuery)).ToList();
        }

        public async Task<List<BookAvailabilityDto>> GetBookAvailability(int bookId)
        {
            var sqlQuery = " select l.LibraryId,l.Longitude,l.Latitude,l.Name as LibraryName,b.BookId,b.Title as BookTitle, lba.Quantity, (lba.Quantity - lba.QuantityReservation ) QuantityAvailable " +
                          " from Book b with(nolock) " +
                          " inner join LibraryBookAvailability lba  with(nolock) on b.BookId = lba.BookId " +
                          " inner join Library l with(nolock) on lba.LibraryId = l.LibraryId " +
                         $" where b.BookId = {bookId}";
            return (await Connection.QueryAsync<BookAvailabilityDto>(sqlQuery)).ToList();
        }

    }
}


