﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using VLS_DataAccessEntityFramework.EntityModel;

namespace VLS_DataAccessEntityFramework.Abstract
{
    public abstract class BaseRepository<TEntity> : IDisposable where TEntity : class
    {
        protected VLSDataModelEntitiesContext Dbcontext;
        
        protected BaseRepository()
        {  
            Dbcontext = new VLSDataModelEntitiesContext();
        }

        public virtual IQueryable<TEntity> AddWhere(IQueryable<TEntity> entity,Expression<Func<TEntity, bool>> where)
        {
            return entity.Where(where);
        }
        public virtual async Task<List<TEntity>> FindAsync(IQueryable<TEntity> entity)
        {
            var data = await entity.AsNoTracking().AsQueryable().ToListAsync();
            return data;
        }

        public virtual async Task<List<TEntity>> FindAsync(Expression<Func<TEntity, bool>> where)
        {
            var data = await Dbcontext.Set<TEntity>().AsNoTracking().AsQueryable().Where(where).ToListAsync();
            return  data;
        }

        public virtual TEntity Add(TEntity entity)
        {
            return Dbcontext.Set<TEntity>().Add(entity);
        }
        public virtual TEntity Modified(TEntity entity)
        {
            Dbcontext.Entry(entity).State = EntityState.Modified;
            return entity;
        }

        public virtual void Remove(long id)
        {
            var item = Dbcontext.Set<TEntity>().Find(id);
            Dbcontext.Set<TEntity>().Remove(item);
        }

        public virtual void Remove(TEntity entity)
        {
            Dbcontext.Entry(entity).State = EntityState.Deleted;
            Dbcontext.Set<TEntity>().Remove(entity);
        }

        public virtual async Task<int> SaveChangesAsync()
        {
            return await Dbcontext.SaveChangesAsync();
        }
        public IQueryable<T> Set<T>() where T : class
        {
            return Dbcontext.Set<T>();
        }

        #region IDisposable
        private bool _disposedValue;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposedValue)
            {
                if (disposing)
                {
                    Dbcontext.Dispose();
                }
                _disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}