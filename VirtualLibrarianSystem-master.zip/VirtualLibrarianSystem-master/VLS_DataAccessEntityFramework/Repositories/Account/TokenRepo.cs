﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class TokenRepo : BaseRepository<EntityModel.Token>, IToken
    {
        private IQueryable<EntityModel.Token> ApplyFilters(TokenDto filtersToken)
        {
            var entity = Set<EntityModel.Token>();
            if (filtersToken == null) return entity;

            if (filtersToken.TokenId != null) entity = AddWhere(entity, r => r.TokenId == filtersToken.TokenId);
            if (filtersToken.UserId != null) entity = AddWhere(entity, r => r.UserId == filtersToken.UserId);
            if (filtersToken.AuthToken != null) entity = AddWhere(entity, r => r.AuthToken == filtersToken.AuthToken);
            if (filtersToken.IssuedOn != null) entity = AddWhere(entity, r => r.IssuedOn == filtersToken.IssuedOn);
            if (filtersToken.ExpiresOn != null) entity = AddWhere(entity, r => r.ExpiresOn == filtersToken.ExpiresOn);

            return entity;
        }

        private EntityModel.Token ApplyData(TokenDto data, EntityModel.Token tokenEntity)
        {
            if (tokenEntity == null)
                tokenEntity = new EntityModel.Token();

            if (data == null) return tokenEntity;

            if (data.TokenId != null) tokenEntity.TokenId = data.TokenId.GetValueOrDefault();
            if (data.UserId != null) tokenEntity.UserId = data.UserId.GetValueOrDefault();
            if (data.AuthToken != null) tokenEntity.AuthToken = data.AuthToken;
            if (data.IssuedOn != null) tokenEntity.IssuedOn = data.IssuedOn.GetValueOrDefault();
            if (data.ExpiresOn != null) tokenEntity.ExpiresOn = data.ExpiresOn.GetValueOrDefault();

            return tokenEntity;
        }
        private List<TokenDto> TransformData(List<EntityModel.Token> data)
        {
            return data.Select(r => new TokenDto
            {
                TokenId = r.TokenId,
                UserId = r.UserId,
                UserName = r.User.UserName,
                AuthToken = r.AuthToken,
                IssuedOn = r.IssuedOn,
                ExpiresOn = r.ExpiresOn,
            }).ToList();
        }

        public async Task<List<TokenDto>> Get(TokenDto filtersToken)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersToken));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(TokenDto newToken)
        {
            if (newToken == null) return -1;
            var entity = ApplyData(newToken, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.TokenId;
        }

        public async Task<int> Update(int updTokenId, TokenDto updToken)
        {
            var tokenEntitys = await FindAsync(r => r.TokenId == updTokenId);
            var tokenEntity = tokenEntitys.FirstOrDefault();

            if (tokenEntity == null) return -1;
            tokenEntity = ApplyData(updToken, tokenEntity);
            Modified(tokenEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delTokenId)
        {
            var tokenEntitys = await FindAsync(r => r.TokenId == delTokenId);
            var tokenEntity = tokenEntitys.FirstOrDefault();

            if (tokenEntity == null) return -1;
            Remove(tokenEntity);
            return await SaveChangesAsync();
        }
    }
}
