﻿using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class UserRepo : BaseRepository<EntityModel.User>, IUser
    {
        public async Task<bool> CheckAuthorization(int userId, string businessEntity, string businessEntityAction)
        {
            var entity = Set<EntityModel.User>();
            entity = AddWhere(entity, r => r.UserId==userId);
            var users = await FindAsync(entity);
            var user = users.FirstOrDefault();
            var res = user?.Role.RoleBusinessEntities.FirstOrDefault(e => e.BusinessEntity.Name.ToUpper(CultureInfo.CurrentCulture) == businessEntity.ToUpper(CultureInfo.CurrentCulture));
            if (res == null) return false;
            if (businessEntityAction.ToUpper(CultureInfo.CurrentCulture) == "View".ToUpper(CultureInfo.CurrentCulture))
                return res.PermitView;
            if (businessEntityAction.ToUpper(CultureInfo.CurrentCulture) == "Insert".ToUpper(CultureInfo.CurrentCulture))
                return res.PermitInsert;
            if (businessEntityAction.ToUpper(CultureInfo.CurrentCulture) == "Update".ToUpper(CultureInfo.CurrentCulture))
                return res.PermitUpdate;
            if (businessEntityAction.ToUpper(CultureInfo.CurrentCulture) == "Delete".ToUpper(CultureInfo.CurrentCulture))
                return res.PermitDelete;
            return false;
        }

        private IQueryable<EntityModel.User> ApplyFilters(UserDto filtersUser)
        {
            var entity = Set<EntityModel.User>();
            if (filtersUser == null) return entity;

            if (filtersUser.UserId != null) entity = AddWhere(entity, r => r.UserId == filtersUser.UserId);
            if (filtersUser.UserName != null) entity = AddWhere(entity, r => r.UserName == filtersUser.UserName);
            if (filtersUser.Password != null) entity = AddWhere(entity, r => r.Password == filtersUser.Password);
            if (filtersUser.FirstName != null) entity = AddWhere(entity, r => r.FirstName == filtersUser.FirstName);
            if (filtersUser.LastName != null) entity = AddWhere(entity, r => r.LastName == filtersUser.LastName);
            if (filtersUser.Email != null) entity = AddWhere(entity, r => r.Email == filtersUser.Email);
            if (filtersUser.Phone != null) entity = AddWhere(entity, r => r.Phone == filtersUser.Phone);
            if (filtersUser.MobilePhone != null) entity = AddWhere(entity, r => r.MobilePhone == filtersUser.MobilePhone);
            if (filtersUser.Address != null) entity = AddWhere(entity, r => r.Address == filtersUser.Address);
            if (filtersUser.StudentCardNumber != null) entity = AddWhere(entity, r => r.StudentCardNumber == filtersUser.StudentCardNumber);
            if (filtersUser.IsActive != null) entity = AddWhere(entity, r => r.IsActive == filtersUser.IsActive);
            if (filtersUser.RoleId != null) entity = AddWhere(entity, r => r.RoleId == filtersUser.RoleId);
            if (filtersUser.RoleName != null) entity = AddWhere(entity, r => r.Role.Name == filtersUser.RoleName);

            return entity;
        }

 private EntityModel.User ApplyData(UserDto data, EntityModel.User userEntity)
        {
            if (userEntity == null)
                userEntity = new EntityModel.User();

            if (data == null) return userEntity;

            if (data.UserId != null) userEntity.UserId = data.UserId.GetValueOrDefault();
            if (data.UserName != null) userEntity.UserName = data.UserName;
            if (data.Password != null) userEntity.Password = data.Password;
            if (data.FirstName != null) userEntity.FirstName = data.FirstName;
            if (data.LastName != null) userEntity.LastName = data.LastName;
            if (data.Email != null) userEntity.Email = data.Email;
            if (data.Phone != null) userEntity.Phone = data.Phone;
            if (data.MobilePhone != null) userEntity.MobilePhone = data.MobilePhone;
            if (data.Address != null) userEntity.Address = data.Address;
            if (data.StudentCardNumber != null) userEntity.StudentCardNumber = data.StudentCardNumber;
            if (data.IsActive != null) userEntity.IsActive = data.IsActive.GetValueOrDefault();
            if (data.RoleId != null) userEntity.RoleId = data.RoleId.GetValueOrDefault();
       
            return userEntity;
        }

        private List<UserDto> TransformData(List<EntityModel.User> data)
        {
            return data.Select(r => new UserDto
            {
                UserId = r.UserId,
                UserName = r.UserName,
                Password = r.Password,
                FirstName = r.FirstName,
                LastName = r.LastName,
                Email=r.Email,
                Phone = r.Phone,
                MobilePhone = r.MobilePhone,
                Address = r.Address,
                StudentCardNumber = r.StudentCardNumber,
                IsActive = r.IsActive,
                RoleId = r.RoleId,
                RoleName = r.Role.Name
            }).ToList();
        }

        public async Task<List<UserDto>> Get(UserDto filtersUser)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersUser));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(UserDto newUser)
        {
            if (newUser == null) return -1;
            var entity = ApplyData(newUser, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.UserId;
        }

        public async Task<int> Update(int updUserId, UserDto updUser)
        {
            var userEntitys = await FindAsync(r => r.UserId == updUserId);
            var userEntity = userEntitys.FirstOrDefault();

            if (userEntity == null) return -1;
            userEntity = ApplyData(updUser, userEntity);
            Modified(userEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delUserId)
        {
            var userEntitys = await FindAsync(r => r.UserId == delUserId);
            var userEntity = userEntitys.FirstOrDefault();

            if (userEntity == null) return -1;
            Remove(userEntity);
            return await SaveChangesAsync();
        }
    }
}
