﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class RoleRepo : BaseRepository<EntityModel.Role>, IRole
    {
        private IQueryable<EntityModel.Role> ApplyFilters(RoleDto filtersRole)
        {
            var entity = Set<EntityModel.Role>();
            if (filtersRole == null) return entity;

            if (filtersRole.RoleId != null) entity = AddWhere(entity, r => r.RoleId == filtersRole.RoleId);
            if (filtersRole.Name != null) entity = AddWhere(entity, r => r.Name == filtersRole.Name);

            return entity;
        }

        private EntityModel.Role ApplyData(RoleDto data, EntityModel.Role roleEntity)
        {
            if (roleEntity == null)
                roleEntity = new EntityModel.Role();

            if (data == null) return roleEntity;

            if (data.RoleId != null) roleEntity.RoleId = data.RoleId.GetValueOrDefault();
            if (data.Name != null) roleEntity.Name = data.Name;

            return roleEntity;
        }
        private List<RoleDto> TransformData(List<EntityModel.Role> data)
        {
            return data.Select(r => new RoleDto
            {
                RoleId = r.RoleId,
                Name = r.Name,
            }).ToList();
        }

        public async Task<List<RoleDto>> Get(RoleDto filtersRole)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersRole));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(RoleDto newRole)
        {
            if (newRole == null) return -1;
            var entity = ApplyData(newRole, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.RoleId;
        }

        public async Task<int> Update(int updRoleId, RoleDto updRole)
        {
            var roleEntitys = await FindAsync(r => r.RoleId == updRoleId);
            var roleEntity = roleEntitys.FirstOrDefault();

            if (roleEntity == null) return -1;
            roleEntity = ApplyData(updRole, roleEntity);
            Modified(roleEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delRoleId)
        {
            var roleEntitys = await FindAsync(r => r.RoleId == delRoleId);
            var roleEntity = roleEntitys.FirstOrDefault();

            if (roleEntity == null) return -1;
            Remove(roleEntity);
            return await SaveChangesAsync();
        }
    }
}
