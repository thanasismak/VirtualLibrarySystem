﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_Models.ModelsDto.Account;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class RoleBusinessEntityRepo : BaseRepository<EntityModel.RoleBusinessEntity>, IRoleBusinessEntity
    {
        private IQueryable<EntityModel.RoleBusinessEntity> ApplyFilters(RoleBusinessEntityDto filtersRoleBusinessEntity)
        {
            var entity = Set<EntityModel.RoleBusinessEntity>();
            if (filtersRoleBusinessEntity == null) return entity;

            if (filtersRoleBusinessEntity.RoleBusinessEntityId != null) entity = AddWhere(entity, r => r.RoleBusinessEntityId == filtersRoleBusinessEntity.RoleBusinessEntityId);
            if (filtersRoleBusinessEntity.RoleId != null) entity = AddWhere(entity, r => r.RoleId == filtersRoleBusinessEntity.RoleId);
            if (filtersRoleBusinessEntity.BusinessEntityId != null) entity = AddWhere(entity, r => r.BusinessEntityId == filtersRoleBusinessEntity.BusinessEntityId);
            if (filtersRoleBusinessEntity.PermitView != null) entity = AddWhere(entity, r => r.PermitView == filtersRoleBusinessEntity.PermitView);
            if (filtersRoleBusinessEntity.PermitInsert != null) entity = AddWhere(entity, r => r.PermitInsert == filtersRoleBusinessEntity.PermitInsert);
            if (filtersRoleBusinessEntity.PermitUpdate != null) entity = AddWhere(entity, r => r.PermitUpdate == filtersRoleBusinessEntity.PermitUpdate);
            if (filtersRoleBusinessEntity.PermitDelete != null) entity = AddWhere(entity, r => r.PermitDelete == filtersRoleBusinessEntity.PermitDelete);
            if (filtersRoleBusinessEntity.BusinessEntityName != null) entity = AddWhere(entity, r => r.BusinessEntity.Name == filtersRoleBusinessEntity.BusinessEntityName);
            if (filtersRoleBusinessEntity.RoleName != null) entity = AddWhere(entity, r => r.Role.Name == filtersRoleBusinessEntity.RoleName);

            return entity;
        }

        private EntityModel.RoleBusinessEntity ApplyData(RoleBusinessEntityDto data, EntityModel.RoleBusinessEntity roleBusinessEntityEntity)
        {
            if (roleBusinessEntityEntity == null)
                roleBusinessEntityEntity = new EntityModel.RoleBusinessEntity();

            if (data == null) return roleBusinessEntityEntity;

            if (data.RoleBusinessEntityId != null) roleBusinessEntityEntity.RoleBusinessEntityId = data.RoleBusinessEntityId.GetValueOrDefault();
            if (data.RoleId != null) roleBusinessEntityEntity.RoleId = data.RoleId.GetValueOrDefault();
            if (data.BusinessEntityId != null) roleBusinessEntityEntity.BusinessEntityId = data.BusinessEntityId.GetValueOrDefault();
            if (data.PermitView != null) roleBusinessEntityEntity.PermitView = data.PermitView.GetValueOrDefault();
            if (data.PermitInsert != null) roleBusinessEntityEntity.PermitInsert = data.PermitInsert.GetValueOrDefault();
            if (data.PermitUpdate != null) roleBusinessEntityEntity.PermitUpdate = data.PermitUpdate.GetValueOrDefault();
            if (data.PermitDelete != null) roleBusinessEntityEntity.PermitDelete = data.PermitDelete.GetValueOrDefault();

            return roleBusinessEntityEntity;
        }
        private List<RoleBusinessEntityDto> TransformData(List<EntityModel.RoleBusinessEntity> data)
        {
            return data.Select(r => new RoleBusinessEntityDto
            {
                RoleBusinessEntityId = r.RoleBusinessEntityId,
                RoleId = r.RoleId,
                BusinessEntityId = r.BusinessEntityId,
                PermitView = r.PermitView,
                PermitInsert = r.PermitInsert,
                PermitUpdate = r.PermitUpdate,
                PermitDelete = r.PermitDelete,
                BusinessEntityName = r.BusinessEntity.Name,
                RoleName = r.Role.Name
            }).ToList();
        }

        public async Task<List<RoleBusinessEntityDto>> Get(RoleBusinessEntityDto filtersRoleBusinessEntity)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersRoleBusinessEntity));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(RoleBusinessEntityDto newRoleBusinessEntity)
        {
            if (newRoleBusinessEntity == null) return -1;
            var entity = ApplyData(newRoleBusinessEntity, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.RoleBusinessEntityId;
        }

        public async Task<int> Update(int updRoleBusinessEntityId, RoleBusinessEntityDto updRoleBusinessEntity)
        {
            var roleBusinessEntityEntitys = await FindAsync(r => r.RoleBusinessEntityId == updRoleBusinessEntityId);
            var roleBusinessEntityEntity = roleBusinessEntityEntitys.FirstOrDefault();

            if (roleBusinessEntityEntity == null) return -1;
            roleBusinessEntityEntity = ApplyData(updRoleBusinessEntity, roleBusinessEntityEntity);
            Modified(roleBusinessEntityEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delRoleBusinessEntityId)
        {
            Remove(delRoleBusinessEntityId);
            var roleBusinessEntityEntitys = await FindAsync(r => r.RoleBusinessEntityId == delRoleBusinessEntityId);
            var roleBusinessEntityEntity = roleBusinessEntityEntitys.FirstOrDefault();

            if (roleBusinessEntityEntity == null) return -1;
            Remove(roleBusinessEntityEntity);
            return await SaveChangesAsync();
        }
    }
}
