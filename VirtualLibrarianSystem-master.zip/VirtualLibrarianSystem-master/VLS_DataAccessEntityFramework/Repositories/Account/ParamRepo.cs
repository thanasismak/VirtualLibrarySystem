﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_Models.ModelsDto.Account;
using VLS_BusinessLayer.Interfaces.Repositories.Account;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class ParamRepo : BaseRepository<EntityModel.Param>, IParam
    {
        private IQueryable<EntityModel.Param> ApplyFilters(ParamDto filtersParam)
        {
            var entity = Set<EntityModel.Param>();

            if (filtersParam == null) return entity;
            if (filtersParam.ParamId != null) entity = AddWhere(entity, r => r.ParamId == filtersParam.ParamId);
            if (filtersParam.Code != null) entity = AddWhere(entity, r => r.Code == filtersParam.Code);
            if (filtersParam.Value != null) entity = AddWhere(entity, r => r.Value == filtersParam.Value);
            if (filtersParam.Description != null) entity = AddWhere(entity, r => r.Description == filtersParam.Description);
            return entity;
        }

        private EntityModel.Param ApplyData(ParamDto data, EntityModel.Param paramEntity)
        {
            if (paramEntity == null)
                paramEntity = new EntityModel.Param();

            if (data == null) return paramEntity;

            if (data.ParamId != null) paramEntity.ParamId = data.ParamId.GetValueOrDefault();
            if (data.Code != null) paramEntity.Code = data.Code;
            if (data.Value != null) paramEntity.Value = data.Value;
            if (data.Description != null) paramEntity.Description = data.Description;

            return paramEntity;
        }
        private List<ParamDto> TransformData(List<EntityModel.Param> data)
        {
            return data.Select(r => new ParamDto
            {
                ParamId = r.ParamId,
                Code = r.Code,
                Value = r.Value,
                Description = r.Description,
            }).ToList();
        }

        public async Task<List<ParamDto>> Get(ParamDto filtersParam)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersParam));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(ParamDto newParam)
        {
            if (newParam == null) return -1;
            var entity = ApplyData(newParam, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.ParamId;
        }

        public async Task<int> Update(int updParamId, ParamDto updParam)
        {
            var paramEntitys = await FindAsync(r => r.ParamId == updParamId);
            var paramEntity = paramEntitys.FirstOrDefault();

            if (paramEntity == null) return -1;
            paramEntity = ApplyData(updParam, paramEntity);
            Modified(paramEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delParamId)
        {
            var paramEntitys = await FindAsync(r => r.ParamId == delParamId);
            var paramEntity = paramEntitys.FirstOrDefault();

            if (paramEntity == null) return -1;
            Remove(paramEntity);
            return await SaveChangesAsync();
        }
    }
}
