﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class PersonKindRepo : BaseRepository<EntityModel.PersonKind>, IPersonKind
    {
        private IQueryable<EntityModel.PersonKind> ApplyFilters(PersonKindDto filtersPersonKind)
        {
            var entity = Set<EntityModel.PersonKind>();
            if (filtersPersonKind == null) return entity;

            if (filtersPersonKind.PersonKindId != null) entity = AddWhere(entity, r => r.PersonKindId == filtersPersonKind.PersonKindId);
            if (filtersPersonKind.Description != null) entity = AddWhere(entity, r => r.Description == filtersPersonKind.Description);

            return entity;
        }

        private EntityModel.PersonKind ApplyData(PersonKindDto data, EntityModel.PersonKind personKindEntity)
        {
            if (personKindEntity == null)
                personKindEntity = new EntityModel.PersonKind();

            if (data == null) return personKindEntity;

            if (data.PersonKindId != null) personKindEntity.PersonKindId = data.PersonKindId.GetValueOrDefault();
            if (data.Description != null) personKindEntity.Description = data.Description;

            return personKindEntity;
        }
        private List<PersonKindDto> TransformData(List<EntityModel.PersonKind> data)
        {
            return data.Select(r => new PersonKindDto
            {
                PersonKindId = r.PersonKindId,
                Description = r.Description,
            }).ToList();
        }

        public async Task<List<PersonKindDto>> Get(PersonKindDto filtersPersonKind)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersPersonKind));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(PersonKindDto newPersonKind)
        {
            if (newPersonKind == null) return -1;
            var entity = ApplyData(newPersonKind, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.PersonKindId;
        }

        public async Task<int> Update(int updPersonKindId, PersonKindDto updPersonKind)
        {
            var personKindEntitys = await FindAsync(r => r.PersonKindId == updPersonKindId);
            var personKindEntity = personKindEntitys.FirstOrDefault();

            if (personKindEntity == null) return -1;
            personKindEntity = ApplyData(updPersonKind, personKindEntity);
            Modified(personKindEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delPersonKindId)
        {
            var personKindEntitys = await FindAsync(r => r.PersonKindId == delPersonKindId);
            var personKindEntity = personKindEntitys.FirstOrDefault();

            if (personKindEntity == null) return -1;
            Remove(personKindEntity);
            return await SaveChangesAsync();
        }
    }
}
