﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;


namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class BookRepo : BaseRepository<EntityModel.Book>, IBook
    {
        private IQueryable<EntityModel.Book> ApplyFilters(BookDto filtersBook)
        {
            var entity = Set<EntityModel.Book>();
            if (filtersBook == null) return entity;

            if (filtersBook.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersBook.BookId);
            if (filtersBook.Title != null) entity = AddWhere(entity, r => r.Title == filtersBook.Title);
            if (filtersBook.SubTitle != null) entity = AddWhere(entity, r => r.SubTitle == filtersBook.SubTitle);
            if (filtersBook.OriginTitle != null) entity = AddWhere(entity, r => r.OriginTitle == filtersBook.OriginTitle);
            if (filtersBook.Description != null) entity = AddWhere(entity, r => r.Description == filtersBook.Description);
            if (filtersBook.PublishYear != null) entity = AddWhere(entity, r => r.PublishYear == filtersBook.PublishYear);
            if (filtersBook.PublishMonth != null) entity = AddWhere(entity, r => r.PublishMonth == filtersBook.PublishMonth);
            if (filtersBook.Pages != null) entity = AddWhere(entity, r => r.Pages == filtersBook.Pages);
            if (filtersBook.Isbn != null) entity = AddWhere(entity, r => r.ISBN == filtersBook.Isbn);
            if (filtersBook.Isbn13 != null) entity = AddWhere(entity, r => r.ISBN13 == filtersBook.Isbn13);
            
            return entity;
        }

        private EntityModel.Book ApplyData(BookDto data, EntityModel.Book bookEntity)
        {
            if (bookEntity == null)
                bookEntity = new EntityModel.Book();

            if (data == null) return bookEntity;

            if (data.BookId != null) bookEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.Title != null) bookEntity.Title = data.Title;
            if (data.SubTitle != null) bookEntity.SubTitle = data.SubTitle;
            if (data.OriginTitle != null) bookEntity.OriginTitle = data.OriginTitle;
            if (data.Description != null) bookEntity.Description = data.Description;
            if (data.PublishYear != null) bookEntity.PublishYear = data.PublishYear;
            if (data.PublishMonth != null) bookEntity.PublishMonth = data.PublishMonth;
            if (data.Pages != null) bookEntity.Pages = data.Pages;
            if (data.Isbn != null) bookEntity.ISBN = data.Isbn;
            if (data.Isbn13 != null) bookEntity.ISBN13 = data.Isbn13;
            
            return bookEntity;
        }
        private List<BookDto> TransformData(List<EntityModel.Book> data)
        {
            return data.Select(r => new BookDto
            {
                BookId = r.BookId,
                Title = r.Title,
                SubTitle = r.SubTitle,
                OriginTitle = r.OriginTitle,
                Description = r.Description,
                PublishYear = r.PublishYear,
                PublishMonth = r.PublishMonth,
                Pages = r.Pages,
                Isbn = r.ISBN,
                Isbn13 = r.ISBN13,
            }).ToList();
        }

        public async Task<List<BookDto>> Get(BookDto filtersBook)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersBook));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(BookDto newBook)
        {
            if (newBook == null) return -1;
            var entity = ApplyData(newBook, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.BookId;
        }

        public async Task<int> Update(int updBookId, BookDto updBook)
        {
            var bookEntitys = await FindAsync(r => r.BookId == updBookId);
            var bookEntity = bookEntitys.FirstOrDefault();

            if (bookEntity == null) return -1;
            bookEntity = ApplyData(updBook, bookEntity);
            Modified(bookEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delBookId)
        {
            var bookEntitys = await FindAsync(r => r.BookId == delBookId);
            var bookEntity = bookEntitys.FirstOrDefault();

            if (bookEntity == null) return -1;
            Remove(bookEntity);
            return await SaveChangesAsync();
        }
    }
}
