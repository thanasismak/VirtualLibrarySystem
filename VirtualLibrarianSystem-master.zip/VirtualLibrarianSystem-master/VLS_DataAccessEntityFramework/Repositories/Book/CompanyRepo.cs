﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class CompanyRepo : BaseRepository<EntityModel.Company>, ICompany
    {
        private IQueryable<EntityModel.Company> ApplyFilters(CompanyDto filtersCompany)
        {
            var entity = Set<EntityModel.Company>();
            if (filtersCompany == null) return entity;

            if (filtersCompany.CompanyId != null) entity = AddWhere(entity, r => r.CompanyId == filtersCompany.CompanyId);
            if (filtersCompany.Name != null) entity = AddWhere(entity, r => r.Name == filtersCompany.Name);
            if (filtersCompany.Address != null) entity = AddWhere(entity, r => r.Address == filtersCompany.Address);
            if (filtersCompany.Email != null) entity = AddWhere(entity, r => r.Email == filtersCompany.Email);
            if (filtersCompany.WebSite != null) entity = AddWhere(entity, r => r.WebSite == filtersCompany.WebSite);
            if (filtersCompany.Phone1 != null) entity = AddWhere(entity, r => r.Phone1 == filtersCompany.Phone1);
            if (filtersCompany.Phone2 != null) entity = AddWhere(entity, r => r.Phone2 == filtersCompany.Phone2);
            if (filtersCompany.Phone3 != null) entity = AddWhere(entity, r => r.Phone3 == filtersCompany.Phone3);
            if (filtersCompany.Fax != null) entity = AddWhere(entity, r => r.Fax == filtersCompany.Fax);

            return entity;
        }

        private EntityModel.Company ApplyData(CompanyDto data, EntityModel.Company companyEntity)
        {
            if (companyEntity == null)
                companyEntity = new EntityModel.Company();

            if (data == null) return companyEntity;

            if (data.CompanyId != null) companyEntity.CompanyId = data.CompanyId.GetValueOrDefault();
            if (data.Name != null) companyEntity.Name = data.Name;
            if (data.Address != null) companyEntity.Address = data.Address;
            if (data.Email != null) companyEntity.Email = data.Email;
            if (data.WebSite != null) companyEntity.WebSite = data.WebSite;
            if (data.Phone1 != null) companyEntity.Phone1 = data.Phone1;
            if (data.Phone2 != null) companyEntity.Phone2 = data.Phone2;
            if (data.Phone3 != null) companyEntity.Phone3 = data.Phone3;
            if (data.Fax != null) companyEntity.Fax = data.Fax;

            return companyEntity;
        }
        private List<CompanyDto> TransformData(List<EntityModel.Company> data)
        {
            return data.Select(r => new CompanyDto
            {
                CompanyId = r.CompanyId,
                Name = r.Name,
                Address = r.Address,
                Email = r.Email,
                WebSite=r.WebSite,
                Phone1=r.Phone1,
                Phone2= r.Phone2,
                Phone3=r.Phone3,
                Fax=r.Fax
            }).ToList();
        }

        public async Task<List<CompanyDto>> Get(CompanyDto filtersCompany)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersCompany));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(CompanyDto newCompany)
        {
            if (newCompany == null) return -1;
            var entity = ApplyData(newCompany, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.CompanyId;
        }

        public async Task<int> Update(int updCompanyId, CompanyDto updCompany)
        {
            var companyEntitys = await FindAsync(r => r.CompanyId == updCompanyId);
            var companyEntity = companyEntitys.FirstOrDefault();

            if (companyEntity == null) return -1;
            companyEntity = ApplyData(updCompany, companyEntity);
            Modified(companyEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delCompanyId)
        {
            var companyEntitys = await FindAsync(r => r.CompanyId == delCompanyId);
            var companyEntity = companyEntitys.FirstOrDefault();

            if (companyEntity == null) return -1;
            Remove(companyEntity);
            return await SaveChangesAsync();
        }
    }
}
