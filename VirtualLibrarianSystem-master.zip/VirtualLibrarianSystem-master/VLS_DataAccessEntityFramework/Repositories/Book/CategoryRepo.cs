﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class CategoryRepo : BaseRepository<EntityModel.Category>, ICategory
    {
        private IQueryable<EntityModel.Category> ApplyFilters(CategoryDto filtersCategory)
        {
            var entity = Set<EntityModel.Category>();
            if (filtersCategory == null) return entity;

            if (filtersCategory.CategoryId != null) entity = AddWhere(entity, r => r.CategoryId == filtersCategory.CategoryId);
            if (filtersCategory.Code != null) entity = AddWhere(entity, r => r.Code == filtersCategory.Code);
            if (filtersCategory.Description != null) entity = AddWhere(entity, r => r.Description == filtersCategory.Description);
            if (filtersCategory.ParentCategoryId != null) entity = AddWhere(entity, r => r.ParentCategoryId == filtersCategory.ParentCategoryId);

            return entity;
        }

        private EntityModel.Category ApplyData(CategoryDto data, EntityModel.Category categoryEntity)
        {
            if (categoryEntity == null)
                categoryEntity = new EntityModel.Category();

            if (data == null) return categoryEntity;

            if (data.CategoryId != null) categoryEntity.CategoryId = data.CategoryId.GetValueOrDefault();
            if (data.Code != null) categoryEntity.Code = data.Code;
            if (data.Description != null) categoryEntity.Description = data.Description;
            if (data.ParentCategoryId != null) categoryEntity.ParentCategoryId = data.ParentCategoryId.GetValueOrDefault();

            return categoryEntity;
        }
        private List<CategoryDto> TransformData(List<EntityModel.Category> data)
        {
            return data.Select(r => new CategoryDto
            {
                CategoryId = r.CategoryId,
                Code = r.Code,
                Description = r.Description,
                ParentCategoryId = r.ParentCategoryId,
            }).ToList();
        }

        public async Task<List<CategoryDto>> Get(CategoryDto filtersCategory)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersCategory));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(CategoryDto newCategory)
        {
            if (newCategory == null) return -1;
            var entity = ApplyData(newCategory, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.CategoryId;
        }

        public async Task<int> Update(int updCategoryId, CategoryDto updCategory)
        {
            var categoryEntitys = await FindAsync(r => r.CategoryId == updCategoryId);
            var categoryEntity = categoryEntitys.FirstOrDefault();

            if (categoryEntity == null) return -1;
            categoryEntity = ApplyData(updCategory, categoryEntity);
            Modified(categoryEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delCategoryId)
        {
            var categoryEntitys = await FindAsync(r => r.CategoryId == delCategoryId);
            var categoryEntity = categoryEntitys.FirstOrDefault();

            if (categoryEntity == null) return -1;
            Remove(categoryEntity);
            return await SaveChangesAsync();
        }
    }
}
