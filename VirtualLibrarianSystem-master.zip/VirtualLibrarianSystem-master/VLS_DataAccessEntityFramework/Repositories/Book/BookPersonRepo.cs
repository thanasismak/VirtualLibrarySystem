﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
   public sealed class BookPersonRepo : BaseRepository<EntityModel.BookPerson>, IBookPerson
    {
        private IQueryable<EntityModel.BookPerson> ApplyFilters(BookPersonDto filtersBookPerson)
        {
            var entity = Set<EntityModel.BookPerson>();
            if (filtersBookPerson == null) return entity;

            if (filtersBookPerson.BookPersonId != null) entity = AddWhere(entity, r => r.BookPersonId == filtersBookPerson.BookPersonId);
            if (filtersBookPerson.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersBookPerson.BookId);
            if (filtersBookPerson.PersonId != null) entity = AddWhere(entity, r => r.PersonId == filtersBookPerson.PersonId);
            if (filtersBookPerson.PersonKindId != null) entity = AddWhere(entity, r => r.PersonKindId == filtersBookPerson.PersonKindId);
            if (filtersBookPerson.PersonKindDescription != null) entity = AddWhere(entity, r => r.PersonKind.Description == filtersBookPerson.PersonKindDescription);
            if (filtersBookPerson.PersonName != null) entity = AddWhere(entity, r => r.Person.Name == filtersBookPerson.PersonName);

            return entity;
        }

        private EntityModel.BookPerson ApplyData(BookPersonDto data,EntityModel.BookPerson bookPersonEntity)
        { 
            if (bookPersonEntity==null)
                bookPersonEntity = new EntityModel.BookPerson();

            if (data == null) return bookPersonEntity;

            if (data.BookPersonId != null) bookPersonEntity.BookPersonId = data.BookPersonId.GetValueOrDefault();
            if (data.BookId != null) bookPersonEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.PersonId != null) bookPersonEntity.PersonId = data.PersonId.GetValueOrDefault();
            if (data.PersonKindId != null) bookPersonEntity.PersonKindId = data.PersonKindId.GetValueOrDefault();
            
            return bookPersonEntity;
       }
        private List<BookPersonDto> TransformData(List<EntityModel.BookPerson> data)
        {
            return data.Select(r => new BookPersonDto
            {
                BookPersonId = r.BookPersonId,BookId = r.BookId,PersonId = r.PersonId,PersonKindId = r.PersonKindId,
                PersonKindDescription = r.PersonKind.Description,PersonName = r.Person.Name
            }).ToList();
        }

        public async Task<List<BookPersonDto>> Get(BookPersonDto filtersBookPerson)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersBookPerson));
            return TransformData(searchresult);
        }

       public async Task<int> Insert(BookPersonDto newBookPerson)
        {
           if (newBookPerson == null) return -1;
            var entity = ApplyData(newBookPerson, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.BookPersonId;
        }

        public async Task<int> Update(int updBookPersonId,BookPersonDto updBookPerson)
        {
            var bookPersonEntitys = await FindAsync(r => r.BookPersonId == updBookPersonId);
            var bookPersonEntity = bookPersonEntitys.FirstOrDefault();

            if (bookPersonEntity == null) return -1;
            bookPersonEntity = ApplyData(updBookPerson, bookPersonEntity);
            Modified(bookPersonEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delBookPersonId)
        {
            var bookPersonEntitys = await FindAsync(r => r.BookPersonId == delBookPersonId);
            var bookPersonEntity = bookPersonEntitys.FirstOrDefault();

            if (bookPersonEntity == null) return -1;
            Remove(bookPersonEntity);
            return await SaveChangesAsync();
        }
    }
}
