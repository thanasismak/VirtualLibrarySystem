﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class BookCompanyRepo : BaseRepository<EntityModel.BookCompany>, IBookCompany
    {
        private IQueryable<EntityModel.BookCompany> ApplyFilters(BookCompanyDto filtersBookCompany)
        {
            var entity = Set<EntityModel.BookCompany>();
            if (filtersBookCompany == null) return entity;

            if (filtersBookCompany.BookCompanyId != null) entity = AddWhere(entity, r => r.BookCompanyId == filtersBookCompany.BookCompanyId);
            if (filtersBookCompany.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersBookCompany.BookId);
            if (filtersBookCompany.CompanyId != null) entity = AddWhere(entity, r => r.CompanyId == filtersBookCompany.CompanyId);
            if (filtersBookCompany.PersonKindId != null) entity = AddWhere(entity, r => r.PersonKindId == filtersBookCompany.PersonKindId);
            if (filtersBookCompany.PersonKindDescription != null) entity = AddWhere(entity, r => r.PersonKind.Description == filtersBookCompany.PersonKindDescription);
            if (filtersBookCompany.CompanyName != null) entity = AddWhere(entity, r => r.Company.Name == filtersBookCompany.CompanyName);

            return entity;
        }

        private EntityModel.BookCompany ApplyData(BookCompanyDto data, EntityModel.BookCompany bookCompanyEntity)
        {
            if (bookCompanyEntity == null)
                bookCompanyEntity = new EntityModel.BookCompany();

            if (data == null) return bookCompanyEntity;

            if (data.BookCompanyId != null) bookCompanyEntity.BookCompanyId = data.BookCompanyId.GetValueOrDefault();
            if (data.BookId != null) bookCompanyEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.CompanyId != null) bookCompanyEntity.CompanyId = data.CompanyId.GetValueOrDefault();
            if (data.PersonKindId != null) bookCompanyEntity.PersonKindId = data.PersonKindId.GetValueOrDefault();

            return bookCompanyEntity;
        }
        private List<BookCompanyDto> TransformData(List<EntityModel.BookCompany> data)
        {
            return data.Select(r => new BookCompanyDto
            {
                BookCompanyId = r.BookCompanyId,
                BookId = r.BookId,
                CompanyId = r.CompanyId,
                PersonKindId = r.PersonKindId,
                PersonKindDescription = r.PersonKind.Description,
                CompanyName = r.Company.Name
            }).ToList();
        }

        public async Task<List<BookCompanyDto>> Get(BookCompanyDto filtersBookCompany)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersBookCompany));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(BookCompanyDto newBookCompany)
        {
            if (newBookCompany == null) return -1;
            var entity = ApplyData(newBookCompany, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.BookCompanyId;
        }

        public async Task<int> Update(int updBookCompanyId, BookCompanyDto updBookCompany)
        {
            var bookCompanyEntitys = await FindAsync(r => r.BookCompanyId == updBookCompanyId);
            var bookCompanyEntity = bookCompanyEntitys.FirstOrDefault();

            if (bookCompanyEntity == null) return -1;
            bookCompanyEntity = ApplyData(updBookCompany, bookCompanyEntity);
            Modified(bookCompanyEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delBookCompanyId)
        {
            var bookCompanyEntitys = await FindAsync(r => r.BookCompanyId == delBookCompanyId);
            var bookCompanyEntity = bookCompanyEntitys.FirstOrDefault();

            if (bookCompanyEntity == null) return -1;
            Remove(bookCompanyEntity);
            return await SaveChangesAsync();
        }
    }
}
