﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
   public sealed class BookCategoryRepo : BaseRepository<EntityModel.BookCategory>, IBookCategory
    {
        private IQueryable<EntityModel.BookCategory> ApplyFilters(BookCategoryDto filtersBookCategory)
        {
            var entity = Set<EntityModel.BookCategory>();
            if (filtersBookCategory == null) return entity;

            if (filtersBookCategory.BookCategoryId != null) entity = AddWhere(entity, r => r.BookCategoryId == filtersBookCategory.BookCategoryId);
            if (filtersBookCategory.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersBookCategory.BookId);
            if (filtersBookCategory.CategoryId != null) entity = AddWhere(entity, r => r.CategoryId == filtersBookCategory.CategoryId);
            if (filtersBookCategory.CategoryDescription != null) entity = AddWhere(entity, r => r.Category.Description == filtersBookCategory.CategoryDescription);

            return entity;
        }

        private EntityModel.BookCategory ApplyData(BookCategoryDto data,EntityModel.BookCategory bookCategoryEntity)
        { 
            if (bookCategoryEntity==null)
                bookCategoryEntity = new EntityModel.BookCategory();

            if (data == null) return bookCategoryEntity;

            if (data.BookCategoryId != null) bookCategoryEntity.BookCategoryId = data.BookCategoryId.GetValueOrDefault();
            if (data.BookId != null) bookCategoryEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.CategoryId != null) bookCategoryEntity.CategoryId = data.CategoryId.GetValueOrDefault();

            return bookCategoryEntity;
       }
        private List<BookCategoryDto> TransformData(List<EntityModel.BookCategory> data)
        {
            return data.Select(r => new BookCategoryDto
            {
                BookCategoryId = r.BookCategoryId,
                BookId = r.BookId,
                CategoryId = r.CategoryId,
                CategoryDescription = r.Category.Description
            }).ToList();
        }

        public async Task<List<BookCategoryDto>> Get(BookCategoryDto filtersBookCategory)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersBookCategory));
            return TransformData(searchresult);
        }

       public async Task<int> Insert(BookCategoryDto newBookCategory)
        {
           if (newBookCategory == null) return -1;
            var entity = ApplyData(newBookCategory, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.BookCategoryId;
        }

        public async Task<int> Update(int updBookCategoryId,BookCategoryDto updBookCategory)
        {
            var bookCategoryEntitys = await FindAsync(r => r.BookCategoryId == updBookCategoryId);
            var bookCategoryEntity = bookCategoryEntitys.FirstOrDefault();

            if (bookCategoryEntity == null) return -1;
            bookCategoryEntity = ApplyData(updBookCategory, bookCategoryEntity);
            Modified(bookCategoryEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delBookCategoryId)
        {
            var bookCategoryEntitys = await FindAsync(r => r.BookCategoryId == delBookCategoryId);
            var bookCategoryEntity = bookCategoryEntitys.FirstOrDefault();

            if (bookCategoryEntity == null) return -1;
            Remove(bookCategoryEntity);
            return await SaveChangesAsync();
        }
    }
}
