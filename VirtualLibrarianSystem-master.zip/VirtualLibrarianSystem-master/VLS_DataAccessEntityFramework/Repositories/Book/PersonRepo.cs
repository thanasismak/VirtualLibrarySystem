﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class PersonRepo : BaseRepository<EntityModel.Person>, IPerson
    {
        private IQueryable<EntityModel.Person> ApplyFilters(PersonDto filtersPerson)
        {
            var entity = Set<EntityModel.Person>();
            if (filtersPerson == null) return entity;

            if (filtersPerson.PersonId != null) entity = AddWhere(entity, r => r.PersonId == filtersPerson.PersonId);
            if (filtersPerson.Name != null) entity = AddWhere(entity, r => r.Name == filtersPerson.Name);
            if (filtersPerson.Description != null) entity = AddWhere(entity, r => r.Description == filtersPerson.Description);
            if (filtersPerson.Email != null) entity = AddWhere(entity, r => r.Email == filtersPerson.Email);
            if (filtersPerson.WebSite != null) entity = AddWhere(entity, r => r.WebSite == filtersPerson.WebSite);

            return entity;
        }

        private EntityModel.Person ApplyData(PersonDto data, EntityModel.Person companyEntity)
        {
            if (companyEntity == null)
                companyEntity = new EntityModel.Person();

            if (data == null) return companyEntity;

            if (data.PersonId != null) companyEntity.PersonId = data.PersonId.GetValueOrDefault();
            if (data.Name != null) companyEntity.Name = data.Name;
            if (data.Description != null) companyEntity.Description = data.Description;
            if (data.Email != null) companyEntity.Email = data.Email;
            if (data.WebSite != null) companyEntity.WebSite = data.WebSite;

            return companyEntity;
        }
        private List<PersonDto> TransformData(List<EntityModel.Person> data)
        {
            return data.Select(r => new PersonDto
            {
                PersonId = r.PersonId,
                Name = r.Name,
                Description = r.Description,
                Email = r.Email,
                WebSite = r.WebSite,
            }).ToList();
        }

        public async Task<List<PersonDto>> Get(PersonDto filtersPerson)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersPerson));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(PersonDto newPerson)
        {
            if (newPerson == null) return -1;
            var entity = ApplyData(newPerson, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.PersonId;
        }

        public async Task<int> Update(int updPersonId, PersonDto updPerson)
        {
            var companyEntitys = await FindAsync(r => r.PersonId == updPersonId);
            var companyEntity = companyEntitys.FirstOrDefault();

            if (companyEntity == null) return -1;
            companyEntity = ApplyData(updPerson, companyEntity);
            Modified(companyEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delPersonId)
        {
            var companyEntitys = await FindAsync(r => r.PersonId == delPersonId);
            var companyEntity = companyEntitys.FirstOrDefault();

            if (companyEntity == null) return -1;
            Remove(companyEntity);
            return await SaveChangesAsync();
        }
    }
}
