﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Book;
using VLS_Models.ModelsDto.Book;
using VLS_DataAccessEntityFramework.Abstract;



namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class BookRatingRepo : BaseRepository<EntityModel.BookRating>, IBookRating
    {
        private IQueryable<EntityModel.BookRating> ApplyFilters(BookRatingDto filtersBookRating)
        {
            var entity = Set<EntityModel.BookRating>();
            if (filtersBookRating == null) return entity;

            if (filtersBookRating.BookRatingId != null) entity = AddWhere(entity, r => r.BookRatingId == filtersBookRating.BookRatingId);
            if (filtersBookRating.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersBookRating.BookId);
            if (filtersBookRating.UserId != null) entity = AddWhere(entity, r => r.UserId == filtersBookRating.UserId);
            if (filtersBookRating.Rating != null) entity = AddWhere(entity, r => r.Rating == filtersBookRating.Rating);
            if (filtersBookRating.InsDate != null) entity = AddWhere(entity, r => r.InsDate == filtersBookRating.InsDate);
            
            return entity;
        }

        private EntityModel.BookRating ApplyData(BookRatingDto data, EntityModel.BookRating BookRatingEntity)
        {
            if (BookRatingEntity == null)
                BookRatingEntity = new EntityModel.BookRating();

            if (data == null) return BookRatingEntity;

            if (data.BookRatingId != null) BookRatingEntity.BookRatingId = data.BookRatingId.GetValueOrDefault();
            if (data.BookId != null) BookRatingEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.UserId != null) BookRatingEntity.UserId = data.UserId.GetValueOrDefault();
            if (data.Rating != null) BookRatingEntity.Rating = data.Rating.GetValueOrDefault();
            BookRatingEntity.InsDate = data.InsDate != null ? data.InsDate.GetValueOrDefault() : DateTime.Now;

            return BookRatingEntity;
        }
        private List<BookRatingDto> TransformData(List<EntityModel.BookRating> data)
        {
            return data.Select(r => new BookRatingDto
            {
                BookRatingId = r.BookRatingId,
                BookId = r.BookId,
                UserId = r.UserId,
                Rating = r.Rating,
                InsDate = r.InsDate,
            }).ToList();
        }

        public async Task<List<BookRatingDto>> Get(BookRatingDto filtersBookRating)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersBookRating));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(BookRatingDto newBookRating)
        {
            if (newBookRating == null) return -1;
            var entity = ApplyData(newBookRating, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.BookRatingId;
        }

        public async Task<int> Update(int updBookRatingId, BookRatingDto updBookRating)
        {
            var bookRatingEntitys = await FindAsync(r => r.BookRatingId == updBookRatingId);
            var bookRatingEntity = bookRatingEntitys.FirstOrDefault();

            if (bookRatingEntity == null) return -1;
            bookRatingEntity = ApplyData(updBookRating, bookRatingEntity);
            Modified(bookRatingEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delBookRatingId)
        {
            var bookRatingEntitys = await FindAsync(r => r.BookRatingId == delBookRatingId);
            var bookRatingEntity = bookRatingEntitys.FirstOrDefault();

            if (bookRatingEntity == null) return -1;
            Remove(bookRatingEntity);
            return await SaveChangesAsync();
        }
    }
}
