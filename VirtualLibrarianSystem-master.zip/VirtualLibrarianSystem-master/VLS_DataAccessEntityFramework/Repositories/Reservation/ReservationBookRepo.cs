﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Reservation;
using VLS_Models.ModelsDto.Reservation;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class ReservationBookRepo : BaseRepository<EntityModel.ReservationBook>, IReservationBook
    {
        private IQueryable<EntityModel.ReservationBook> ApplyFilters(ReservationBookDto filtersReservationBook)
        {
            var entity = Set<EntityModel.ReservationBook>();
            if (filtersReservationBook == null) return entity;

            if (filtersReservationBook.ReservationBookId != null) entity = AddWhere(entity, r => r.ReservationBookId == filtersReservationBook.ReservationBookId);
            if (filtersReservationBook.ReservationId != null) entity = AddWhere(entity, r => r.ReservationId == filtersReservationBook.ReservationId);
            if (filtersReservationBook.LibraryId != null) entity = AddWhere(entity, r => r.LibraryId == filtersReservationBook.LibraryId);
            if (filtersReservationBook.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersReservationBook.BookId);
            if (filtersReservationBook.ReservationBookStatus != null) entity = AddWhere(entity, r => r.ReservationBookStatus == filtersReservationBook.ReservationBookStatus);
            if (filtersReservationBook.Extend != null) entity = AddWhere(entity, r => r.Extend == filtersReservationBook.Extend);
            if (filtersReservationBook.ExtendReservationBookId != null) entity = AddWhere(entity, r => r.ExtendReservationBookId == filtersReservationBook.ExtendReservationBookId);
            if (filtersReservationBook.StartDate != null) entity = AddWhere(entity, r => r.StartDate == filtersReservationBook.StartDate);
            if (filtersReservationBook.EndDate != null) entity = AddWhere(entity, r => r.EndDate == filtersReservationBook.EndDate);

            return entity;
        }

        private EntityModel.ReservationBook ApplyData(ReservationBookDto data, EntityModel.ReservationBook reservationBookEntity)
        {
            if (reservationBookEntity == null)
                reservationBookEntity = new EntityModel.ReservationBook();

            if (data == null) return reservationBookEntity;

            if (data.ReservationBookId != null) reservationBookEntity.ReservationBookId = data.ReservationBookId.GetValueOrDefault();
            if (data.ReservationId != null) reservationBookEntity.ReservationId = data.ReservationId.GetValueOrDefault();
            if (data.LibraryId != null) reservationBookEntity.LibraryId = data.LibraryId.GetValueOrDefault();
            if (data.BookId != null) reservationBookEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.ReservationBookStatus != null) reservationBookEntity.ReservationBookStatus = data.ReservationBookStatus.GetValueOrDefault();
            if (data.Extend != null) reservationBookEntity.Extend = data.Extend.GetValueOrDefault();
            if (data.ExtendReservationBookId != null) reservationBookEntity.ExtendReservationBookId = data.ExtendReservationBookId.GetValueOrDefault();
            reservationBookEntity.StartDate = data.StartDate != null ? data.StartDate.GetValueOrDefault() : DateTime.Now;
            reservationBookEntity.EndDate = data.EndDate != null ? data.EndDate.GetValueOrDefault() : DateTime.Now;
            return reservationBookEntity;
        }
        private List<ReservationBookDto> TransformData(List<EntityModel.ReservationBook> data)
        {
            return data.Select(r => new ReservationBookDto
            {
                ReservationBookId = r.ReservationBookId,
                ReservationId =r.ReservationId,
                LibraryId=r.LibraryId,
                BookId=r.BookId,
                ReservationBookStatus= r.ReservationBookStatus,
                Extend=r.Extend,
                ExtendReservationBookId=r.ExtendReservationBookId,
                StartDate = r.StartDate,
                EndDate = r.EndDate,
            }).ToList();
        }

        public async Task<List<ReservationBookDto>> Get(ReservationBookDto filtersReservationBook)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersReservationBook));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(ReservationBookDto newReservationBook)
        {
            if (newReservationBook == null) return -1;
            var entity = ApplyData(newReservationBook, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.ReservationBookId;
        }
  
        public async Task<int> Update(int updReservationBookId, ReservationBookDto updReservationBook)
        {
            var reservationBookEntitys = await FindAsync(r => r.ReservationBookId == updReservationBookId);
            var reservationBookEntity = reservationBookEntitys.FirstOrDefault();

            if (reservationBookEntity == null) return -1;
            reservationBookEntity = ApplyData(updReservationBook, reservationBookEntity);
            Modified(reservationBookEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delReservationBookId)
        {
            var reservationBookEntitys = await FindAsync(r => r.ReservationBookId == delReservationBookId);
            var reservationBookEntity = reservationBookEntitys.FirstOrDefault();

            if (reservationBookEntity == null) return -1;
            Remove(reservationBookEntity);
            return await SaveChangesAsync();
        }

      
    }
}
