﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Reservation;
using VLS_Models.ModelsDto.Reservation;
using VLS_DataAccessEntityFramework.Abstract;
using VLS_DataAccessEntityFramework.EntityModel;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class ReservationRepo : BaseRepository<Reservation>, IReservation
    {
        private IQueryable<Reservation> ApplyFilters(ReservationDto filtersReservation)
        {
            var entity = Set<Reservation>();
            if (filtersReservation == null) return entity;

            if (filtersReservation.ReservationId != null) entity = AddWhere(entity, r => r.ReservationId == filtersReservation.ReservationId);
            if (filtersReservation.UserId != null) entity = AddWhere(entity, r => r.UserId == filtersReservation.UserId);
            
            return entity;
        }

        private Reservation ApplyData(ReservationDto data, Reservation reservationEntity)
        {
            if (reservationEntity == null)
                reservationEntity = new Reservation();

            if (data == null) return reservationEntity;

            if (data.ReservationId != null) reservationEntity.ReservationId = data.ReservationId.GetValueOrDefault();
            if (data.UserId != null) reservationEntity.UserId = data.UserId.GetValueOrDefault();
            reservationEntity.InsDate = data.InsDate != null ? data.InsDate.GetValueOrDefault() : DateTime.Now;
            if (data.ReservationBooks != null)
            {
                reservationEntity.ReservationBooks = data.ReservationBooks.Select(b => new ReservationBook
                {
                    ReservationBookId = b.ReservationBookId.GetValueOrDefault(),
                    ReservationId = b.ReservationId.GetValueOrDefault(),
                    LibraryId = b.LibraryId.GetValueOrDefault(),
                    BookId = b.BookId.GetValueOrDefault(),
                    StartDate = b.StartDate.GetValueOrDefault(),
                    EndDate = b.EndDate.GetValueOrDefault(),
                    ReservationBookStatus = b.ReservationBookStatus.GetValueOrDefault(),
                    Extend = b.Extend.GetValueOrDefault(),
                    ExtendReservationBookId = b.ExtendReservationBookId,
                }).ToList();
            }
            return reservationEntity;
        }
        private List<ReservationDto> TransformData(List<Reservation> data)
        {
            return data.Select(r => new ReservationDto
            {
                ReservationId = r.ReservationId,
                UserId = r.UserId,
                InsDate = r.InsDate,
                ReservationBooks =  r.ReservationBooks.Select(b=>new ReservationBookDto
                                                            {
                                                                ReservationBookId = b.ReservationBookId,
                                                                ReservationId=b.ReservationId,
                                                                LibraryId=b.LibraryId,
                                                                LibraryName = b.Library.Name,
                                                                BookId=b.BookId,
                                                                BookTitle=b.Book.Title,
                                                                StartDate=b.StartDate,
                                                                EndDate=b.EndDate,
                                                                ReservationBookStatus = b.ReservationBookStatus,
                                                                Extend = b.Extend,
                                                                ExtendReservationBookId = b.ExtendReservationBookId
                                                            }).ToList()
            }).ToList();
        }

        public async Task<List<ReservationDto>> Get(ReservationDto filtersReservation)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersReservation));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(ReservationDto newReservation)
        {
            if (newReservation == null) return -1;
            var entity = ApplyData(newReservation, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.ReservationId;
        }
        public async Task UpdateReservationBookStatus_Reservation(int reservationId)
        {
            await Task.Run(() => Dbcontext.UpdReservationBookStatus_Reservation(reservationId));
        }

        public async Task UpdateReservationBookStatus_Return(int reservationId)
        {
            await Task.Run(() => Dbcontext.UpdReservationBookStatus_Return(reservationId));
        }

        public async Task<int> Update(int updReservationId, ReservationDto updReservation)
        {
            var reservationEntitys = await FindAsync(r => r.ReservationId == updReservationId);
            var reservationEntity = reservationEntitys.FirstOrDefault();

            if (reservationEntity == null) return -1;
            reservationEntity = ApplyData(updReservation, reservationEntity);
            Modified(reservationEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delReservationId)
        {
            var reservationEntitys = await FindAsync(r => r.ReservationId == delReservationId);
            var reservationEntity = reservationEntitys.FirstOrDefault();

            if (reservationEntity == null) return -1;
            Remove(reservationEntity);
            return await SaveChangesAsync();
        }

      
    }
}
