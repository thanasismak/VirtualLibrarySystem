﻿using GeoCoordinatePortable;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Library;
using VLS_Models.ModelsDto.Library;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
    public sealed class LibraryRepo : BaseRepository<EntityModel.Library>, ILibrary
    {
        private IQueryable<EntityModel.Library> ApplyFilters(LibraryDto filtersLibrary)
        {
            var entity = Set<EntityModel.Library>();
            if (filtersLibrary == null) return entity;

            if (filtersLibrary.LibraryId != null) entity = AddWhere(entity, r => r.LibraryId == filtersLibrary.LibraryId);
            if (filtersLibrary.Name != null) entity = AddWhere(entity, r => r.Name == filtersLibrary.Name);
            if (filtersLibrary.Description != null) entity = AddWhere(entity, r => r.Description == filtersLibrary.Description);
            if (filtersLibrary.Address != null) entity = AddWhere(entity, r => r.Address == filtersLibrary.Address);
            if (filtersLibrary.Email != null) entity = AddWhere(entity, r => r.Email == filtersLibrary.Email);
            if (filtersLibrary.WebSite != null) entity = AddWhere(entity, r => r.WebSite == filtersLibrary.WebSite);
            if (filtersLibrary.Phone1 != null) entity = AddWhere(entity, r => r.Phone1 == filtersLibrary.Phone1);
            if (filtersLibrary.Phone2 != null) entity = AddWhere(entity, r => r.Phone2 == filtersLibrary.Phone2);
            if (filtersLibrary.Phone3 != null) entity = AddWhere(entity, r => r.Phone3 == filtersLibrary.Phone3);
            if (filtersLibrary.Fax != null) entity = AddWhere(entity, r => r.Fax == filtersLibrary.Fax);

            return entity;
        }

        private EntityModel.Library ApplyData(LibraryDto data, EntityModel.Library lLibraryEntity)
        {
            if (lLibraryEntity == null)
                lLibraryEntity = new EntityModel.Library();

            if (data == null) return lLibraryEntity;

            if (data.LibraryId != null) lLibraryEntity.LibraryId = data.LibraryId.GetValueOrDefault();
            if (data.Name != null) lLibraryEntity.Name = data.Name;
            if (data.Description != null) lLibraryEntity.Name = data.Description;
            if (data.Address != null) lLibraryEntity.Address = data.Address;
            if (data.Email != null) lLibraryEntity.Email = data.Email;
            if (data.WebSite != null) lLibraryEntity.WebSite = data.WebSite;
            if (data.Phone1 != null) lLibraryEntity.Phone1 = data.Phone1;
            if (data.Phone2 != null) lLibraryEntity.Phone2 = data.Phone2;
            if (data.Phone3 != null) lLibraryEntity.Phone3 = data.Phone3;
            if (data.Fax != null) lLibraryEntity.Fax = data.Fax;
            if (data.Longitude != null) lLibraryEntity.Longitude = data.Longitude;
            if (data.Latitude != null) lLibraryEntity.Latitude = data.Latitude;

            return lLibraryEntity;
        }
        private List<LibraryDto> TransformData(List<EntityModel.Library> data)
        {
            return data.Select(r => new LibraryDto
            {
                LibraryId = r.LibraryId,
                Name = r.Name,
                Description = r.Description,
                Address = r.Address,
                Email = r.Email,
                WebSite=r.WebSite,
                Phone1=r.Phone1,
                Phone2= r.Phone2,
                Phone3=r.Phone3,
                Fax=r.Fax,
                Longitude=r.Longitude,
                Latitude=r.Latitude,
            }).ToList();
        }
        public async Task<List<LibraryDto>> GetByDistance(float latitude, float longitude)
        {
            var coord = new GeoCoordinate(latitude, longitude);

            var searchresult = await FindAsync(ApplyFilters(null));

            var data = (from r in searchresult.AsEnumerable()
                let geo = new GeoCoordinate {Latitude = r.Latitude.GetValueOrDefault(), Longitude = r.Longitude.GetValueOrDefault()}
                select new LibraryDto()
                {
                    LibraryId = r.LibraryId,
                    Name = r.Name,
                    Description = r.Description,
                    Address = r.Address,
                    Email = r.Email,
                    WebSite = r.WebSite,
                    Phone1 = r.Phone1,
                    Phone2 = r.Phone2,
                    Phone3 = r.Phone3,
                    Fax = r.Fax,
                    Longitude = r.Longitude,
                    Latitude = r.Latitude,
                    Distance = geo.GetDistanceTo(coord)
                }).ToList();

            return data.OrderByDescending(o => o.Distance).ToList();
        }

        public async Task<List<LibraryDto>> Get(LibraryDto filtersLibrary)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersLibrary));
            return TransformData(searchresult);
        }

        public async Task<int> Insert(LibraryDto newLibrary)
        {
            if (newLibrary == null) return -1;
            var entity = ApplyData(newLibrary, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.LibraryId;
        }

        public async Task<int> Update(int updLibraryId, LibraryDto updLibrary)
        {
            var lLibraryEntitys = await FindAsync(r => r.LibraryId == updLibraryId);
            var lLibraryEntity = lLibraryEntitys.FirstOrDefault();

            if (lLibraryEntity == null) return -1;
            lLibraryEntity = ApplyData(updLibrary, lLibraryEntity);
            Modified(lLibraryEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delLibraryId)
        {
            var lLibraryEntitys = await FindAsync(r => r.LibraryId == delLibraryId);
            var lLibraryEntity = lLibraryEntitys.FirstOrDefault();

            if (lLibraryEntity == null) return -1;
            Remove(lLibraryEntity);
            return await SaveChangesAsync();
        }
    }
}
