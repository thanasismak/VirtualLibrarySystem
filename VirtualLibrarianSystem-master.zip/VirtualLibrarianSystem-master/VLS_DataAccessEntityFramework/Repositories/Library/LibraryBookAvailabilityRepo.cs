﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VLS_BusinessLayer.Interfaces.Repositories.Library;
using VLS_Models.ModelsDto.Library;
using VLS_DataAccessEntityFramework.Abstract;

namespace VLS_DataAccessEntityFramework.Repositories
{
   public sealed class LibraryBookAvailabilityRepo : BaseRepository<EntityModel.LibraryBookAvailability>, ILibraryBookAvailability
    {
        private IQueryable<EntityModel.LibraryBookAvailability> ApplyFilters(LibraryBookAvailabilityDto filtersLibraryBookAvailability)
        {
            var entity = Set<EntityModel.LibraryBookAvailability>();
            if (filtersLibraryBookAvailability == null) return entity;

            if (filtersLibraryBookAvailability.LibraryBookAvailabilityId != null) entity = AddWhere(entity, r => r.LibraryBookAvailabilityId == filtersLibraryBookAvailability.LibraryBookAvailabilityId);
            if (filtersLibraryBookAvailability.LibraryId != null) entity = AddWhere(entity, r => r.LibraryId == filtersLibraryBookAvailability.LibraryId);
            if (filtersLibraryBookAvailability.BookId != null) entity = AddWhere(entity, r => r.BookId == filtersLibraryBookAvailability.BookId);
            if (filtersLibraryBookAvailability.Quantity != null) entity = AddWhere(entity, r => r.Quantity == filtersLibraryBookAvailability.Quantity);

            return entity;
        }

        private EntityModel.LibraryBookAvailability ApplyData(LibraryBookAvailabilityDto data,EntityModel.LibraryBookAvailability bookCompanyEntity)
        { 
            if (bookCompanyEntity==null)
                bookCompanyEntity = new EntityModel.LibraryBookAvailability();

            if (data == null) return bookCompanyEntity;

            if (data.LibraryBookAvailabilityId != null) bookCompanyEntity.LibraryBookAvailabilityId = data.LibraryBookAvailabilityId.GetValueOrDefault();
            if (data.LibraryId != null) bookCompanyEntity.LibraryId = data.LibraryId.GetValueOrDefault();
            if (data.BookId != null) bookCompanyEntity.BookId = data.BookId.GetValueOrDefault();
            if (data.Quantity != null) bookCompanyEntity.Quantity = data.Quantity.GetValueOrDefault();

            return bookCompanyEntity;
       }
        private List<LibraryBookAvailabilityDto> TransformData(List<EntityModel.LibraryBookAvailability> data)
        {
            return data.Select(r => new LibraryBookAvailabilityDto
            {
                LibraryBookAvailabilityId = r.LibraryBookAvailabilityId,
                BookId = r.BookId,
                Quantity = r.Quantity,
                LibraryId = r.LibraryId,
            }).ToList();
        }

        public async Task<List<LibraryBookAvailabilityDto>> Get(LibraryBookAvailabilityDto filtersLibraryBookAvailability)
        {
            var searchresult = await FindAsync(ApplyFilters(filtersLibraryBookAvailability));
            return TransformData(searchresult);
        }

       public async Task<int> Insert(LibraryBookAvailabilityDto newLibraryBookAvailability)
        {
           if (newLibraryBookAvailability == null) return -1;
            var entity = ApplyData(newLibraryBookAvailability, null);
            Add(entity);
            await SaveChangesAsync();
            return entity.LibraryBookAvailabilityId;
        }

        public async Task<int> Update(int updLibraryBookAvailabilityId,LibraryBookAvailabilityDto updLibraryBookAvailability)
        {
            var bookCompanyEntitys = await FindAsync(r => r.LibraryBookAvailabilityId == updLibraryBookAvailabilityId);
            var bookCompanyEntity = bookCompanyEntitys.FirstOrDefault();

            if (bookCompanyEntity == null) return -1;
            bookCompanyEntity = ApplyData(updLibraryBookAvailability, bookCompanyEntity);
            Modified(bookCompanyEntity);
            return await SaveChangesAsync();
        }

        public async Task<int> Delete(int delLibraryBookAvailabilityId)
        {
            var bookCompanyEntitys = await FindAsync(r => r.LibraryBookAvailabilityId == delLibraryBookAvailabilityId);
            var bookCompanyEntity = bookCompanyEntitys.FirstOrDefault();

            if (bookCompanyEntity == null) return -1;
            Remove(bookCompanyEntity);
            return await SaveChangesAsync();
        }
    }
}
