﻿using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web.Http.Controllers;
using System.Web.Http.Description;
using System.Xml.XPath;

namespace VLS_WebApi.Providers
{

    /// <summary>
    /// 
    /// </summary>
    public class XmlCommentDocumentationProvider : IDocumentationProvider
    {
        private readonly XPathNavigator _documentNavigator;
        private const string MethodExpression = "/doc/members/member[@name='M:{0}']";

        private static readonly Regex NullableTypeNameRegex =
            new Regex(@"(.*\.Nullable)" + Regex.Escape("`1[[") + "([^,]*),.*");

        /// <summary>
        /// 
        /// </summary>
        /// <param name="documentPath"></param>
        public XmlCommentDocumentationProvider(string documentPath)
        {
            XPathDocument xpath = new XPathDocument(documentPath);
            _documentNavigator = xpath.CreateNavigator();
        }

        public string GetDocumentation(HttpParameterDescriptor parameterDescriptor)
        {
            ReflectedHttpParameterDescriptor reflectedParameterDescriptor =
                parameterDescriptor as ReflectedHttpParameterDescriptor;
            if (reflectedParameterDescriptor != null)
            {
                XPathNavigator memberNode = GetMemberNode(reflectedParameterDescriptor.ActionDescriptor);
                if (memberNode != null)
                {
                    string parameterName = reflectedParameterDescriptor.ParameterInfo.Name;
                    XPathNavigator parameterNode =memberNode.SelectSingleNode($"param[@name='{parameterName}']");
                    if (parameterNode != null)
                    {
                        return parameterNode.Value.Trim();
                    }
                }
            }

            return "No Documentation Found.";
        }

        public string GetDocumentation(HttpActionDescriptor actionDescriptor)
        {
            XPathNavigator memberNode = GetMemberNode(actionDescriptor);
            XPathNavigator summaryNode = memberNode?.SelectSingleNode("summary");
            if (summaryNode != null)
            {
                return summaryNode.Value.Trim();
            }

            return "No Documentation Found.";
        }

        private XPathNavigator GetMemberNode(HttpActionDescriptor actionDescriptor)
        {
            ReflectedHttpActionDescriptor reflectedActionDescriptor = actionDescriptor as ReflectedHttpActionDescriptor;
            if (reflectedActionDescriptor != null)
            {
                string selectExpression = string.Format(MethodExpression,
                    GetMemberName(reflectedActionDescriptor.MethodInfo));
                XPathNavigator node = _documentNavigator.SelectSingleNode(selectExpression);
                if (node != null)
                {
                    return node;
                }
            }

            return null;
        }

        private static string GetMemberName(MethodInfo method)
        {
            if (method.DeclaringType != null)
            {
                string name = $"{method.DeclaringType.FullName}.{method.Name}";
                var parameters = method.GetParameters();
                if (parameters.Length != 0)
                {
                    string[] parameterTypeNames =
                        parameters.Select(param => ProcessTypeName(param.ParameterType.FullName)).ToArray();
                    name += $"({string.Join(",", parameterTypeNames)})";
                }

                return name;
            }
            return string.Empty;
        }

        private static string ProcessTypeName(string typeName)
        {
            //handle nullable
            var result = NullableTypeNameRegex.Match(typeName);
            if (result.Success)
            {
                return $"{result.Groups[1].Value}{{{result.Groups[2].Value}}}";
            }
            return typeName;
        }

        public string GetDocumentation(HttpControllerDescriptor controllerDescriptor)
        {

            return "No Documentation Found.";
        }

        public string GetResponseDocumentation(HttpActionDescriptor actionDescriptor)
        {
            return "No Documentation Found.";
        }
    }
}