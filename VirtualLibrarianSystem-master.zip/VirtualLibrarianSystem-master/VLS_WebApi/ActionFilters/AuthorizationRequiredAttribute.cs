﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Interfaces.Services;
using VLS_BusinessLayer.Interfaces.Services.Account;
using VLS_Models.ModelsDto.Account;
using VLS_WebApi.Filters;
using VLS_WebApi.Misc;

namespace VLS_WebApi.ActionFilters
{
    /// <summary>
    /// 
    /// </summary>
    public class AuthorizationRequiredAttribute : ActionFilterAttribute
    {
        private const string Token = "Token";
        /// <summary>
        /// 
        /// </summary>
        public EnumBusinessEntity BusinessEntity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public EnumBusinessEntityAction BusinessEntityAction { get; set; }

        public override void OnActionExecuting(HttpActionContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            try
            {
                var tokenservice = filterContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(ITokenService)) as ITokenService;
                var userservice = filterContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(IUserService)) as IUserService;


                if (filterContext.Request.Headers.Contains(Token))
                {
                    var tokenValue = filterContext.Request.Headers.GetValues(Token).First();
                    
                    if (tokenservice!=null)
                    {
                        if (!Task.Run(() => tokenservice.ValidateToken(tokenValue)).Result)
                        {
                            var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                            {
                                ReasonPhrase = tokenValue + " , Token does not exists or has been expired"
                            };
                            filterContext.Response = responseMessage;
                        }
                        else
                        {
                            var token = Task.Run(() => tokenservice.Get(new TokenDto() {AuthToken = tokenValue})).Result.FirstOrDefault();
                            if (token != null)
                            {
                                if (BusinessEntityAction != EnumBusinessEntityAction.None &&
                                    (userservice != null && !Task.Run(() =>userservice.CheckAuthorization(token.UserId.GetValueOrDefault(),BusinessEntity.ToString(), BusinessEntityAction.ToString())).Result))
                                {
                                    var responseMessage = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                                    {
                                        ReasonPhrase =
                                            tokenValue + ", User does not have authorization for " +
                                            BusinessEntityAction.ToString() + " at " + BusinessEntity.ToString()
                                    };
                                    filterContext.Response = responseMessage;
                                }
                                SetIdentity(token.UserId.GetValueOrDefault(),token.UserName);
                            }
                            else
                            {
                                filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                            }
                        }
                    }
                }
                else
                {
                    filterContext.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                }
                base.OnActionExecuting(filterContext);
            }
            catch (Exception ex)
            {
                var logger = filterContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(ILoggerService)) as ILoggerService;
                logger?.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }
        }

        private void SetIdentity(int userId,string userName)
        {
            var identity =  new BasicAuthenticationIdentity(userId, userName, "");
            var principal = new GenericPrincipal(identity, null);
            Thread.CurrentPrincipal = principal;
            if (HttpContext.Current != null)
            {
               HttpContext.Current.User = principal;
             }
        }
    }
}