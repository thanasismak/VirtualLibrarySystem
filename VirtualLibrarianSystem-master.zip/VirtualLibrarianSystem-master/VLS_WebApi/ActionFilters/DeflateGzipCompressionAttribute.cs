﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web.Http.Filters;

namespace VLS_WebApi.ActionFilters
{
    /// <summary>
    /// 
    /// </summary>
    public class DeflateGzipCompressionAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(HttpActionExecutedContext actContext)
        {
            try
            {
                var content = actContext.Response.Content;
                string contentencoding = System.Web.HttpContext.Current.Request.Headers["Accept-Encoding"];           

                if (!string.IsNullOrEmpty(contentencoding)) { 
                    if (contentencoding.ToLower(CultureInfo.CurrentCulture).Contains("gzip"))
                    {
                        contentencoding = "gzip";
             
                    }
                    else if (contentencoding.ToLower(CultureInfo.CurrentCulture).Contains("deflate"))
                    {
                        contentencoding = "deflate";
                    }
                }

                if (!string.IsNullOrEmpty(contentencoding))
                    {
                        IEnumerable<string> headerValues = System.Web.HttpContext.Current.Request.Headers.GetValues("Accept");
                        var bytes = content?.ReadAsByteArrayAsync().Result;
                        var zlibbedContent = bytes == null ? new byte[0] :
                        CompressionHelper.DeflateByte(bytes);
                        actContext.Response.Content = new ByteArrayContent(zlibbedContent);
                        actContext.Response.Content.Headers.Remove("Content-Type");
                        actContext.Response.Content.Headers.Add("Content-Encoding", contentencoding);
                        if(headerValues != null && headerValues.Any())
                          {
                              {
                                  string contentHeaderType = headerValues.FirstOrDefault();
                                  if(contentHeaderType != null && !contentHeaderType.ToLower(CultureInfo.CurrentCulture).Contains("json") && !contentHeaderType.ToLower(CultureInfo.CurrentCulture).Contains("xml"))
                                  {
                                      contentHeaderType = "application/json";
                                  }
                                  if (contentHeaderType != null)
                                      actContext.Response.Content.Headers.Add("Content-Type", contentHeaderType.Split(",".ToCharArray())[0]);
                              }
                          }
                    }
            }
            catch (Exception)
            {
                // ignored
            }

            base.OnActionExecuted(actContext);
          }

        }

        /// <summary>
        /// 
        /// </summary>
        public static class CompressionHelper
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="str"></param>
            /// <returns></returns>
            public static byte[] DeflateByte(byte[] str)
            {
                if (str == null)
                {
                    return null;
                }

                using (var output = new MemoryStream())
                {

                using (var compressor = new Ionic.Zlib.GZipStream(output, Ionic.Zlib.CompressionMode.Compress,Ionic.Zlib.CompressionLevel.BestSpeed))
                {
                    compressor.Write(str, 0, str.Length);
                }

                return output.ToArray();
                }
            }
        }
 
}