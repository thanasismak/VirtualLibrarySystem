using System.Web.Routing;
using AttributeRouting.Web.Mvc;

[assembly: WebActivator.PreApplicationStartMethod(typeof(VLS_WebApi.AttributeRoutingConfig), "Start")]

namespace VLS_WebApi 
{
    /// <summary>
    /// 
    /// </summary>
    public static class AttributeRoutingConfig
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="routes"></param>
		public static void RegisterRoutes(RouteCollection routes) 
		{    
			routes.MapAttributeRoutes();
		}

        /// <summary>
        /// 
        /// </summary>
        public static void Start() 
		{
            RegisterRoutes(RouteTable.Routes);
        }
    }
}
