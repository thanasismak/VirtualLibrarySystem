using VLS_BusinessLayer.Interfaces.Services;
using VLS_BusinessLayer.Interfaces.Services.Account;
using VLS_BusinessLayer.Interfaces.Services.Book;
using VLS_BusinessLayer.Interfaces.Services.Library;
using VLS_BusinessLayer.Interfaces.Services.Reservation;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Account;
using VLS_BusinessLayer.Services.Book;
using VLS_BusinessLayer.Services.Library;
using VLS_BusinessLayer.Services.Reservation;

[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(VLS_WebApi.NinjectWebCommon), "Start")]
[assembly: WebActivatorEx.ApplicationShutdownMethodAttribute(typeof(VLS_WebApi.NinjectWebCommon), "Stop")]

namespace VLS_WebApi
{
    using System;
    using System.Web;

    using Microsoft.Web.Infrastructure.DynamicModuleHelper;

    using Ninject;
    using Ninject.Web.Common;

    /// <summary>
    /// 
    /// </summary>
    public static class NinjectWebCommon 
    {
        private static readonly Bootstrapper Bootstrapper = new Bootstrapper();

        /// <summary>
        /// Starts the application
        /// </summary>
        public static void Start() 
        {
            DynamicModuleUtility.RegisterModule(typeof(OnePerRequestHttpModule));
            DynamicModuleUtility.RegisterModule(typeof(NinjectHttpModule));
            Bootstrapper.Initialize(CreateKernel);
        }

        /// <summary>
        /// Stops the application.
        /// </summary>
        public static void Stop()
        {
            Bootstrapper.ShutDown();
        }
        
        /// <summary>
        /// Creates the kernel that will manage your application.
        /// </summary>
        /// <returns>The created kernel.</returns>
        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            try
            {
                kernel.Bind<Func<IKernel>>().ToMethod(ctx => () => new Bootstrapper().Kernel);
                kernel.Bind<IHttpModule>().To<HttpApplicationInitializationHttpModule>();

                RegisterServices(kernel);

                System.Web.Http.GlobalConfiguration.Configuration.DependencyResolver = new Ninject.WebApi.DependencyResolver.NinjectDependencyResolver(kernel);

                return kernel;
            }
            catch
            {
                kernel.Dispose();
                throw;
            }
        }

        /// <summary>
        /// Load your modules or register your services here!
        /// </summary>
        /// <param name="kernel">The kernel.</param>
        private static void RegisterServices(IKernel kernel)
        {
            kernel.Bind<Func<ILoggerService>>().ToMethod(ctx => () => new LoggerService());

            kernel.Bind<ITokenService>().To<TokenService>().InRequestScope();
            kernel.Bind<IRoleService>().To<RoleService>().InRequestScope();
            kernel.Bind<IRoleBusinessEntityService>().To<RoleBusinessEntityService>().InRequestScope();
            kernel.Bind<IUserService>().To<UserService>().InRequestScope();
            kernel.Bind<IParamService>().To<ParamService>().InRequestScope();

            kernel.Bind<IPersonKindService>().To<PersonKindService>().InRequestScope();
            kernel.Bind<IPersonService>().To<PersonService>().InRequestScope();
            kernel.Bind<ICompanyService>().To<CompanyService>().InRequestScope();
            kernel.Bind<ICategoryService>().To<CategoryService>().InRequestScope();

            kernel.Bind<IBookPersonService>().To<BookPersonService>().InRequestScope();
            kernel.Bind<IBookCompanyService>().To<BookCompanyService>().InRequestScope();
            kernel.Bind<IBookCategoryService>().To<BookCategoryService>().InRequestScope();
            kernel.Bind<IBookRatingService>().To<BookRatingService>().InRequestScope();
            kernel.Bind<IBookService>().To<BookService>().InRequestScope();
            kernel.Bind<IBookSearchService>().To<BookSearchService>().InRequestScope();

            kernel.Bind<ILibraryService>().To<LibraryService>().InRequestScope();
            kernel.Bind<ILibraryBookAvailabilityService>().To<LibraryBookAvailabilityService>().InRequestScope();

            kernel.Bind<IReservationService>().To<ReservationService>().InRequestScope();
        }
    }
}
