﻿using System.Security.Principal;

namespace VLS_WebApi.Filters
{
    /// <summary>
    /// 
    /// </summary>
    public class BasicAuthenticationIdentity : GenericIdentity
    {
        /// <summary>
        /// 
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        public BasicAuthenticationIdentity(int userId, string userName, string password): base(userName, "Basic")
        {
            UserId = userId;
            UserName = userName;
            Password = password;
        }
    }
}