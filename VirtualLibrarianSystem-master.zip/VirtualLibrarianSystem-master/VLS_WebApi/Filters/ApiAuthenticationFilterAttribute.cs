﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Controllers;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Interfaces.Services;
using VLS_BusinessLayer.Interfaces.Services.Account;
using VLS_BusinessLayer.Services.Account;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Filters
{
    /// <summary>
    /// 
    /// </summary>
    public class ApiAuthenticationFilterAttribute : GenericAuthenticationFilterAttribute
    {
       
        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="actionContext"></param>
        /// <returns></returns>
        protected override bool OnAuthorizeUser(string username, string password, HttpActionContext actionContext)
        {
            try
            {
                var userId = -1;
                var userservice = actionContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(IUserService)) as UserService ;
                if (userservice != null)
                    userId = Task.Run(() => userservice.Authenticate(username, password)).Result;
                if (userId > 0)
                {
                    var basicAuthenticationIdentity = Thread.CurrentPrincipal.Identity as BasicAuthenticationIdentity;
                    if (basicAuthenticationIdentity != null)
                        basicAuthenticationIdentity.UserId = userId;
                    return true;
                }
            }
            catch (Exception ex)
            {
                var logger = actionContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(ILoggerService)) as ILoggerService;
                logger?.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }

            return false;
        }
    }
}