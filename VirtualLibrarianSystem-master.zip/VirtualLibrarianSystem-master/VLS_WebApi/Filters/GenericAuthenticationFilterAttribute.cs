﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Interfaces.Services;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Filters
{
    /// <summary>
    /// 
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class GenericAuthenticationFilterAttribute : AuthorizationFilterAttribute
    {
        public override void OnAuthorization(HttpActionContext filterContext)
        {
            try
            {
                var identity = FetchAuthHeader(filterContext);
                if (identity == null)
                {
                    ChallengeAuthRequest(filterContext);
                    return;
                }

                SetPrincipal(new GenericPrincipal(identity, null));

                if (!OnAuthorizeUser(identity.Name, identity.Password, filterContext))
                {
                    ChallengeAuthRequest(filterContext);
                    return;
                }
                base.OnAuthorization(filterContext);
            }
            catch (Exception ex)
            {
                var logger = filterContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(ILoggerService)) as ILoggerService;
                logger?.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }
        }

        private static void SetPrincipal(IPrincipal principal)
        {
            Thread.CurrentPrincipal = principal;
            if (HttpContext.Current != null)
            {
                HttpContext.Current.User = principal;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="pass"></param>
        /// <param name="filterContext"></param>
        /// <returns></returns>
        protected virtual bool OnAuthorizeUser(string user, string pass, HttpActionContext filterContext)
        {
            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
                return false;
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterContext"></param>
        /// <returns></returns>
        protected virtual BasicAuthenticationIdentity FetchAuthHeader(HttpActionContext filterContext)
        {
            try
            {
                string authHeaderValue = null;
                var authRequest = filterContext.Request.Headers.Authorization;
                if (!string.IsNullOrEmpty(authRequest?.Scheme) && authRequest.Scheme == "Basic")
                    authHeaderValue = authRequest.Parameter;

                if (string.IsNullOrEmpty(authHeaderValue))
                    return null;

                authHeaderValue = Encoding.Default.GetString(Convert.FromBase64String(authHeaderValue));
                var idx = authHeaderValue.IndexOf(':');
                if (idx < 1) return null;


                var username = authHeaderValue.Substring(0, idx);
                var password = authHeaderValue.Substring(idx + 1);
                return string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)
                    ? null
                    : new BasicAuthenticationIdentity(-1,username, password);

            }
            catch (Exception ex)
            {
                var logger = filterContext.ControllerContext.Configuration.DependencyResolver.GetService(typeof(ILoggerService)) as ILoggerService;
                logger?.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }
            return null;
        }

        private static void ChallengeAuthRequest(HttpActionContext filterContext)
        {
            var dnsHost = filterContext.Request.RequestUri.DnsSafeHost;
            filterContext.Response = filterContext.Request.CreateResponse(HttpStatusCode.Unauthorized);
            filterContext.Response.Headers.Add("WWW-Authenticate", $"Basic realm=\"{dnsHost}\"");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filterContext"></param>
    }
}