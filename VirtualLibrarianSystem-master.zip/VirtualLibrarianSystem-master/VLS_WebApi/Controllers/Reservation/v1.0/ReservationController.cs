﻿using System;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Reservation;
using VLS_Models.ModelsDto.Reservation;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Filters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Reservation.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class ReservationController : ApiController
    {
        private readonly ReservationService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public ReservationController(ReservationService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }


        /// <summary>
        /// 
        /// </summary>
        public int GetCurrentUserId
        {
            get
            {
                var principal = (GenericPrincipal)Thread.CurrentPrincipal;
                var identity = (BasicAuthenticationIdentity)principal?.Identity;
                if (identity?.UserId != null) return identity.UserId;
                return -1;
            }
        }


        //// POST: api/v1.0/UserReservation/Search
        /// <summary>
        /// Search User Reservations with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="reservation">
        /// 
        /// {"ReservationId": null,"UserId": null,"ReservationStatus": null,"Extend": null,"ExtendReservationId": null,"InsDate": null,
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null}
        ///                          ]
        ///   }
        /// 
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/UserReservation/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.UserReservation, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> UserReservationSearch(ReservationDto reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                if (reservation == null) reservation = new ReservationDto();
                reservation.UserId = GetCurrentUserId;
                var result = await _service.Get(reservation);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }



        /// POST: api/v1.0/UserNewReservation
        /// <summary>
        /// Add reservation 
        /// </summary>
        /// <param name="reservation">
        /// {
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null}
        ///                          ]
        ///   }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/UserNewReservation")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.UserReservation, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> UserNewReservation(ReservationDto reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                reservation.UserId = GetCurrentUserId;
                var newid = await _service.UserNewReservation(reservation);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }



        /// POST: api/v1.0/UserExtendReservation
        /// <summary>
        /// Add reservation 
        /// </summary>
        /// <param name="reservation">
        /// {
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null}
        ///                          ]
        ///   }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/UserExtendReservation")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.UserReservation, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> UserExtendReservation(ReservationDto reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                reservation.UserId = GetCurrentUserId;
                var newid = await _service.UserExtendReservation(reservation);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }









        //// POST: api/v1.0/Reservation/Search
        /// <summary>
        /// Search Reservations with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="reservation">
        /// 
        /// {"ReservationId": null,"UserId": null,"InsDate": null,
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null,"ReservationBookStatus": null,"Extend": null,"ExtendReservationBookId": null}
        ///                          ]
        ///   }
        /// 
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Reservation/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Reservation, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(ReservationDto reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(reservation);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/Reservation/{id}
        /// <summary>
        /// GET reservation by id 
        /// </summary>
        /// <param name="id">{ReservationId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Reservation/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Reservation, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Reservation
        /// <summary>
        /// Add reservation 
        /// </summary>
        /// <param name="reservation">
        /// {"ReservationId": null,"UserId": null,"InsDate": null,
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null,"ReservationBookStatus": null,"Extend": null,"ExtendReservationBookId": null}
        ///                          ]
        ///   }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Reservation")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Reservation, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(ReservationDto reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(reservation);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/Reservation/{id}
        /// <summary>
        /// Update reservation by id 
        /// </summary>
        /// <param name="id">{ReservationId}</param>
        /// <param name="reservation">
        /// {"ReservationId": null,"UserId": null,"InsDate": null,
        ///      "ReservationBooks": [
        ///                            {"ReservationBookId": null,"ReservationId": null,"LibraryId": null,"BookId": null,"StartDate": null,"EndDate": null,"ReservationBookStatus": null,"Extend": null,"ExtendReservationBookId": null}
        ///                          ]
        ///   }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Reservation/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Reservation, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, ReservationDto  reservation)
        {
            Validate(reservation);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                reservation.ReservationId = id;
                var res = await _service.Update(id, reservation);
                if (res == -1)
                    return NotFound();
                return Ok(reservation);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Reservation/{id}
        /// <summary>
        /// Delete reservation by id 
        /// </summary>
        /// <param name="id">{ReservationId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Reservation/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Reservation, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

