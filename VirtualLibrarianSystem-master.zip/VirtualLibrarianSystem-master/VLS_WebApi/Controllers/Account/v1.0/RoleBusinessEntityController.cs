﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Account;
using VLS_Models.ModelsDto.Account;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Controllers.Account.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class RoleBusinessEntityController : ApiController
    {
        private readonly RoleBusinessEntityService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public RoleBusinessEntityController(RoleBusinessEntityService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/RoleBusinessEntity/Search
        /// <summary>
        /// Search RoleBusinessEntitys with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="roleBusinessEntity">
        /// {"RoleBusinessEntityId": null,"RoleId": null,"BusinessEntityId": null,"PermitView": null,"PermitInsert": null,"PermitUpdate": null,"PermitDelete": null,"BusinessEntityName" : null, "RoleName" : null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/RoleBusinessEntity/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.RoleBusinessEntity, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(RoleBusinessEntityDto roleBusinessEntity)
        {
            Validate(roleBusinessEntity);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(roleBusinessEntity);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/RoleBusinessEntity/{id}
        /// <summary>
        /// GET RoleBusinessEntity by id 
        /// </summary>
        /// <param name="id">{RoleBusinessEntityId}</param>
        /// <returns></returns>
        [Route("api/v1.0/RoleBusinessEntity/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.RoleBusinessEntity, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/RoleBusinessEntity
        /// <summary>
        /// Add RoleBusinessEntity 
        /// </summary>
        /// <param name="roleBusinessEntity">
        /// {"RoleBusinessEntityId": null,"RoleId": null,"BusinessEntityId": null,"PermitView": null,"PermitInsert": null,"PermitUpdate": null,"PermitDelete": null,"BusinessEntityName" : null, "RoleName" : null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/RoleBusinessEntity")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.RoleBusinessEntity, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(RoleBusinessEntityDto roleBusinessEntity)
        {
            Validate(roleBusinessEntity);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(roleBusinessEntity);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT: api/v1.0/RoleBusinessEntity/{id}
        /// <summary>
        /// Update RoleBusinessEntity by id 
        /// </summary>
        /// <param name="id">{RoleBusinessEntityId}</param>
        /// <param name="roleBusinessEntity">
        /// {"RoleBusinessEntityId": null,"RoleId": null,"BusinessEntityId": null,"PermitView": null,"PermitInsert": null,"PermitUpdate": null,"PermitDelete": null,"BusinessEntityName" : null, "RoleName" : null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/RoleBusinessEntity/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.RoleBusinessEntity, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, RoleBusinessEntityDto roleBusinessEntity)
        {
            Validate(roleBusinessEntity);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                roleBusinessEntity.RoleBusinessEntityId = id;
                var res = await _service.Update(id, roleBusinessEntity);
                if (res == -1)
                    return NotFound();
                return Ok(roleBusinessEntity);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/RoleBusinessEntity/{id}
        /// <summary>
        /// Delete RoleBusinessEntity by id 
        /// </summary>
        /// <param name="id">{RoleBusinessEntityId}</param>
        /// <returns></returns>
        [Route("api/v1.0/RoleBusinessEntity/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.RoleBusinessEntity, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}