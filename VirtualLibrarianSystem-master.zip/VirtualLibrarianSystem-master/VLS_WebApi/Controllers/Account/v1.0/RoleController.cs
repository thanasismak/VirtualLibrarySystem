﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Account;
using VLS_Models.ModelsDto.Account;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Controllers.Account.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class RoleController : ApiController
    {
        private readonly RoleService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public RoleController(RoleService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/Role/Search
        /// <summary>
        /// Search Roles with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="role">
        /// {"RoleId": null, "Name": null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Role/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Role, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(RoleDto role)
        {
            Validate(role);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(role);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/Role/{id}
        /// <summary>
        /// GET Role by id 
        /// </summary>
        /// <param name="id">{RoleId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Role/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Role, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Role
        /// <summary>
        /// Add Role 
        /// </summary>
        /// <param name="role">
        /// {"RoleId": null, "Name": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Role")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Role, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(RoleDto role)
        {
            Validate(role);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(role);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT: api/v1.0/Role/{id}
        /// <summary>
        /// Update Role by id 
        /// </summary>
        /// <param name="id">{RoleId}</param>
        /// <param name="role">
        /// {"RoleId": null, "Name": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Role/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Role, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, RoleDto role)
        {
            Validate(role);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                role.RoleId = id;
                var res = await _service.Update(id, role);
                if (res == -1)
                    return NotFound();
                return Ok(role);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Role/{id}
        /// <summary>
        /// Delete Role by id 
        /// </summary>
        /// <param name="id">{RoleId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Role/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Role, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

