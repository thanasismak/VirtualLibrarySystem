﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Account;
using VLS_Models.ModelsDto.Account;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Controllers.Account.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class ParamController : ApiController
    {
        private readonly ParamService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public ParamController(ParamService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        //// POST: api/v1.0/Param/Search
        /// <summary>
        /// Search Params with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="param">
        /// {"ParamId": null, Code: null, Value : null, "Description": null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Param/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Param,BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(ParamDto param)
        {
            Validate(param);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(param);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error,
                    Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }


        /// GET: api/v1.0/Param/{id}
    /// <summary>
    /// GET Param by id 
    /// </summary>
    /// <param name="id">{ParamId}</param>
    /// <returns></returns>
    [Route("api/v1.0/Param/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Param, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/Param
        /// <summary>
        /// Add Param
        /// </summary>
        /// <param name="param">
        /// {"ParamId": null, Code: null, Value : null, "Description": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Param")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Param, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(ParamDto param)
        {
            Validate(param);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(param);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT: api/Param
        /// <summary>
        /// Update Param by id 
        /// </summary>
        /// <param name="id">{ParamId}</param>
        /// <param name="param">
        /// {"ParamId": null, Code: null, Value : null, "Description": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Param/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Param, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, ParamDto param)
        {
            Validate(param);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                param.ParamId = id;
                var res = await _service.Update(id, param);
                if (res == -1)
                    return NotFound();
                return Ok(param);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/Param/{id}
        /// <summary>
        /// Delete Param by id 
        /// </summary>
        /// <param name="id">{ParamId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Param/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Param, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

