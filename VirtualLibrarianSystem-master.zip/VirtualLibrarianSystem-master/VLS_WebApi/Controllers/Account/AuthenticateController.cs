﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Account;
using VLS_Models.ModelsDto.Account;
using VLS_WebApi.Filters;
using VLS_WebApi.Misc;

namespace VLS_WebApi.Controllers.Account
{
    /// <summary>
    /// 
    /// </summary>
    [ApiAuthenticationFilterAttribute]
    public sealed class AuthenticateController : ApiController
    {
        private readonly TokenService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public AuthenticateController (TokenService service,LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        ///POST /Token
        /// <summary>
        /// GET Token with Basic authentication.
        /// Add Header  "Authorization"    "Basic " + Base64(username + ":" + password));
        /// </summary>
        /// <returns></returns>
        [Route("Token")]
        public HttpResponseMessage Authenticate()
        {
            try
            {
                Thread.CurrentPrincipal = HttpContext.Current.User;

                if (Thread.CurrentPrincipal != null && Thread.CurrentPrincipal.Identity.IsAuthenticated)
                {
                    var basicAuthenticationIdentity = Thread.CurrentPrincipal.Identity as BasicAuthenticationIdentity;
                    if (basicAuthenticationIdentity != null)
                    {
                        var userId = basicAuthenticationIdentity.UserId;
                        return GetAuthToken(userId);
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }

            return null;
        }

        private HttpResponseMessage GetAuthToken(int userId)
        {
            TokenDto token = Task.Run(() => _service.GenerateToken(userId)).Result;

            if (token != null)
            {
                var response = Request.CreateResponse(HttpStatusCode.OK, "Authorized");
                response.Headers.Add("Token", token.AuthToken);
                response.Headers.Add("TokenExpiry", ConfigurationManager.AppSettings["AuthTokenExpiry"]);
                response.Headers.Add("Access-Control-Expose-Headers", "Token,TokenExpiry");
                return response;
            }
            else
            {
                var response = Request.CreateResponse(HttpStatusCode.Unauthorized, "Unauthorized");
                return response;
            }
        }
    }
}
