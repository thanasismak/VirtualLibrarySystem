﻿using System;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Filters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class BookController : ApiController
    {
        private readonly BookService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public BookController(BookService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        public int GetCurrentUserId
        {
            get
            {
                var principal = (GenericPrincipal)Thread.CurrentPrincipal;
                var identity = (BasicAuthenticationIdentity)principal?.Identity;
                if (identity?.UserId != null) return identity.UserId;
                return -1;
            }
        }


        //// POST: api/v1.0/Book/Search
        /// <summary>
        /// Search Books with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="book">
        /// { "BookId": null,  "Title": null,  "SubTitle": null,  "OriginTitle": null,  "Description": null,  "PublishYear": null,  "PublishMonth": null,  "Pages": null,  "Isbn": null,  "IsbnSet": null,  "Isbn13": null,  "IsbnSet13": null }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Book/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Book, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(BookDto book)
        {
            Validate(book);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(book);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/Book/{id}
        /// <summary>
        /// GET book by id 
        /// </summary>
        /// <param name="id">{BookId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Book/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Book, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Book
        /// <summary>
        /// Add book 
        /// </summary>
        /// <param name="book">
        /// { "BookId": null,  "Title": null,  "SubTitle": null,  "OriginTitle": null,  "Description": null,  "PublishYear": null,  "PublishMonth": null,  "Pages": null,  "Isbn": null,  "IsbnSet": null,  "Isbn13": null,  "IsbnSet13": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Book")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Book, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(BookDto book)
        {
            Validate(book);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(book);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/Book/{id}
        /// <summary>
        /// Update book by id 
        /// </summary>
        /// <param name="id">{BookId}</param>
        /// <param name="book">
        /// { "BookId": null,  "Title": null,  "SubTitle": null,  "OriginTitle": null,  "Description": null,  "PublishYear": null,  "PublishMonth": null,  "Pages": null,  "Isbn": null,  "IsbnSet": null,  "Isbn13": null,  "IsbnSet13": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Book/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Book, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, BookDto  book)
        {
            Validate(book);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                book.BookId = id;
                var res = await _service.Update(id, book);
                if (res == -1)
                    return NotFound();
                return Ok(book);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Book/{id}
        /// <summary>
        /// Delete book by id 
        /// </summary>
        /// <param name="id">{BookId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Book/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Book, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

