﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class CategoryController : ApiController
    {
        private readonly CategoryService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public CategoryController(CategoryService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/Category/Search
        /// <summary>
        /// Search Categorys with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="category">
        /// {  "CategoryId": null,  "Code": null,  "Description": null,  "ParentCategoryId": null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Category/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Category, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(CategoryDto category)
        {
            Validate(category);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(category);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/Category/{id}
        /// <summary>
        /// GET category by id 
        /// </summary>
        /// <param name="id">{CategoryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Category/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Category, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Category
        /// <summary>
        /// Add category 
        /// </summary>
        /// <param name="category">
        /// {  "CategoryId": null,  "Code": null,  "Description": null,  "ParentCategoryId": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Category")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Category, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(CategoryDto category)
        {
            Validate(category);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(category);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/Category/{id}
        /// <summary>
        /// Update category by id 
        /// </summary>
        /// <param name="id">{CategoryId}</param>
        /// <param name="category">
        /// {  "CategoryId": null,  "Code": null,  "Description": null,  "ParentCategoryId": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Category/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Category, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, CategoryDto  category)
        {
            Validate(category);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                category.CategoryId = id;
                var res = await _service.Update(id, category);
                if (res == -1)
                    return NotFound();
                return Ok(category);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Category/{id}
        /// <summary>
        /// Delete category by id 
        /// </summary>
        /// <param name="id">{CategoryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Category/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Category, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

