﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class PersonController : ApiController
    {
        private readonly PersonService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public PersonController(PersonService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/Person/Search
        /// <summary>
        /// Search Persons with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="person">
        /// { "PersonId": null,  "Name": null,  "Description": null,  "Email": null, "WebSite": null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Person/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Person, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(PersonDto person)
        {
            Validate(person);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(person);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/Person/{id}
        /// <summary>
        /// GET person by id 
        /// </summary>
        /// <param name="id">{PersonId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Person/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Person, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Person
        /// <summary>
        /// Add person 
        /// </summary>
        /// <param name="person">
        /// { "PersonId": null,  "Name": null,  "Description": null,  "Email": null, "WebSite": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Person")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Person, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(PersonDto person)
        {
            Validate(person);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(person);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/Person/{id}
        /// <summary>
        /// Update person by id 
        /// </summary>
        /// <param name="id">{PersonId}</param>
        /// <param name="person">
        /// { "PersonId": null,  "Name": null,  "Description": null,  "Email": null, "WebSite": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Person/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Person, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, PersonDto  person)
        {
            Validate(person);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                person.PersonId = id;
                var res = await _service.Update(id, person);
                if (res == -1)
                    return NotFound();
                return Ok(person);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Person/{id}
        /// <summary>
        /// Delete person by id 
        /// </summary>
        /// <param name="id">{PersonId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Person/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Person, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

