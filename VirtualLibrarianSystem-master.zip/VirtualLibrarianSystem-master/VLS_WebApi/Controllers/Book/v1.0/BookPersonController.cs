﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class BookPersonController : ApiController
    {
        private readonly BookPersonService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public BookPersonController(BookPersonService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/BookPerson/Search
        /// <summary>
        /// Search BookPersons with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="bookPerson">
        /// { "BookPersonId": null,  "BookId": null,  "PersonId": null,  "PersonKindId": null,"PersonName":null,"PersonKindDescription":null }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/BookPerson/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookPerson, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(BookPersonDto bookPerson)
        {
            Validate(bookPerson);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(bookPerson);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/BookPerson/{id}
        /// <summary>
        /// GET bookPerson by id 
        /// </summary>
        /// <param name="id">{BookPersonId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookPerson/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookPerson, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/BookPerson
        /// <summary>
        /// Add bookPerson 
        /// </summary>
        /// <param name="bookPerson">
        /// {  "BookPersonId": null,  "BookId": null,  "PersonId": null,  "PersonKindId": null,"PersonName":null,"PersonKindDescription":null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookPerson")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookPerson, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(BookPersonDto bookPerson)
        {
            Validate(bookPerson);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(bookPerson);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/BookPerson/{id}
        /// <summary>
        /// Update bookPerson by id 
        /// </summary>
        /// <param name="id">{BookPersonId}</param>
        /// <param name="bookPerson">
        /// {  "BookPersonId": null,  "BookId": null,  "PersonId": null,  "PersonKindId": null,"PersonName":null,"PersonKindDescription":null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookPerson/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookPerson, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, BookPersonDto  bookPerson)
        {
            Validate(bookPerson);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                bookPerson.BookPersonId = id;
                var res = await _service.Update(id, bookPerson);
                if (res == -1)
                    return NotFound();
                return Ok(bookPerson);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/BookPerson/{id}
        /// <summary>
        /// Delete bookPerson by id 
        /// </summary>
        /// <param name="id">{BookPersonId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookPerson/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookPerson, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

