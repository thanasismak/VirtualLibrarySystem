﻿using System;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Filters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class BookRatingController : ApiController
    {
        private readonly BookRatingService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public BookRatingController(BookRatingService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        /// <summary>
        /// 
        /// </summary>
        public int GetCurrentUserId
        {
            get
            {
                var principal = (GenericPrincipal)Thread.CurrentPrincipal;
                var identity = (BasicAuthenticationIdentity)principal?.Identity;
                if (identity?.UserId != null) return identity.UserId;
                return -1;
            }
        }


        //// POST: api/v1.0/BookRating/Search
        /// <summary>
        /// Search BookRatings with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="bookRating">
        /// { "BookRatingId": null,  "BookId": null,  "UserId": null,  "Rating": null,  "InsDate": null }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/BookRating/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookRating, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(BookRatingDto bookRating)
        {
            Validate(bookRating);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(bookRating);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/BookRating/{id}
        /// <summary>
        /// GET BookRating by id 
        /// </summary>
        /// <param name="id">{BookRatingId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookRating/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookRating, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/BookRating
        /// <summary>
        /// Add BookRating 
        /// </summary>
        /// <param name="bookRating">
        ///{ "BookRatingId": null,  "BookId": null,  "UserId": null,  "Rating": null,  "InsDate": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookRating")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookRating, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(BookRatingDto bookRating)
        {
            Validate(bookRating);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                bookRating.UserId = GetCurrentUserId;
                var newid = await _service.Insert(bookRating);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/BookRating/{id}
        /// <summary>
        /// Update BookRating by id 
        /// </summary>
        /// <param name="id">{BookRatingId}</param>
        /// <param name="bookRating">
        /// { "BookRatingId": null,  "BookId": null,  "UserId": null,  "Rating": null,  "InsDate": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookRating/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookRating, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, BookRatingDto  bookRating)
        {
            Validate(bookRating);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                bookRating.BookRatingId = id;
                var res = await _service.Update(id, bookRating);
                if (res == -1)
                    return NotFound();
                return Ok(bookRating);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/BookRating/{id}
        /// <summary>
        /// Delete BookRating by id 
        /// </summary>
        /// <param name="id">{BookRatingId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookRating/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookRating, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

