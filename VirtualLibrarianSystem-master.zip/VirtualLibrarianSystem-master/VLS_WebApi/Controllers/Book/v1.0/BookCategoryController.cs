﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class BookCategoryController : ApiController
    {
        private readonly BookCategoryService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public BookCategoryController(BookCategoryService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/BookCategory/Search
        /// <summary>
        /// Search BookCategorys with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="bookCategory">
        /// { "BookCategoryId": null,  "BookId": null,  "CategoryId": null, "CategoryDescription":null  }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/BookCategory/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookCategory, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(BookCategoryDto bookCategory)
        {
            Validate(bookCategory);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(bookCategory);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/BookCategory/{id}
        /// <summary>
        /// GET bookCategory by id 
        /// </summary>
        /// <param name="id">{BookCategoryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookCategory/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookCategory, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/BookCategory
        /// <summary>
        /// Add bookCategory 
        /// </summary>
        /// <param name="bookCategory">
        /// {  "BookCategoryId": null,  "BookId": null,  "CategoryId": null, "CategoryDescription":null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookCategory")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookCategory, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(BookCategoryDto bookCategory)
        {
            Validate(bookCategory);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(bookCategory);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/BookCategory/{id}
        /// <summary>
        /// Update bookCategory by id 
        /// </summary>
        /// <param name="id">{BookCategoryId}</param>
        /// <param name="bookCategory">
        /// {  "BookCategoryId": null,  "BookId": null,  "CategoryId": null, "CategoryDescription":null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/BookCategory/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookCategory, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, BookCategoryDto  bookCategory)
        {
            Validate(bookCategory);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                bookCategory.BookCategoryId = id;
                var res = await _service.Update(id, bookCategory);
                if (res == -1)
                    return NotFound();
                return Ok(bookCategory);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/BookCategory/{id}
        /// <summary>
        /// Delete bookCategory by id 
        /// </summary>
        /// <param name="id">{BookCategoryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/BookCategory/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.BookCategory, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

