﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Book;
using System.Runtime.Caching;
using VLS_Models.ModelsDto.Book;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Book.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    [DeflateGzipCompressionAttribute]
    public sealed class BookSearchController : ApiController
    {
        private readonly BookSearchService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public BookSearchController(BookSearchService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        /// GET: api/v1.0/BookSearch/GetByValue
        /// <summary>
        /// Search Books 
        ///  </summary>
        /// <param name="searchfield">from BookSearchField Enum</param>
        /// <param name="keyword"> </param>
        /// <param name="pageIndex"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1.0/BookSearch/GetByValue")]
        public async Task<IHttpActionResult> GetByValue(EnumBookSearchField searchfield, string keyword, int pageIndex)
        {
            try
            {
                ObjectCache cache = MemoryCache.Default;
                var cacheKey = "SearchBook_GetByValue_" + searchfield + "_" + keyword + "_" + pageIndex;
                var booklist = cache.Get(cacheKey) as List<BookSearchResultDto>;
                if (booklist != null) return Ok(booklist);

                booklist = await _service.GetByValue(searchfield, keyword, pageIndex);
                var policy = new CacheItemPolicy { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(20) };
                cache.Add(cacheKey, booklist, policy);
                return Ok(booklist);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/BookSearch/GetByPerson
        /// <summary>
        /// Search Books 
        ///  </summary>
        /// <param name="personKindId"></param>
        /// <param name="keyword"> </param>
        /// <param name="pageIndex"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1.0/BookSearch/GetByPerson")]
        public async Task<IHttpActionResult> GetByPerson(int personKindId, string keyword, int pageIndex)
        {
            try
            {
                ObjectCache cache = MemoryCache.Default;
                var cacheKey = "SearchBook_GetByPerson_"+ personKindId+"_"+ keyword + "_"+ pageIndex;
                var booklist = cache.Get(cacheKey) as List<BookSearchResultDto>;
                if (booklist != null) return Ok(booklist);

                booklist = await _service.GetByPerson(personKindId, keyword, pageIndex);
                var policy = new CacheItemPolicy { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(20) };
                cache.Add(cacheKey, booklist, policy);
                return Ok(booklist);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
         }


        /// GET: api/v1.0/BookSearch/GetById
        /// <summary>
        /// Search Books 
        ///  </summary>
        /// <param name="bookId"> </param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1.0/BookSearch/GetById")]
        public async Task<IHttpActionResult> GetById(int bookId)
        {
            try
            {
                ObjectCache cache = MemoryCache.Default;
                var cacheKey = "SearchBook_GetById_" + bookId.ToString();
                var booklist = cache.Get(cacheKey) as List<BookSearchResultDto>;
                if (booklist != null) return Ok(booklist);

                booklist = await _service.GetById(bookId);
                var policy = new CacheItemPolicy { AbsoluteExpiration = DateTimeOffset.Now.AddMinutes(20) };
                cache.Add(cacheKey, booklist, policy);
                return Ok(booklist);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }


        /// GET: api/v1.0/BookSearch/BookAvailability
        /// <summary>
        /// Search Books 
        ///  </summary>
        /// <param name="bookId"> </param>
        /// <returns></returns>
        [HttpGet]
        [Route("api/v1.0/BookSearch/BookAvailability")]
        public async Task<IHttpActionResult> BookAvailability(int bookId)
        {
            try
            {
                var booklist = await _service.GetBookAvailability(bookId);
                return Ok(booklist);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}