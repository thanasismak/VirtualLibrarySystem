﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Library;
using VLS_Models.ModelsDto.Library;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Library.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class LibraryController : ApiController
    {
        private readonly LibraryService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public LibraryController(LibraryService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }

        /// GET: api/v1.0/Library/GetByDistance
        /// <summary>
        /// GET library by distance
        /// </summary>
        /// <param name="latitude">{latitude}</param>
        /// <param name="longitude">{longitude}</param>
        /// <returns>The distance in meters.</returns>
        [Route("api/v1.0/Library/GetByDistance")]
        public async Task<List<LibraryDto>> GetByDistance(float latitude, float longitude)
        {
            var result = new List<LibraryDto>();
            try
            {
                result = await _service.GetByDistance(latitude, longitude);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
            }
            return result;
        }

        //// POST: api/v1.0/Library/Search
        /// <summary>
        /// Search Librarys with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="library">
        /// {  "LibraryId": null,  "Name": null,  "Description": null,  "Address": null,  "Email": null,  "WebSite": null,  "Phone1": null,  "Phone2": null,  "Phone3": null,  "Fax": null,  "Longitude": null,  "Latitude": null }
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/Library/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Library, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(LibraryDto library)
        {
            Validate(library);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(library);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }


        /// GET: api/v1.0/Library/{id}
        /// <summary>
        /// GET library by id 
        /// </summary>
        /// <param name="id">{LibraryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Library/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Library, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/Library
        /// <summary>
        /// Add library 
        /// </summary>
        /// <param name="library">
        /// {  "LibraryId": null,  "Name": null,  "Description": null,  "Address": null,  "Email": null,  "WebSite": null,  "Phone1": null,  "Phone2": null,  "Phone3": null,  "Fax": null,  "Longitude": null,  "Latitude": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Library")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Library, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(LibraryDto library)
        {
            Validate(library);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(library);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/Library/{id}
        /// <summary>
        /// Update library by id 
        /// </summary>
        /// <param name="id">{LibraryId}</param>
        /// <param name="library">
        /// {  "LibraryId": null,  "Name": null,  "Description": null,  "Address": null,  "Email": null,  "WebSite": null,  "Phone1": null,  "Phone2": null,  "Phone3": null,  "Fax": null,  "Longitude": null,  "Latitude": null }
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/Library/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Library, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, LibraryDto  library)
        {
            Validate(library);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                library.LibraryId = id;
                var res = await _service.Update(id, library);
                if (res == -1)
                    return NotFound();
                return Ok(library);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/Library/{id}
        /// <summary>
        /// Delete library by id 
        /// </summary>
        /// <param name="id">{LibraryId}</param>
        /// <returns></returns>
        [Route("api/v1.0/Library/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.Library, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

