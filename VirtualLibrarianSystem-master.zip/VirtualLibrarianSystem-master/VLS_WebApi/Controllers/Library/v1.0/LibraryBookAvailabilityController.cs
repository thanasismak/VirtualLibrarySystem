﻿using System;
using System.Threading.Tasks;
using System.Web.Http;
using VLS_BusinessLayer;
using VLS_BusinessLayer.Services;
using VLS_BusinessLayer.Services.Library;
using VLS_Models.ModelsDto.Library;
using VLS_WebApi.ActionFilters;
using VLS_WebApi.Misc;


namespace VLS_WebApi.Controllers.Library.v1._0
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class LibraryBookAvailabilityController : ApiController
    {
        private readonly LibraryBookAvailabilityService _service;
        private readonly LoggerService _logger;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="logger"></param>
        public LibraryBookAvailabilityController(LibraryBookAvailabilityService service, LoggerService logger)
        {
            _service = service;
            _logger = logger;
        }
        //// POST: api/v1.0/LibraryBookAvailability/Search
        /// <summary>
        /// Search LibraryBookAvailabilitys with Filters.
        /// For Contain, add % at start or at the end of filter 
        /// </summary>
        /// <param name="libraryBookAvailability">
        /// { "LibraryBookAvailabilityId": null,  "LibraryId": null,  "BookId": null,  "Quantity": null}
        /// </param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/v1.0/LibraryBookAvailability/Search")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.LibraryBookAvailability, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> Search(LibraryBookAvailabilityDto libraryBookAvailability)
        {
            Validate(libraryBookAvailability);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var result = await _service.Get(libraryBookAvailability);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// GET: api/v1.0/LibraryBookAvailability/{id}
        /// <summary>
        /// GET libraryBookAvailability by id 
        /// </summary>
        /// <param name="id">{LibraryBookAvailabilityId}</param>
        /// <returns></returns>
        [Route("api/v1.0/LibraryBookAvailability/{Id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.LibraryBookAvailability, BusinessEntityAction = EnumBusinessEntityAction.View)]
        public async Task<IHttpActionResult> GetById(int id)
        {
            try
            {
                var result = await _service.GetById(id);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// POST: api/v1.0/LibraryBookAvailability
        /// <summary>
        /// Add libraryBookAvailability 
        /// </summary>
        /// <param name="libraryBookAvailability">
        /// {  "LibraryBookAvailabilityId": null,  "LibraryId": null,  "BookId": null,  "Quantity": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/LibraryBookAvailability")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.LibraryBookAvailability, BusinessEntityAction = EnumBusinessEntityAction.Insert)]
        public async Task<IHttpActionResult> Post(LibraryBookAvailabilityDto libraryBookAvailability)
        {
            Validate(libraryBookAvailability);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var newid = await _service.Insert(libraryBookAvailability);
                return Ok(newid);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// PUT : api/v1.0/LibraryBookAvailability/{id}
        /// <summary>
        /// Update libraryBookAvailability by id 
        /// </summary>
        /// <param name="id">{LibraryBookAvailabilityId}</param>
        /// <param name="libraryBookAvailability">
        /// {  "LibraryBookAvailabilityId": null,  "LibraryId": null,  "BookId": null,  "Quantity": null}
        /// </param>
        /// <returns></returns>
        [Route("api/v1.0/LibraryBookAvailability/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.LibraryBookAvailability, BusinessEntityAction = EnumBusinessEntityAction.Update)]
        public async Task<IHttpActionResult> Put(int id, LibraryBookAvailabilityDto  libraryBookAvailability)
        {
            Validate(libraryBookAvailability);
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            try
            {
                libraryBookAvailability.LibraryBookAvailabilityId = id;
                var res = await _service.Update(id, libraryBookAvailability);
                if (res == -1)
                    return NotFound();
                return Ok(libraryBookAvailability);
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

        /// DELETE: api/v1.0/LibraryBookAvailability/{id}
        /// <summary>
        /// Delete libraryBookAvailability by id 
        /// </summary>
        /// <param name="id">{LibraryBookAvailabilityId}</param>
        /// <returns></returns>
        [Route("api/v1.0/LibraryBookAvailability/{id}")]
        [AuthorizationRequired(BusinessEntity = EnumBusinessEntity.LibraryBookAvailability, BusinessEntityAction = EnumBusinessEntityAction.Delete)]
        public async Task<IHttpActionResult> Delete(int id)
        {
            try
            {
                var res = await _service.Delete(id);
                if (res == -1)
                    return NotFound();
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Log(new LogEntry(EnumLoggingEventType.Error, Utils.LoggerMessage(System.Reflection.MethodBase.GetCurrentMethod(), "", "WebApi Error"), ex));
                return BadRequest(ex.ToString());
            }
        }

    }
}

