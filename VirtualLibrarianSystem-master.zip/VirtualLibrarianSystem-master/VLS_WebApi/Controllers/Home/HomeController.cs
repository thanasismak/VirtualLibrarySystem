﻿using System.Web.Http;
using System.Web.Mvc;

namespace VLS_WebApi.Controllers.Home
{
    /// <summary>
    /// 
    /// </summary>
    public class HomeController : Controller
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            ViewBag.Title = "Virtual Librarian Web API ";
            var apiExplorer = GlobalConfiguration.Configuration.Services.GetApiExplorer();

            return View(apiExplorer);
        }
 
    }
}
