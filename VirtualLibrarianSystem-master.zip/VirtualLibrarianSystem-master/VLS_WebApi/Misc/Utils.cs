﻿using System.Reflection;
using System.Security.Principal;
using System.Threading;
using System.Web;
using VLS_WebApi.Filters;

namespace VLS_WebApi.Misc
{
    /// <summary>
    /// 
    /// </summary>
    public class Utils
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodBase"></param>
        /// <param name="values"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static string LoggerMessage(MethodBase methodBase, string values, string message)
        {
            if (methodBase.DeclaringType != null)
            {
                string controller = methodBase.DeclaringType.FullName;
                string method = methodBase.Name;
                string uri = HttpContext.Current.Request.Url.AbsoluteUri;
                Utils utils = new Utils();
                return
                    $"User: {utils.GetCurrentUserInfo()}, ApiController: {controller}, Method: {method}, Uri: {uri}, Values: {values}, Message: {message}";
            }
            return string.Empty;
        }

        /// <summary />
        /// <returns></returns>
        public string GetIpAddress()
        {
            var context = HttpContext.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

            if (!string.IsNullOrEmpty(ipAddress))
            {
                string[] addresses = ipAddress.Split(',');
                if (addresses.Length != 0)
                {
                    return addresses[0];
                }
            }

            return context.Request.ServerVariables["REMOTE_ADDR"];
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Username
        {
            get
            {
                try
                {


                    var principal = (GenericPrincipal) Thread.CurrentPrincipal;
                    var identity = (BasicAuthenticationIdentity) principal?.Identity;
                    if (identity?.UserName != null) return identity.UserName;
                    return "";
                }
                catch
                {
                    return "";
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string GetCurrentUserInfo()
        {
            return $"{GetIpAddress()} - {Username}"; 
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public static float ParseFloat(float? number)
        {
            float value;
            if (number == null)
                return 0;

            bool result = float.TryParse(number.ToString(), out value);
            if (result)
            {
                return value;
            }
            else
            {
                return 0;
            }
        }

    }
}
